import { defineEventHandler, setResponseStatus } from 'h3';
import { g as getDB } from './index2.mjs';
import { r as responseJson } from './index.mjs';
import 'mysql2';
import './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';

const notebooks_get = defineEventHandler(async (event) => {
  const con = getDB();
  try {
    const [rows] = await con.execute("SELECT * FROM `notebooks`");
    console.log("333333", rows);
    await con.end();
    return responseJson(0, "ok", {});
  } catch (e) {
    await con.end();
    console.log("error", e);
    setResponseStatus(event, 500);
    return responseJson(1, "\u670D\u52A1\u5668\u9519\u8BEF", {});
  }
});

export { notebooks_get as default };
//# sourceMappingURL=notebooks.get.mjs.map
