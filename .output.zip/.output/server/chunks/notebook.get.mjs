import { defineEventHandler, setResponseStatus } from 'h3';
import { g as getDB } from './index2.mjs';
import { g as getLoginUid, r as responseJson } from './index.mjs';
import 'mysql2';
import './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';

const notebook_get = defineEventHandler(async (event) => {
  let uid = getLoginUid(event);
  console.log("uid", uid);
  if (uid === 0) {
    setResponseStatus(event, 401);
    return responseJson(1, "\u8BF7\u5148\u767B\u5F55", {});
  }
  const con = getDB();
  try {
    const [rows] = await con.execute(
      "SELECT * FROM `notebooks` WHERE `uid`=? ORDER BY `id` DESC",
      [uid]
    );
    console.log("333333", rows);
    await con.end();
    return responseJson(0, "\u83B7\u53D6\u6587\u96C6\u6210\u529F\u54E6", {
      list: rows
    });
  } catch (e) {
    await con.end();
    console.log("error", e);
    setResponseStatus(event, 500);
    return responseJson(1, "\u670D\u52A1\u5668\u9519\u8BEF", {});
  }
});

export { notebook_get as default };
//# sourceMappingURL=notebook.get.mjs.map
