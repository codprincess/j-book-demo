import { defineEventHandler, getQuery, setResponseStatus } from 'h3';
import { g as getDB } from './index2.mjs';
import { t as trimMarkdown, a as getFirstImage, r as responseJson } from './index.mjs';
import 'mysql2';
import './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';

const notes_get = defineEventHandler(async (event) => {
  const params = await getQuery(event);
  const con = getDB();
  try {
    const [notesData] = await con.query(
      "SELECT notes.id AS id,notes.title,notes.content_md,notes.uid,users.nickname FROM `notes` LEFT JOIN `users` ON notes.uid = users.id WHERE `state`=? LIMIT ? OFFSET ?",
      [2, Number(params.pageSize), (Number(params.page) - 1) * Number(params.pageSize)]
    );
    notesData.map((v) => {
      v.subTitle = trimMarkdown(v.content_md, 300);
      v.cover = getFirstImage(v.content_md);
      v.like = 45;
      v.content_md = "";
      v.flag = false;
    });
    await con.end();
    return responseJson(0, "\u83B7\u53D6\u6587\u7AE0\u6210\u529F\u54E6", {
      list: notesData
    });
  } catch (e) {
    await con.end();
    console.log("error", e);
    setResponseStatus(event, 500);
    return responseJson(1, "\u670D\u52A1\u5668\u9519\u8BEF", {});
  }
});

export { notes_get as default };
//# sourceMappingURL=notes.get.mjs.map
