import { defineEventHandler, setResponseStatus, readBody } from 'h3';
import Joi from 'joi';
import { g as getDB } from './index2.mjs';
import { g as getLoginUid, r as responseJson, b as genTitle } from './index.mjs';
import 'mysql2';
import './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';

const note_post = defineEventHandler(async (event) => {
  let uid = getLoginUid(event);
  console.log("uid", uid);
  if (uid === 0) {
    setResponseStatus(event, 401);
    return responseJson(1, "\u8BF7\u5148\u767B\u5F55", {});
  }
  const body = await readBody(event);
  console.log("11111", body);
  const schema = Joi.object({
    notebookId: Joi.number().required()
  });
  try {
    const value = await schema.validateAsync(body);
  } catch (err) {
    return responseJson(1, "\u53C2\u6570\u9519\u8BEF", {});
  }
  const con = getDB();
  try {
    const [rows] = await con.execute(
      "INSERT INTO `notes` (`title`,`content_md`,`state`,`uid`) VALUE (?,?,?,?)",
      [genTitle(), "", 1, uid]
    );
    if (rows.affectedRows === 0) {
      return responseJson(1, "\u521B\u5EFA\u5931\u8D25", {});
    }
    console.log("333333", rows);
    const [rows2] = await con.execute(
      "INSERT INTO `notebook_notes` (`notebook_id`,`note_id`) VALUE (?,?)",
      [body.notebookId, rows.insertId]
    );
    await con.end();
    if (rows.affectedRows === 0) {
      return responseJson(1, "\u521B\u5EFA\u5931\u8D25", {});
    }
    return responseJson(0, "\u521B\u5EFA\u6210\u529F", {});
  } catch (e) {
    await con.end();
    console.log("error", e);
    setResponseStatus(event, 500);
    return responseJson(1, "\u670D\u52A1\u5668\u9519\u8BEF", {});
  }
});

export { note_post as default };
//# sourceMappingURL=note.post.mjs.map
