const responseJson = (code, msg, data) => {
  let resp = { code, msg, data };
  return resp;
};
const getLoginUid = (event) => {
  return event.context.auth ? event.context.auth.uid : 0;
};
const genTitle = () => {
  let currentDate = /* @__PURE__ */ new Date();
  let year = currentDate.getFullYear();
  let month = ("0" + (currentDate.getMonth() + 1)).slice(-2);
  let day = ("0" + currentDate.getDay()).slice(-2);
  return year + "-" + month + "-" + day;
};
const trimMarkdown = (content, maxLength) => {
  let strippedContent = content.replace(/#|\*|_|`/g, "");
  if (strippedContent.length > maxLength) {
    strippedContent = strippedContent.substr(0, maxLength) + "...";
  }
  return strippedContent;
};
const getFirstImage = (content) => {
  const regex = /!\[.*\]\((.*)\)/;
  const match = content.match(regex);
  if (match) {
    return match[1];
  }
  return null;
};

export { getFirstImage as a, genTitle as b, getLoginUid as g, responseJson as r, trimMarkdown as t };
//# sourceMappingURL=index.mjs.map
