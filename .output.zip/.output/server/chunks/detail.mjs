import { defineEventHandler, getQuery, setResponseStatus } from 'h3';
import { g as getDB } from './index2.mjs';
import { r as responseJson, t as trimMarkdown } from './index.mjs';
import Joi from 'joi';
import 'mysql2';
import './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';

const detail = defineEventHandler(async (event) => {
  const params = await getQuery(event);
  const schema = Joi.object({
    noteId: Joi.number().required()
  });
  try {
    const value = await schema.validateAsync(params);
  } catch (err) {
    return responseJson(1, "\u53C2\u6570\u9519\u8BEF", {});
  }
  const con = getDB();
  try {
    const [notesData] = await con.query(
      "SELECT notes.id AS id,notes.title,notes.content_md,notes.uid,notes.created_at,users.nickname,users.avatar FROM `notes` LEFT JOIN `users` ON notes.uid = users.id WHERE `state`=? AND notes.id=?",
      [2, params.noteId]
    );
    if (notesData.length !== 1) {
      return responseJson(1, "\u6587\u7AE0\u4E0D\u5B58\u5728", {});
    }
    await con.end();
    return responseJson(0, "\u83B7\u53D6\u6587\u7AE0\u6210\u529F\u54E6", {
      id: notesData[0].id,
      title: notesData[0].title,
      subTitle: trimMarkdown(notesData[0].content_md, 300),
      author: {
        id: notesData[0].uid,
        nickname: notesData[0].nickname,
        avatar: notesData[0].avatar
      },
      content_md: notesData[0].content_md,
      created_at: notesData[0].created_at
    });
  } catch (e) {
    await con.end();
    console.log("error", e);
    setResponseStatus(event, 500);
    return responseJson(1, "\u670D\u52A1\u5668\u9519\u8BEF", {});
  }
});

export { detail as default };
//# sourceMappingURL=detail.mjs.map
