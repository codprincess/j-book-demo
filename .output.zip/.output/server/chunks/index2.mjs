import mysql from 'mysql2';
import { u as useRuntimeConfig } from './nitro/node-server.mjs';

const getDB = () => {
  const config = useRuntimeConfig();
  console.log(66666666, config);
  return mysql.createPool({
    host: config.DB_HOST,
    user: config.DB_USER,
    database: config.DB_DATABASE,
    password: config.DB_PASSWORD,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  }).promise();
};

export { getDB as g };
//# sourceMappingURL=index2.mjs.map
