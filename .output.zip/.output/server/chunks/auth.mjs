import { defineEventHandler, setResponseStatus, getQuery } from 'h3';
import { g as getLoginUid, r as responseJson } from './index.mjs';
import STS from 'qcloud-cos-sts';
import Joi from 'joi';
import { u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';

const conf = useRuntimeConfig();
var config = {
  secretId: conf.SecretId,
  // 固定密钥
  secretKey: conf.SecretKey,
  // 固定密钥
  proxy: "",
  durationSeconds: 1800,
  // host: 'sts.tencentcloudapi.com', // 域名，非必须，默认为 sts.tencentcloudapi.com
  endpoint: "sts.tencentcloudapi.com",
  // 域名，非必须，与host二选一，默认为 sts.tencentcloudapi.com
  // 放行判断相关参数
  bucket: conf.public.BUCKET,
  region: conf.public.REGION,
  allowPrefix: "",
  // 这里改成允许的路径前缀，可以根据自己网站的用户登录态判断允许上传的具体路径，例子： a.jpg 或者 a/* 或者 * (使用通配符*存在重大安全风险, 请谨慎评估使用)
  // 简单上传和分片，需要以下的权限，其他权限列表请看 https://cloud.tencent.com/document/product/436/31923
  allowActions: [
    // 简单上传
    "name/cos:PutObject",
    "name/cos:PostObject",
    // 分片上传
    "name/cos:InitiateMultipartUpload",
    "name/cos:ListMultipartUploads",
    "name/cos:ListParts",
    "name/cos:UploadPart",
    "name/cos:CompleteMultipartUpload"
  ]
};
const auth = defineEventHandler(async (event) => {
  let uid = getLoginUid(event);
  console.log("uid", uid);
  if (uid === 0) {
    setResponseStatus(event, 401);
    return responseJson(1, "\u8BF7\u5148\u767B\u5F55", {});
  }
  const params = await getQuery(event);
  console.log("params", params);
  const schema = Joi.object({
    type: Joi.string().required()
  });
  try {
    const value = await schema.validateAsync(params);
  } catch (err) {
    return responseJson(1, "\u53C2\u6570\u9519\u8BEF", {});
  }
  if (params.type !== "avatar" && params.type !== "note") {
    return responseJson(1, "\u53C2\u6570\u9519\u8BEF~", {});
  }
  config.allowPrefix = "uploads/" + uid + "/" + params.type + "/*";
  var shortBucketName = config.bucket.substr(0, config.bucket.lastIndexOf("-"));
  var appId = config.bucket.substr(1 + config.bucket.lastIndexOf("-"));
  var policy = {
    "version": "2.0",
    "statement": [{
      "action": config.allowActions,
      "effect": "allow",
      "principal": { "qcs": ["*"] },
      "resource": [
        "qcs::cos:" + config.region + ":uid/" + appId + ":prefix//" + appId + "/" + shortBucketName + "/" + config.allowPrefix
      ]
      // condition生效条件，关于 condition 的详细设置规则和COS支持的condition类型可以参考https://cloud.tencent.com/document/product/436/71306
      // 'condition': {
      //   // 比如限定ip访问
      //   'ip_equal': {
      //     'qcs:ip': '10.121.2.10/24'
      //   }
      // }
    }]
  };
  const result = await STS.getCredential({
    secretId: config.secretId,
    secretKey: config.secretKey,
    proxy: config.proxy,
    durationSeconds: config.durationSeconds,
    endpoint: config.endpoint,
    policy
  });
  return responseJson(0, "ok~~~", result);
});

export { auth as default };
//# sourceMappingURL=auth.mjs.map
