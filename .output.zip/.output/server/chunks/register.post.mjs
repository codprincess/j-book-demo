import { defineEventHandler, readBody } from 'h3';
import Joi from 'joi';
import md5 from 'md5';
import { g as getDB } from './index2.mjs';
import { r as responseJson } from './index.mjs';
import 'mysql2';
import './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';

const register_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  console.log("11111", body);
  const schema = Joi.object({
    nickname: Joi.string().required(),
    password: Joi.string().required(),
    phone: Joi.string().pattern(/1\d{10}/)
  });
  try {
    const value = await schema.validateAsync(body);
  } catch (err) {
    return responseJson(1, "\u53C2\u6570\u9519\u8BEF", {});
  }
  let salt = "ueidfisgfilegfiff";
  let password = md5(md5(body.password) + salt);
  const con = getDB();
  try {
    const [rows] = await con.execute("select * from `users` where `phone`=?", [body.phone]);
    console.log("22222", rows);
    if (rows.length > 0) {
      return responseJson(1, "\u8D26\u53F7\u5DF2\u6CE8\u518C", {});
    }
    const [rows2] = await con.execute("insert into `users` (`nickname`,`phone`,`password`) value (?,?,?)", [body.nickname, body.phone, password]);
    console.log("333333", rows2);
    await con.end();
    if (rows2.affectedRows === 1) {
      return responseJson(0, "\u6CE8\u518C\u6210\u529F", {});
    }
  } catch (e) {
    await con.end();
    return responseJson(1, "\u670D\u52A1\u5668\u9519\u8BEF", {});
  }
});

export { register_post as default };
//# sourceMappingURL=register.post.mjs.map
