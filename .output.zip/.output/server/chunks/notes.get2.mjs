import { defineEventHandler, setResponseStatus, getQuery } from 'h3';
import { g as getDB } from './index2.mjs';
import { g as getLoginUid, r as responseJson } from './index.mjs';
import Joi from 'joi';
import 'mysql2';
import './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';

const notes_get = defineEventHandler(async (event) => {
  let uid = getLoginUid(event);
  console.log("uid", uid);
  if (uid === 0) {
    setResponseStatus(event, 401);
    return responseJson(1, "\u8BF7\u5148\u767B\u5F55", {});
  }
  const params = await getQuery(event);
  console.log("body", params);
  const schema = Joi.object({
    notebookId: Joi.number().required()
  });
  try {
    const value = await schema.validateAsync(params);
  } catch (err) {
    return responseJson(1, "\u53C2\u6570\u9519\u8BEF", {});
  }
  const con = getDB();
  try {
    const [notebookRows] = await con.query(
      "SELECT `note_id` FROM `notebook_notes` WHERE `notebook_id`=?",
      [params.notebookId]
    );
    console.log("notebookRows", notebookRows);
    let noteIdList = [];
    if (notebookRows.length < 1) {
      return responseJson(0, "\u65E0\u6570\u636E", {
        list: []
      });
    }
    notebookRows.map((v) => {
      noteIdList.push(v.note_id);
    });
    const [notesRows] = await con.query(
      "SELECT id,title FROM `notes` WHERE `uid`=? AND id IN (?) ORDER BY `id` DESC",
      [uid, noteIdList]
    );
    console.log("notesRows", notesRows);
    await con.end();
    return responseJson(0, "\u83B7\u53D6\u6587\u7AE0\u6210\u529F\u54E6", {
      list: notesRows
    });
  } catch (e) {
    await con.end();
    console.log("error", e);
    setResponseStatus(event, 500);
    return responseJson(1, "\u670D\u52A1\u5668\u9519\u8BEF", {});
  }
});

export { notes_get as default };
//# sourceMappingURL=notes.get2.mjs.map
