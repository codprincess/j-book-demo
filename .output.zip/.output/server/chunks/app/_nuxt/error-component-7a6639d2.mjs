import { useSSRContext, defineAsyncComponent, unref, mergeProps } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';

const o = { __name: "nuxt-error-page", __ssrInlineRender: true, props: { error: Object }, setup(r) {
  var _a;
  const { error: t } = r;
  (t.stack || "").split(`
`).splice(1).map((e) => ({ text: e.replace("webpack:/", "").replace(".vue", ".js").trim(), internal: e.includes("node_modules") && !e.includes(".cache") || e.includes("internal") || e.includes("new Promise") })).map((e) => `<span class="stack${e.internal ? " internal" : ""}">${e.text}</span>`).join(`
`);
  const s = Number(t.statusCode || 500), a = s === 404, d = (_a = t.statusMessage) != null ? _a : a ? "Page Not Found" : "Internal Server Error", i = t.message || t.toString(), m = void 0, l = a ? defineAsyncComponent(() => import('./error-404-25262f42.mjs').then((e) => e.default || e)) : defineAsyncComponent(() => import('./error-500-8debfb4e.mjs').then((e) => e.default || e));
  return (e, c, _, f) => {
    c(ssrRenderComponent(unref(l), mergeProps({ statusCode: unref(s), statusMessage: unref(d), description: unref(i), stack: unref(m) }, f), null, _));
  };
} }, p = o.setup;
o.setup = (r, t) => {
  const s = useSSRContext();
  return (s.modules || (s.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/app/components/nuxt-error-page.vue"), p ? p(r, t) : void 0;
};
const h = o;

export { h as default };
//# sourceMappingURL=error-component-7a6639d2.mjs.map
