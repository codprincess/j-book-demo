import { unref, useSSRContext } from 'vue';
import { V as Vr } from '../server.mjs';
import { ssrInterpolate } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import '@babel/runtime/helpers/esm/objectSpread2';
import '@babel/runtime/helpers/esm/defineProperty';
import '@babel/runtime/helpers/esm/objectWithoutProperties';
import '@babel/runtime/helpers/esm/slicedToArray';
import '@babel/runtime/helpers/esm/typeof';
import '@babel/runtime/helpers/esm/extends';
import '@babel/runtime/helpers/esm/toConsumableArray';
import 'vue-types';
import '@ant-design/colors';
import '@ctrl/tinycolor';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';

const m = { __name: "about", __ssrInlineRender: true, setup(o) {
  const t = Vr();
  return (r, i, a, _) => {
    i(`<!--[--><h1>about</h1><h1>${ssrInterpolate(unref(t).query)}</h1><!--]-->`);
  };
} }, p = m.setup;
m.setup = (o, t) => {
  const r = useSSRContext();
  return (r.modules || (r.modules = /* @__PURE__ */ new Set())).add("pages/about.vue"), p ? p(o, t) : void 0;
};

export { m as default };
//# sourceMappingURL=about-d426e075.mjs.map
