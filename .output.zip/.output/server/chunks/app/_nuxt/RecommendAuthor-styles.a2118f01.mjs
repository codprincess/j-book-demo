const t = `.recommended-authors[data-v-df5074f5]{margin-top:30px;width:100%}.recommended-authors .title[data-v-df5074f5]{color:#b4b4b4;display:flex;justify-content:space-between;width:100%}.recommended-authors .title a[data-v-df5074f5]{align-items:center;color:#b4b4b4;display:flex}.recommended-authors .title a[data-v-df5074f5]:hover{color:#333}.recommended-authors .list[data-v-df5074f5]{margin-top:30px}.recommended-authors .list .list-item[data-v-df5074f5]{display:flex;margin-bottom:10px}.recommended-authors .list .list-item .authors-info[data-v-df5074f5]{flex:1;margin-left:10px}.recommended-authors .list .list-item .authors-info .authors-name[data-v-df5074f5]{display:flex;justify-content:space-between}.recommended-authors .list .list-item .authors-info .authors-name a[data-v-df5074f5]{color:#00bb29}.recommended-authors .list .list-item .authors-info p[data-v-df5074f5]{color:#969696;font-size:12px;margin-top:2px}
`;

const RecommendAuthorStyles_a2118f01 = [t];

export { RecommendAuthorStyles_a2118f01 as default };
//# sourceMappingURL=RecommendAuthor-styles.a2118f01.mjs.map
