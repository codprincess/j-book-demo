import { defineComponent, computed, ref, h, resolveComponent } from 'vue';
import { hasProtocol, parseURL, parseQuery, withTrailingSlash, withoutTrailingSlash } from 'ufo';
import { n as Tt, d as Br } from '../server.mjs';

const N = (...t) => t.find((u) => u !== void 0), b = "noopener noreferrer";
function k(t) {
  const u = t.componentName || "NuxtLink", m = (e, l) => {
    if (!e || t.trailingSlash !== "append" && t.trailingSlash !== "remove")
      return e;
    const i = t.trailingSlash === "append" ? withTrailingSlash : withoutTrailingSlash;
    if (typeof e == "string")
      return i(e, true);
    const a = "path" in e ? e.path : l(e).path;
    return { ...e, name: void 0, path: i(a, true) };
  };
  return defineComponent({ name: u, props: { to: { type: [String, Object], default: void 0, required: false }, href: { type: [String, Object], default: void 0, required: false }, target: { type: String, default: void 0, required: false }, rel: { type: String, default: void 0, required: false }, noRel: { type: Boolean, default: void 0, required: false }, prefetch: { type: Boolean, default: void 0, required: false }, noPrefetch: { type: Boolean, default: void 0, required: false }, activeClass: { type: String, default: void 0, required: false }, exactActiveClass: { type: String, default: void 0, required: false }, prefetchedClass: { type: String, default: void 0, required: false }, replace: { type: Boolean, default: void 0, required: false }, ariaCurrentValue: { type: String, default: void 0, required: false }, external: { type: Boolean, default: void 0, required: false }, custom: { type: Boolean, default: void 0, required: false } }, setup(e, { slots: l }) {
    const i = Tt(), a = computed(() => {
      const r = e.to || e.href || "";
      return m(r, i.resolve);
    }), f = computed(() => e.external || e.target && e.target !== "_self" ? true : typeof a.value == "object" ? false : a.value === "" || hasProtocol(a.value, { acceptRelative: true })), g = ref(false), p = void 0, y = void 0;
    return () => {
      var _a;
      var d, s;
      if (!f.value) {
        const n = { ref: y, to: a.value, activeClass: e.activeClass || t.activeClass, exactActiveClass: e.exactActiveClass || t.exactActiveClass, replace: e.replace, ariaCurrentValue: e.ariaCurrentValue, custom: e.custom };
        return e.custom || (g.value && (n.class = e.prefetchedClass || t.prefetchedClass), n.rel = e.rel), h(resolveComponent("RouterLink"), n, l.default);
      }
      const r = typeof a.value == "object" ? (_a = (d = i.resolve(a.value)) == null ? void 0 : d.href) != null ? _a : null : a.value || null, o = e.target || null, c = e.noRel ? null : N(e.rel, t.externalRelAttribute, r ? b : "") || null, C = () => Br(r, { replace: e.replace });
      return e.custom ? l.default ? l.default({ href: r, navigate: C, get route() {
        if (!r)
          return;
        const n = parseURL(r);
        return { path: n.pathname, fullPath: n.pathname, get query() {
          return parseQuery(n.search);
        }, hash: n.hash, params: {}, name: void 0, matched: [], redirectedFrom: void 0, meta: {}, href: r };
      }, rel: c, target: o, isExternal: f.value, isActive: false, isExactActive: false }) : null : h("a", { ref: p, href: r, rel: c, target: o }, (s = l.default) == null ? void 0 : s.call(l));
    };
  } });
}
const V = k({ componentName: "NuxtLink" });

export { V };
//# sourceMappingURL=nuxt-link-00da5e11.mjs.map
