const e = `.settings[data-v-a5bb3eb5]{padding-top:80px}.settings .aside[data-v-a5bb3eb5]{margin-top:20px}.settings .aside .active[data-v-a5bb3eb5]{background-color:#f0f0f0;border-radius:5px}.settings .aside .user-link-item[data-v-a5bb3eb5]{align-items:center;display:flex;padding:5px 10px}.settings .aside .user-link-item[data-v-a5bb3eb5]:hover{background-color:#f0f0f0;border-radius:5px}.settings .aside .user-link-item svg[data-v-a5bb3eb5]{color:#a0a0a0;font-size:32px}.settings .aside .user-link-item span[data-v-a5bb3eb5]{color:#333;font-size:16px;margin-left:12px}.settings .setting-base[data-v-a5bb3eb5]{margin-left:50px}.settings .setting-base .border-b[data-v-a5bb3eb5]{border-bottom:1px solid #f0f0f0}.settings .setting-base .settings-list[data-v-a5bb3eb5]{align-items:center;display:flex;padding:20px 0}.settings .setting-base .settings-list .item-line[data-v-a5bb3eb5]{width:150px}.settings .setting-base .settings-list .item-line span[data-v-a5bb3eb5]{color:#969696;font-size:15px}.settings .setting-base .settings-list .nickname[data-v-a5bb3eb5]{background-color:#f7f7f7;border:1px solid #c8c8c8;border-radius:6px;padding:2px}
`;

const t = `.settings-list .ant-btn.ant-btn-background-ghost{border-color:#42c02e;color:#42c02e;height:36px}.save-btn .ant-btn.ant-btn-background-ghost{background-color:#00bb29;border-color:#42c02e;color:#fff;height:32px;margin-top:30px}
`;

const settingsStyles_6cb053ef = [e, t];

export { settingsStyles_6cb053ef as default };
//# sourceMappingURL=settings-styles.6cb053ef.mjs.map
