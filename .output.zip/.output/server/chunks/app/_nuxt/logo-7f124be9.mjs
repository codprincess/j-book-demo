import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { defineComponent, ref, computed, createVNode, Fragment, inject, provide } from 'vue';
import { k as ke, b as Ai, N as Nt, a as pt, h as Mt, L as ma } from '../server.mjs';
import v from '@babel/runtime/helpers/esm/objectSpread2';
import { b as bt, Y as Yo, k as Xo, C as Ce, D as Jn } from './useHttpFetch-0d93f309.mjs';

var C = Symbol("SizeProvider"), H = function(e) {
  var n = inject("configProvider", ma), s = computed(function() {
    return e.size || n.componentSize;
  });
  return provide(C, s), s;
}, J = function(e) {
  var n = e ? computed(function() {
    return e.size;
  }) : inject(C, computed(function() {
    return "default";
  }));
  return n;
}, G = function() {
  return v(v({}, Jn()), {}, { content: pt.any, title: pt.any });
}, M = defineComponent({ compatConfig: { MODE: 3 }, name: "APopover", props: bt(G(), v(v({}, Yo()), {}, { trigger: "hover", transitionName: "zoom-big", placement: "top", mouseEnterDelay: 0.1, mouseLeaveDelay: 0.1 })), setup: function(e, n) {
  var s = n.expose, i = n.slots, f = ref();
  s({ getPopupDomNode: function() {
    var t, o;
    return (t = f.value) === null || t === void 0 || (o = t.getPopupDomNode) === null || o === void 0 ? void 0 : o.call(t);
  } });
  var d = ke("popover", e), p = d.prefixCls, x = d.configProvider, D = computed(function() {
    return x.getPrefixCls();
  }), N = function() {
    var t, o, m = e.title, a = m === void 0 ? Mt((t = i.title) === null || t === void 0 ? void 0 : t.call(i)) : m, g = e.content, c = g === void 0 ? Mt((o = i.content) === null || o === void 0 ? void 0 : o.call(i)) : g, P = !!(Array.isArray(a) ? a.length : a), b = !!(Array.isArray(c) ? c.length : a);
    if (!(!P && !b))
      return createVNode(Fragment, null, [P && createVNode("div", { class: "".concat(p.value, "-title") }, [a]), createVNode("div", { class: "".concat(p.value, "-inner-content") }, [c])]);
  };
  return function() {
    return createVNode(Xo, v(v({}, Ce(e, ["title", "content"])), {}, { prefixCls: p.value, ref: f, transitionName: Ai(D.value, "zoom-big", e.transitionName) }), { title: N, default: i.default });
  };
} });
const K = Nt(M), Q = "" + publicAssetsURL("images/logo.png");

export { H, J, K, Q };
//# sourceMappingURL=logo-7f124be9.mjs.map
