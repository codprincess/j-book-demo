import { V } from './nuxt-link-00da5e11.mjs';
import { h as hn, o as or, i as ia$1, X as Xe, l as lr, L as Le, _ as _e, n as nn } from './index-4f8e2b3b.mjs';
import { createVNode, defineComponent, ref, computed, watch, nextTick, provide, inject, createElementVNode, mergeProps, withCtx, createTextVNode, unref, openBlock, createBlock, useSSRContext, onUnmounted, shallowRef, watchEffect, createElementBlock } from 'vue';
import { A as AntdIcon, k as ke, m as ki, y as ye, p as pe, E as Ea$1, a as pt, g as Eo, d as Br, i as it } from '../server.mjs';
import { h as Q, b as bt, G as Go, j as Ze, e as ei, t as ti, o as oi, k as Xo, J as Jo } from './useHttpFetch-0d93f309.mjs';
import { ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { J, H, K, Q as Q$1 } from './logo-7f124be9.mjs';
import ce from '@babel/runtime/helpers/esm/extends';
import x from '@babel/runtime/helpers/esm/defineProperty';
import fe from '@babel/runtime/helpers/esm/toConsumableArray';
import v from '@babel/runtime/helpers/esm/objectSpread2';
import ee from '@babel/runtime/helpers/esm/typeof';

// This icon file is generated automatically.
var BarsOutlined$1 = { "icon": { "tag": "svg", "attrs": { "viewBox": "0 0 1024 1024", "focusable": "false" }, "children": [{ "tag": "path", "attrs": { "d": "M912 192H328c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h584c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8zm0 284H328c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h584c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8zm0 284H328c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h584c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8zM104 228a56 56 0 10112 0 56 56 0 10-112 0zm0 284a56 56 0 10112 0 56 56 0 10-112 0zm0 284a56 56 0 10112 0 56 56 0 10-112 0z" } }] }, "name": "bars", "theme": "outlined" };
const BarsOutlinedSvg = BarsOutlined$1;

function _objectSpread$1(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? Object(arguments[i]) : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty$1(target, key, source[key]); }); } return target; }

function _defineProperty$1(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var BarsOutlined = function BarsOutlined(props, context) {
  var p = _objectSpread$1({}, props, context.attrs);

  return createVNode(AntdIcon, _objectSpread$1({}, p, {
    "icon": BarsOutlinedSvg
  }), null);
};

BarsOutlined.displayName = 'BarsOutlined';
BarsOutlined.inheritAttrs = false;
const Mt = BarsOutlined;

// This icon file is generated automatically.
var LeftOutlined$1 = { "icon": { "tag": "svg", "attrs": { "viewBox": "64 64 896 896", "focusable": "false" }, "children": [{ "tag": "path", "attrs": { "d": "M724 218.3V141c0-6.7-7.7-10.4-12.9-6.3L260.3 486.8a31.86 31.86 0 000 50.3l450.8 352.1c5.3 4.1 12.9.4 12.9-6.3v-77.3c0-4.9-2.3-9.6-6.1-12.6l-360-281 360-281.1c3.8-3 6.1-7.7 6.1-12.6z" } }] }, "name": "left", "theme": "outlined" };
const LeftOutlinedSvg = LeftOutlined$1;

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? Object(arguments[i]) : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var LeftOutlined = function LeftOutlined(props, context) {
  var p = _objectSpread({}, props, context.attrs);

  return createVNode(AntdIcon, _objectSpread({}, p, {
    "icon": LeftOutlinedSvg
  }), null);
};

LeftOutlined.displayName = 'LeftOutlined';
LeftOutlined.inheritAttrs = false;
const Je = LeftOutlined;

function Ot() {
  var c = ref({}), a = null;
  return onUnmounted(function() {
    Go.unsubscribe(a);
  }), c;
}
function Wt(c) {
  var a = shallowRef();
  return watchEffect(function() {
    a.value = c();
  }, { flush: "sync" }), a;
}
var It = function() {
  return { prefixCls: String, shape: { type: String, default: "circle" }, size: { type: [Number, String, Object], default: function() {
    return "default";
  } }, src: String, srcset: String, icon: pt.any, alt: String, gap: Number, draggable: { type: Boolean, default: void 0 }, crossOrigin: String, loadError: { type: Function } };
}, Rt = defineComponent({ compatConfig: { MODE: 3 }, name: "AAvatar", inheritAttrs: false, props: It(), slots: ["icon"], setup: function(a, y) {
  var k = y.slots, p = y.attrs, z = ref(true), E = ref(false), F = ref(1), A = ref(null), _ = ref(null), B = ke("avatar", a), i = B.prefixCls, s = J(), n = computed(function() {
    return a.size === "default" ? s.value : a.size;
  }), S = Ot(), v$1 = Wt(function() {
    if (ee(a.size) === "object") {
      var m = Ze.find(function(h) {
        return S.value[h];
      }), f = a.size[m];
      return f;
    }
  }), P = function(f) {
    return v$1.value ? { width: "".concat(v$1.value, "px"), height: "".concat(v$1.value, "px"), lineHeight: "".concat(v$1.value, "px"), fontSize: "".concat(f ? v$1.value / 2 : 18, "px") } : {};
  }, g = function() {
    if (!(!A.value || !_.value)) {
      var f = A.value.offsetWidth, h = _.value.offsetWidth;
      if (f !== 0 && h !== 0) {
        var d = a.gap, N = d === void 0 ? 4 : d;
        N * 2 < h && (F.value = h - N * 2 < f ? (h - N * 2) / f : 1);
      }
    }
  }, T = function() {
    var f = a.loadError, h = f == null ? void 0 : f();
    h !== false && (z.value = false);
  };
  return watch(function() {
    return a.src;
  }, function() {
    nextTick(function() {
      z.value = true, F.value = 1;
    });
  }), watch(function() {
    return a.gap;
  }, function() {
    nextTick(function() {
      g();
    });
  }), function() {
    var m, f, h = a.shape, d = a.src, N = a.alt, D = a.srcset, X = a.draggable, V = a.crossOrigin, r = ki(k, a, "icon"), $ = i.value, I = (m = {}, x(m, "".concat(p.class), !!p.class), x(m, $, true), x(m, "".concat($, "-lg"), n.value === "large"), x(m, "".concat($, "-sm"), n.value === "small"), x(m, "".concat($, "-").concat(h), h), x(m, "".concat($, "-image"), d && z.value), x(m, "".concat($, "-icon"), r), m), R = typeof n.value == "number" ? { width: "".concat(n.value, "px"), height: "".concat(n.value, "px"), lineHeight: "".concat(n.value, "px"), fontSize: r ? "".concat(n.value / 2, "px") : "18px" } : {}, M = (f = k.default) === null || f === void 0 ? void 0 : f.call(k), H;
    if (d && z.value)
      H = createVNode("img", { draggable: X, src: d, srcset: D, onError: T, alt: N, crossorigin: V }, null);
    else if (r)
      H = r;
    else if (E.value || F.value !== 1) {
      var me = "scale(".concat(F.value, ") translateX(-50%)"), pe = { msTransform: me, WebkitTransform: me, transform: me }, Se = typeof n.value == "number" ? { lineHeight: "".concat(n.value, "px") } : {};
      H = createVNode(hn, { onResize: g }, { default: function() {
        return [createVNode("span", { class: "".concat($, "-string"), ref: A, style: v(v({}, Se), pe) }, [M])];
      } });
    } else
      H = createVNode("span", { class: "".concat($, "-string"), ref: A, style: { opacity: 0 } }, [M]);
    return createVNode("span", v(v({}, p), {}, { ref: _, class: I, style: [R, P(!!r), p.style] }), [H]);
  };
} });
const ge = Rt;
var Ft = function() {
  return { prefixCls: String, maxCount: Number, maxStyle: { type: Object, default: void 0 }, maxPopoverPlacement: { type: String, default: "top" }, maxPopoverTrigger: String, size: { type: [Number, String, Object], default: "default" } };
}, Vt = defineComponent({ compatConfig: { MODE: 3 }, name: "AAvatarGroup", inheritAttrs: false, props: Ft(), setup: function(a, y) {
  var k = y.slots, p = y.attrs, z = ke("avatar-group", a), E = z.prefixCls, F = z.direction;
  return H(a), function() {
    var A, _ = a.maxPopoverPlacement, B = _ === void 0 ? "top" : _, i = a.maxCount, s = a.maxStyle, n = a.maxPopoverTrigger, S = n === void 0 ? "hover" : n, v$1 = (A = {}, x(A, E.value, true), x(A, "".concat(E.value, "-rtl"), F.value === "rtl"), x(A, "".concat(p.class), !!p.class), A), P = ki(k, a), g = ye(P).map(function(h, d) {
      return Q(h, { key: "avatar-key-".concat(d) });
    }), T = g.length;
    if (i && i < T) {
      var m = g.slice(0, i), f = g.slice(i, T);
      return m.push(createVNode(K, { key: "avatar-popover-key", content: f, trigger: S, placement: B, overlayClassName: "".concat(E.value, "-popover") }, { default: function() {
        return [createVNode(ge, { style: s }, { default: function() {
          return ["+".concat(T - i)];
        } })];
      } })), createVNode("div", v(v({}, p), {}, { class: v$1, style: p.style }), [m]);
    }
    return createVNode("div", v(v({}, p), {}, { class: v$1, style: p.style }), [g]);
  };
} });
const Ee = Vt;
ge.Group = Ee;
ge.install = function(c) {
  return c.component(ge.name, ge), c.component(Ee.name, Ee), c;
};
var Zt = function(a) {
  return !isNaN(parseFloat(a)) && isFinite(a);
};
const Dt = Zt;
var Me = function() {
  return { prefixCls: String, hasSider: { type: Boolean, default: void 0 }, tagName: String };
};
function $e(c) {
  var a = c.suffixCls, y = c.tagName, k = c.name;
  return function(p) {
    var z = defineComponent({ compatConfig: { MODE: 3 }, name: k, props: Me(), setup: function(F, A) {
      var _ = A.slots, B = ke(a, F), i = B.prefixCls;
      return function() {
        var s = v(v({}, F), {}, { prefixCls: i.value, tagName: y });
        return createVNode(p, s, _);
      };
    } });
    return z;
  };
}
var He = defineComponent({ compatConfig: { MODE: 3 }, props: Me(), setup: function(a, y) {
  var k = y.slots;
  return function() {
    return createVNode(a.tagName, { class: a.prefixCls }, k);
  };
} }), Gt = defineComponent({ compatConfig: { MODE: 3 }, props: Me(), setup: function(a, y) {
  var k = y.slots, p = ke("", a), z = p.direction, E = ref([]), F = { addSider: function(B) {
    E.value = [].concat(fe(E.value), [B]);
  }, removeSider: function(B) {
    E.value = E.value.filter(function(i) {
      return i !== B;
    });
  } };
  provide(or, F);
  var A = computed(function() {
    var _, B = a.prefixCls, i = a.hasSider;
    return _ = {}, x(_, "".concat(B), true), x(_, "".concat(B, "-has-sider"), typeof i == "boolean" ? i : E.value.length > 0), x(_, "".concat(B, "-rtl"), z.value === "rtl"), _;
  });
  return function() {
    var _ = a.tagName;
    return createVNode(_, { class: A.value }, k);
  };
} }), Ut = $e({ suffixCls: "layout", tagName: "section", name: "ALayout" })(Gt), be = $e({ suffixCls: "layout-header", tagName: "header", name: "ALayoutHeader" })(He), Pe = $e({ suffixCls: "layout-footer", tagName: "footer", name: "ALayoutFooter" })(He), ze = $e({ suffixCls: "layout-content", tagName: "main", name: "ALayoutContent" })(He);
const Ne = Ut;
var Kt = function() {
  return { prefixCls: String, collapsible: { type: Boolean, default: void 0 }, collapsed: { type: Boolean, default: void 0 }, defaultCollapsed: { type: Boolean, default: void 0 }, reverseArrow: { type: Boolean, default: void 0 }, zeroWidthTriggerStyle: { type: Object, default: void 0 }, trigger: pt.any, width: pt.oneOfType([pt.number, pt.string]), collapsedWidth: pt.oneOfType([pt.number, pt.string]), breakpoint: pt.oneOf(Eo("xs", "sm", "md", "lg", "xl", "xxl", "xxxl")), theme: pt.oneOf(Eo("light", "dark")).def("dark"), onBreakpoint: Function, onCollapse: Function };
}, Xt = function() {
  var c = 0;
  return function() {
    var a = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
    return c += 1, "".concat(a).concat(c);
  };
}();
const Te = defineComponent({ compatConfig: { MODE: 3 }, name: "ALayoutSider", inheritAttrs: false, props: bt(Kt(), { collapsible: false, defaultCollapsed: false, reverseArrow: false, width: 200, collapsedWidth: 80 }), emits: ["breakpoint", "update:collapsed", "collapse"], setup: function(a, y) {
  var k = y.emit, p = y.attrs, z = y.slots, E = ke("layout-sider", a), F = E.prefixCls, A = inject(or, void 0), _ = ref(!!(a.collapsed !== void 0 ? a.collapsed : a.defaultCollapsed)), B = ref(false);
  watch(function() {
    return a.collapsed;
  }, function() {
    _.value = !!a.collapsed;
  }), provide(ia$1, _);
  var i = function(v, P) {
    a.collapsed === void 0 && (_.value = v), k("update:collapsed", v), k("collapse", v, P);
  };
  ref(function(S) {
    B.value = S.matches, k("breakpoint", S.matches), _.value !== S.matches && i(S.matches, "responsive");
  });
  var s = Xt("ant-sider-");
  A && A.addSider(s);
  var n = function() {
    i(!_.value, "clickTrigger");
  };
  return function() {
    var S, v$1, P, g = F.value, T = a.collapsedWidth, m = a.width, f = a.reverseArrow, h = a.zeroWidthTriggerStyle, d = a.trigger, N = d === void 0 ? (S = z.trigger) === null || S === void 0 ? void 0 : S.call(z) : d, D = a.collapsible, X = a.theme, V = _.value ? T : m, r = Dt(V) ? "".concat(V, "px") : String(V), $ = parseFloat(String(T || 0)) === 0 ? createVNode("span", { onClick: n, class: pe("".concat(g, "-zero-width-trigger"), "".concat(g, "-zero-width-trigger-").concat(f ? "right" : "left")), style: h }, [N || createVNode(Mt, null, null)]) : null, I = { expanded: f ? createVNode(Xe, null, null) : createVNode(Je, null, null), collapsed: f ? createVNode(Je, null, null) : createVNode(Xe, null, null) }, R = _.value ? "collapsed" : "expanded", M = I[R], H = N !== null ? $ || createVNode("div", { class: "".concat(g, "-trigger"), onClick: n, style: { width: r } }, [N || M]) : null, me = [p.style, { flex: "0 0 ".concat(r), maxWidth: r, minWidth: r, width: r }], pe$1 = pe(g, "".concat(g, "-").concat(X), (v$1 = {}, x(v$1, "".concat(g, "-collapsed"), !!_.value), x(v$1, "".concat(g, "-has-trigger"), D && N !== null && !$), x(v$1, "".concat(g, "-below"), !!B.value), x(v$1, "".concat(g, "-zero-width"), parseFloat(r) === 0), v$1), p.class);
    return createVNode("aside", v(v({}, p), {}, { class: pe$1, style: me }), [createVNode("div", { class: "".concat(g, "-children") }, [(P = z.default) === null || P === void 0 ? void 0 : P.call(z)]), D || B.value && $ ? H : null]);
  };
} });
var Jt = be, bl = ze;
const zl = ce(Ne, { Header: be, Footer: Pe, Content: ze, Sider: Te, install: function(a) {
  return a.component(Ne.name, Ne), a.component(be.name, be), a.component(Pe.name, Pe), a.component(Te.name, Te), a.component(ze.name, ze), a;
} }), Qt = { viewBox: "0 0 24 24", width: "1.2em", height: "1.2em" }, Yt = createElementVNode("path", { fill: "currentColor", d: "M22 2s-7.64-.37-13.66 7.88C3.72 16.21 2 22 2 22l1.94-1c1.44-2.5 2.19-3.53 3.6-5c2.53.74 5.17.65 7.46-2c-2-.56-3.6-.43-5.96-.19C11.69 12 13.5 11.6 16 12l1-2c-1.8-.34-3-.37-4.78.04C14.19 8.65 15.56 7.87 18 8l1.21-1.93c-1.56-.11-2.5.06-4.29.5c1.61-1.46 3.08-2.12 5.22-2.25c0 0 1.05-1.89 1.86-2.32Z" }, null, -1), qt = [Yt];
function ea(c, a) {
  return openBlock(), createElementBlock("svg", Qt, qt);
}
const ta = { name: "mdi-feather", render: ea }, aa = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, la = createElementVNode("path", { fill: "currentColor", d: "M868 732h-70.3c-4.8 0-9.3 2.1-12.3 5.8c-7 8.5-14.5 16.7-22.4 24.5a353.84 353.84 0 0 1-112.7 75.9A352.8 352.8 0 0 1 512.4 866c-47.9 0-94.3-9.4-137.9-27.8a353.84 353.84 0 0 1-112.7-75.9a353.28 353.28 0 0 1-76-112.5C167.3 606.2 158 559.9 158 512s9.4-94.2 27.8-137.8c17.8-42.1 43.4-80 76-112.5s70.5-58.1 112.7-75.9c43.6-18.4 90-27.8 137.9-27.8c47.9 0 94.3 9.3 137.9 27.8c42.2 17.8 80.1 43.4 112.7 75.9c7.9 7.9 15.3 16.1 22.4 24.5c3 3.7 7.6 5.8 12.3 5.8H868c6.3 0 10.2-7 6.7-12.3C798 160.5 663.8 81.6 511.3 82C271.7 82.6 79.6 277.1 82 516.4C84.4 751.9 276.2 942 512.4 942c152.1 0 285.7-78.8 362.3-197.7c3.4-5.3-.4-12.3-6.7-12.3zm88.9-226.3L815 393.7c-5.3-4.2-13-.4-13 6.3v76H488c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h314v76c0 6.7 7.8 10.5 13 6.3l141.9-112a8 8 0 0 0 0-12.6z" }, null, -1), na = [la];
function sa(c, a) {
  return openBlock(), createElementBlock("svg", aa, na);
}
const ra = { name: "ant-design-logout-outlined", render: sa }, oa = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, ia = createElementVNode("path", { fill: "currentColor", d: "M600.704 64a32 32 0 0 1 30.464 22.208l35.2 109.376c14.784 7.232 28.928 15.36 42.432 24.512l112.384-24.192a32 32 0 0 1 34.432 15.36L944.32 364.8a32 32 0 0 1-4.032 37.504l-77.12 85.12a357.12 357.12 0 0 1 0 49.024l77.12 85.248a32 32 0 0 1 4.032 37.504l-88.704 153.6a32 32 0 0 1-34.432 15.296L708.8 803.904c-13.44 9.088-27.648 17.28-42.368 24.512l-35.264 109.376A32 32 0 0 1 600.704 960H423.296a32 32 0 0 1-30.464-22.208L357.696 828.48a351.616 351.616 0 0 1-42.56-24.64l-112.32 24.256a32 32 0 0 1-34.432-15.36L79.68 659.2a32 32 0 0 1 4.032-37.504l77.12-85.248a357.12 357.12 0 0 1 0-48.896l-77.12-85.248A32 32 0 0 1 79.68 364.8l88.704-153.6a32 32 0 0 1 34.432-15.296l112.32 24.256c13.568-9.152 27.776-17.408 42.56-24.64l35.2-109.312A32 32 0 0 1 423.232 64H600.64zm-23.424 64H446.72l-36.352 113.088l-24.512 11.968a294.113 294.113 0 0 0-34.816 20.096l-22.656 15.36l-116.224-25.088l-65.28 113.152l79.68 88.192l-1.92 27.136a293.12 293.12 0 0 0 0 40.192l1.92 27.136l-79.808 88.192l65.344 113.152l116.224-25.024l22.656 15.296a294.113 294.113 0 0 0 34.816 20.096l24.512 11.968L446.72 896h130.688l36.48-113.152l24.448-11.904a288.282 288.282 0 0 0 34.752-20.096l22.592-15.296l116.288 25.024l65.28-113.152l-79.744-88.192l1.92-27.136a293.12 293.12 0 0 0 0-40.256l-1.92-27.136l79.808-88.128l-65.344-113.152l-116.288 24.96l-22.592-15.232a287.616 287.616 0 0 0-34.752-20.096l-24.448-11.904L577.344 128zM512 320a192 192 0 1 1 0 384a192 192 0 0 1 0-384zm0 64a128 128 0 1 0 0 256a128 128 0 0 0 0-256z" }, null, -1), ua = [ia];
function ca(c, a) {
  return openBlock(), createElementBlock("svg", oa, ua);
}
const da = { name: "ep-setting", render: ca }, fa = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, _a = createElementVNode("path", { fill: "currentColor", d: "M256 128v698.88l196.032-156.864a96 96 0 0 1 119.936 0L768 826.816V128H256zm-32-64h576a32 32 0 0 1 32 32v797.44a32 32 0 0 1-51.968 24.96L531.968 720a32 32 0 0 0-39.936 0L243.968 918.4A32 32 0 0 1 192 893.44V96a32 32 0 0 1 32-32z" }, null, -1), va = [_a];
function ma(c, a) {
  return openBlock(), createElementBlock("svg", fa, va);
}
const pa = { name: "ep-collection-tag", render: ma }, ga = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, ha = createElementVNode("path", { fill: "currentColor", d: "M858.5 763.6a374 374 0 0 0-80.6-119.5a375.63 375.63 0 0 0-119.5-80.6c-.4-.2-.8-.3-1.2-.5C719.5 518 760 444.7 760 362c0-137-111-248-248-248S264 225 264 362c0 82.7 40.5 156 102.8 201.1c-.4.2-.8.3-1.2.5c-44.8 18.9-85 46-119.5 80.6a375.63 375.63 0 0 0-80.6 119.5A371.7 371.7 0 0 0 136 901.8a8 8 0 0 0 8 8.2h60c4.4 0 7.9-3.5 8-7.8c2-77.2 33-149.5 87.8-204.3c56.7-56.7 132-87.9 212.2-87.9s155.5 31.2 212.2 87.9C779 752.7 810 825 812 902.2c.1 4.4 3.6 7.8 8 7.8h60a8 8 0 0 0 8-8.2c-1-47.8-10.9-94.3-29.5-138.2zM512 534c-45.9 0-89.1-17.9-121.6-50.4S340 407.9 340 362c0-45.9 17.9-89.1 50.4-121.6S466.1 190 512 190s89.1 17.9 121.6 50.4S684 316.1 684 362c0 45.9-17.9 89.1-50.4 121.6S557.9 534 512 534z" }, null, -1), xa = [ha];
function ya(c, a) {
  return openBlock(), createElementBlock("svg", ga, xa);
}
const Ca = { name: "ant-design-user-outlined", render: ya }, ka = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, ba = createElementVNode("path", { fill: "currentColor", d: "M840.4 300H183.6c-19.7 0-30.7 20.8-18.5 35l328.4 380.8c9.4 10.9 27.5 10.9 37 0L858.9 335c12.2-14.2 1.2-35-18.5-35z" }, null, -1), za = [ba];
function $a(c, a) {
  return openBlock(), createElementBlock("svg", ka, za);
}
const Sa = { name: "ant-design-caret-down-filled", render: $a };
const wa = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, La = createElementVNode("path", { fill: "currentColor", d: "m795.904 750.72l124.992 124.928a32 32 0 0 1-45.248 45.248L750.656 795.904a416 416 0 1 1 45.248-45.248zM480 832a352 352 0 1 0 0-704a352 352 0 0 0 0 704z" }, null, -1), Aa = [La];
function Ba(c, a) {
  return openBlock(), createElementBlock("svg", wa, Aa);
}
const Pa = { name: "ep-search", render: Ba }, Na = { viewBox: "0 0 24 24", width: "1.2em", height: "1.2em" }, Ta = createElementVNode("path", { fill: "currentColor", d: "M10 21h4a2 2 0 0 1-2 2a2 2 0 0 1-2-2m11-2v1H3v-1l2-2v-6c0-3.1 2.03-5.83 5-6.71V4a2 2 0 0 1 2-2a2 2 0 0 1 2 2v.29c2.97.88 5 3.61 5 6.71v6l2 2m-4-8a5 5 0 0 0-5-5a5 5 0 0 0-5 5v7h10v-7m2.75-7.81l-1.42 1.42A8.982 8.982 0 0 1 21 11h2c0-2.93-1.16-5.75-3.25-7.81M1 11h2c0-2.4.96-4.7 2.67-6.39L4.25 3.19A10.96 10.96 0 0 0 1 11Z" }, null, -1), ja = [Ta];
function Ea(c, a) {
  return openBlock(), createElementBlock("svg", Na, ja);
}
const Ma = { name: "mdi-bell-ring-outline", render: Ea }, Ha = { viewBox: "0 0 24 24", width: "1.2em", height: "1.2em" }, Oa = createElementVNode("path", { fill: "currentColor", d: "M14 2H6a2 2 0 0 0-2 2v16c0 1.11.89 2 2 2h12c1.11 0 2-.89 2-2V8l-6-6m4 18H6V4h7v5h5v11m-8.46-4.35l2.09 2.09L10.35 19L7 15.65l3.35-3.35l1.28 1.26l-2.09 2.09m7.46 0L13.65 19l-1.27-1.26l2.09-2.09l-2.09-2.09l1.27-1.26L17 15.65Z" }, null, -1), Wa = [Oa];
function Ia(c, a) {
  return openBlock(), createElementBlock("svg", Ha, Wa);
}
const Ra = { name: "mdi-file-code-outline", render: Ia }, Fa = { viewBox: "0 0 24 24", width: "1.2em", height: "1.2em" }, Va = createElementVNode("path", { fill: "currentColor", d: "M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5m14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1Z" }, null, -1), Za = [Va];
function Da(c, a) {
  return openBlock(), createElementBlock("svg", Fa, Za);
}
const Ga = { name: "mdi-crown", render: Da }, Ua = { viewBox: "0 0 256 256", width: "1.2em", height: "1.2em" }, Ka = createElementVNode("path", { fill: "currentColor", d: "M224 48h-64a40 40 0 0 0-32 16a40 40 0 0 0-32-16H32a16 16 0 0 0-16 16v128a16 16 0 0 0 16 16h64a24 24 0 0 1 24 24a8 8 0 0 0 16 0a24 24 0 0 1 24-24h64a16 16 0 0 0 16-16V64a16 16 0 0 0-16-16ZM96 192H32V64h64a24 24 0 0 1 24 24v112a39.81 39.81 0 0 0-24-8Zm128 0h-64a39.81 39.81 0 0 0-24 8V88a24 24 0 0 1 24-24h64ZM160 88h40a8 8 0 0 1 0 16h-40a8 8 0 0 1 0-16Zm48 40a8 8 0 0 1-8 8h-40a8 8 0 0 1 0-16h40a8 8 0 0 1 8 8Zm0 32a8 8 0 0 1-8 8h-40a8 8 0 0 1 0-16h40a8 8 0 0 1 8 8Z" }, null, -1), Xa = [Ka];
function Ja(c, a) {
  return openBlock(), createElementBlock("svg", Ua, Xa);
}
const Qa = { name: "ph-book-open-text", render: Ja }, Ya = { viewBox: "0 0 24 24", width: "1.2em", height: "1.2em" }, qa = createElementVNode("path", { fill: "currentColor", d: "m7 17l3.2-6.8L17 7l-3.2 6.8L7 17m5-5.9a.9.9 0 0 0-.9.9a.9.9 0 0 0 .9.9a.9.9 0 0 0 .9-.9a.9.9 0 0 0-.9-.9M12 2a10 10 0 0 1 10 10a10 10 0 0 1-10 10A10 10 0 0 1 2 12A10 10 0 0 1 12 2m0 2a8 8 0 0 0-8 8a8 8 0 0 0 8 8a8 8 0 0 0 8-8a8 8 0 0 0-8-8Z" }, null, -1), el = [qa];
function tl(c, a) {
  return openBlock(), createElementBlock("svg", Ya, el);
}
const al = { name: "mdi-compass-outline", render: tl };
const Oe = defineComponent({ __name: "NavBar", __ssrInlineRender: true, setup(c) {
  const a = lr().value, y = () => {
    Br("/note/writer");
  }, k = () => {
    const E = it("userInfo");
    E.value = "", window.location.reload();
  }, p = () => {
    Br("/sign_in");
  }, z = () => {
    Br("/sign_up");
  };
  return (E, F, A, _) => {
    const B = Jt, i = ei, s = ti, n = V, S = al, v = Qa, P = Ga, g = Ra, T = Ma, m = oi, f = Xo, h = Pa, d = Jo, N = Le, D = ge, X = Sa, V$1 = _e, r = nn, $ = Ca, I = pa, R = da, M = ra, H = ta;
    F(ssrRenderComponent(B, mergeProps({ class: "header" }, _), { default: withCtx((me, pe, Se, We) => {
      if (pe)
        pe(ssrRenderComponent(i, { type: "flex", justify: "center" }, { default: withCtx((ll, Ie, at, lt) => {
          if (Ie)
            Ie(ssrRenderComponent(s, { span: 19 }, { default: withCtx((nl, Re, nt, st) => {
              if (Re)
                Re(ssrRenderComponent(i, { type: "flex", justify: "space-between" }, { default: withCtx((sl, Ce, we, Le) => {
                  if (Ce)
                    Ce(ssrRenderComponent(s, { span: 4 }, { default: withCtx((Fe, oe, he, xe) => {
                      if (oe)
                        oe(ssrRenderComponent(n, { to: "/" }, { default: withCtx((Ve, G, te, q) => {
                          if (G)
                            G(`<img class="logo" alt="logo"${ssrRenderAttr("src", Q$1)} data-v-3f133fe9${q}>`);
                          else
                            return [createVNode("img", { class: "logo", alt: "logo", src: Q$1 })];
                        }), _: 1 }, he, xe));
                      else
                        return [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode("img", { class: "logo", alt: "logo", src: Q$1 })]), _: 1 })];
                    }), _: 1 }, we, Le)), Ce(ssrRenderComponent(s, { span: 15 }, { default: withCtx((Fe, oe, he, xe) => {
                      if (oe)
                        oe(ssrRenderComponent(i, { type: "flex", align: "middle" }, { default: withCtx((Ve, G, te, q) => {
                          if (G)
                            G(ssrRenderComponent(s, { span: 3, class: "nav-item" }, { default: withCtx((ue, C, O, j) => {
                              if (C)
                                C(ssrRenderComponent(n, { to: "/", class: "active" }, { default: withCtx((ae, u, L, w) => {
                                  if (u)
                                    u(ssrRenderComponent(S, null, null, L, w)), u(" \u53D1\u73B0");
                                  else
                                    return [createVNode(S), createTextVNode(" \u53D1\u73B0")];
                                }), _: 1 }, O, j));
                              else
                                return [createVNode(n, { to: "/", class: "active" }, { default: withCtx(() => [createVNode(S), createTextVNode(" \u53D1\u73B0")]), _: 1 })];
                            }), _: 1 }, te, q)), G(ssrRenderComponent(s, { span: 3, class: "nav-item" }, { default: withCtx((ue, C, O, j) => {
                              if (C)
                                C(ssrRenderComponent(n, { to: "/" }, { default: withCtx((ae, u, L, w) => {
                                  if (u)
                                    u(ssrRenderComponent(v, null, null, L, w)), u(" \u5173\u6CE8");
                                  else
                                    return [createVNode(v), createTextVNode(" \u5173\u6CE8")];
                                }), _: 1 }, O, j));
                              else
                                return [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(v), createTextVNode(" \u5173\u6CE8")]), _: 1 })];
                            }), _: 1 }, te, q)), G(ssrRenderComponent(s, { span: 3, class: "nav-item" }, { default: withCtx((ue, C, O, j) => {
                              if (C)
                                C(ssrRenderComponent(n, { to: "/" }, { default: withCtx((ae, u, L, w) => {
                                  if (u)
                                    u(ssrRenderComponent(P, null, null, L, w)), u("\u4F1A\u5458");
                                  else
                                    return [createVNode(P), createTextVNode("\u4F1A\u5458")];
                                }), _: 1 }, O, j));
                              else
                                return [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(P), createTextVNode("\u4F1A\u5458")]), _: 1 })];
                            }), _: 1 }, te, q)), G(ssrRenderComponent(s, { span: 3, class: "nav-item" }, { default: withCtx((ue, C, O, j) => {
                              if (C)
                                C(ssrRenderComponent(n, { to: "/" }, { default: withCtx((ae, u, L, w) => {
                                  if (u)
                                    u(ssrRenderComponent(g, null, null, L, w)), u("IT\u6280\u672F");
                                  else
                                    return [createVNode(g), createTextVNode("IT\u6280\u672F")];
                                }), _: 1 }, O, j));
                              else
                                return [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(g), createTextVNode("IT\u6280\u672F")]), _: 1 })];
                            }), _: 1 }, te, q)), G(ssrRenderComponent(s, { span: 3, class: "nav-item" }, { default: withCtx((ue, C, O, j) => {
                              if (C)
                                C(ssrRenderComponent(n, { to: "/" }, { default: withCtx((ae, u, L, w) => {
                                  if (u)
                                    u(ssrRenderComponent(T, null, null, L, w)), u("\u6D88\u606F");
                                  else
                                    return [createVNode(T), createTextVNode("\u6D88\u606F")];
                                }), _: 1 }, O, j));
                              else
                                return [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(T), createTextVNode("\u6D88\u606F")]), _: 1 })];
                            }), _: 1 }, te, q)), G(ssrRenderComponent(s, { span: 7, class: "nav-item" }, { default: withCtx((ue, C, O, j) => {
                              if (C)
                                C(ssrRenderComponent(i, { type: "flex", class: "search-box" }, { default: withCtx((ae, u, L, w) => {
                                  if (u)
                                    u(ssrRenderComponent(m, { bordered: false, placeholder: "\u641C\u7D22" }, { suffix: withCtx((Ze, ee, ce, ie) => {
                                      if (ee)
                                        ee(ssrRenderComponent(f, { title: "Extra information" }, { default: withCtx((ke, U, se, re) => {
                                          if (U)
                                            U(ssrRenderComponent(h, null, null, se, re));
                                          else
                                            return [createVNode(h)];
                                        }), _: 1 }, ce, ie));
                                      else
                                        return [createVNode(f, { title: "Extra information" }, { default: withCtx(() => [createVNode(h)]), _: 1 })];
                                    }), _: 1 }, L, w));
                                  else
                                    return [createVNode(m, { bordered: false, placeholder: "\u641C\u7D22" }, { suffix: withCtx(() => [createVNode(f, { title: "Extra information" }, { default: withCtx(() => [createVNode(h)]), _: 1 })]), _: 1 })];
                                }), _: 1 }, O, j));
                              else
                                return [createVNode(i, { type: "flex", class: "search-box" }, { default: withCtx(() => [createVNode(m, { bordered: false, placeholder: "\u641C\u7D22" }, { suffix: withCtx(() => [createVNode(f, { title: "Extra information" }, { default: withCtx(() => [createVNode(h)]), _: 1 })]), _: 1 })]), _: 1 })];
                            }), _: 1 }, te, q));
                          else
                            return [createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/", class: "active" }, { default: withCtx(() => [createVNode(S), createTextVNode(" \u53D1\u73B0")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(v), createTextVNode(" \u5173\u6CE8")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(P), createTextVNode("\u4F1A\u5458")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(g), createTextVNode("IT\u6280\u672F")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(T), createTextVNode("\u6D88\u606F")]), _: 1 })]), _: 1 }), createVNode(s, { span: 7, class: "nav-item" }, { default: withCtx(() => [createVNode(i, { type: "flex", class: "search-box" }, { default: withCtx(() => [createVNode(m, { bordered: false, placeholder: "\u641C\u7D22" }, { suffix: withCtx(() => [createVNode(f, { title: "Extra information" }, { default: withCtx(() => [createVNode(h)]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })];
                        }), _: 1 }, he, xe));
                      else
                        return [createVNode(i, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/", class: "active" }, { default: withCtx(() => [createVNode(S), createTextVNode(" \u53D1\u73B0")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(v), createTextVNode(" \u5173\u6CE8")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(P), createTextVNode("\u4F1A\u5458")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(g), createTextVNode("IT\u6280\u672F")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(T), createTextVNode("\u6D88\u606F")]), _: 1 })]), _: 1 }), createVNode(s, { span: 7, class: "nav-item" }, { default: withCtx(() => [createVNode(i, { type: "flex", class: "search-box" }, { default: withCtx(() => [createVNode(m, { bordered: false, placeholder: "\u641C\u7D22" }, { suffix: withCtx(() => [createVNode(f, { title: "Extra information" }, { default: withCtx(() => [createVNode(h)]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })];
                    }), _: 1 }, we, Le)), Ce(ssrRenderComponent(s, { span: 5 }, { default: withCtx((Fe, oe, he, xe) => {
                      if (oe)
                        oe(ssrRenderComponent(i, { type: "flex", justify: "space-around" }, { default: withCtx((Ve, G, te, q) => {
                          if (G)
                            G(ssrRenderComponent(s, null, { default: withCtx((ue, C, O, j) => {
                              if (C)
                                unref(a) ? C(ssrRenderComponent(N, null, { overlay: withCtx((ae, u, L, w) => {
                                  if (u)
                                    u(ssrRenderComponent(V$1, null, { default: withCtx((Ze, ee, ce, ie) => {
                                      if (ee)
                                        ee(ssrRenderComponent(r, null, { default: withCtx((ke, U, se, re) => {
                                          if (U)
                                            U(ssrRenderComponent(n, { class: "select-user" }, { default: withCtx((Ae, Z, de, fe) => {
                                              if (Z)
                                                Z(ssrRenderComponent($, null, null, de, fe)), Z(" \u6211\u7684\u4E3B\u9875");
                                              else
                                                return [createVNode($), createTextVNode(" \u6211\u7684\u4E3B\u9875")];
                                            }), _: 1 }, se, re));
                                          else
                                            return [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode($), createTextVNode(" \u6211\u7684\u4E3B\u9875")]), _: 1 })];
                                        }), _: 1 }, ce, ie)), ee(ssrRenderComponent(r, null, { default: withCtx((ke, U, se, re) => {
                                          if (U)
                                            U(ssrRenderComponent(n, { class: "select-user" }, { default: withCtx((Ae, Z, de, fe) => {
                                              if (Z)
                                                Z(ssrRenderComponent(I, null, null, de, fe)), Z(" \u6536\u85CF\u6587\u7AE0");
                                              else
                                                return [createVNode(I), createTextVNode(" \u6536\u85CF\u6587\u7AE0")];
                                            }), _: 1 }, se, re));
                                          else
                                            return [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(I), createTextVNode(" \u6536\u85CF\u6587\u7AE0")]), _: 1 })];
                                        }), _: 1 }, ce, ie)), ee(ssrRenderComponent(r, null, { default: withCtx((ke, U, se, re) => {
                                          if (U)
                                            U(ssrRenderComponent(n, { to: "/user/settings", class: "select-user" }, { default: withCtx((Ae, Z, de, fe) => {
                                              if (Z)
                                                Z(ssrRenderComponent(R, null, null, de, fe)), Z(" \u8BBE\u7F6E");
                                              else
                                                return [createVNode(R), createTextVNode(" \u8BBE\u7F6E")];
                                            }), _: 1 }, se, re));
                                          else
                                            return [createVNode(n, { to: "/user/settings", class: "select-user" }, { default: withCtx(() => [createVNode(R), createTextVNode(" \u8BBE\u7F6E")]), _: 1 })];
                                        }), _: 1 }, ce, ie)), ee(ssrRenderComponent(r, { onClick: k }, { default: withCtx((ke, U, se, re) => {
                                          if (U)
                                            U(ssrRenderComponent(n, { class: "select-user" }, { default: withCtx((Ae, Z, de, fe) => {
                                              if (Z)
                                                Z(ssrRenderComponent(M, null, null, de, fe)), Z(" \u9000\u51FA");
                                              else
                                                return [createVNode(M), createTextVNode(" \u9000\u51FA")];
                                            }), _: 1 }, se, re));
                                          else
                                            return [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(M), createTextVNode(" \u9000\u51FA")]), _: 1 })];
                                        }), _: 1 }, ce, ie));
                                      else
                                        return [createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode($), createTextVNode(" \u6211\u7684\u4E3B\u9875")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(I), createTextVNode(" \u6536\u85CF\u6587\u7AE0")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { to: "/user/settings", class: "select-user" }, { default: withCtx(() => [createVNode(R), createTextVNode(" \u8BBE\u7F6E")]), _: 1 })]), _: 1 }), createVNode(r, { onClick: k }, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(M), createTextVNode(" \u9000\u51FA")]), _: 1 })]), _: 1 })];
                                    }), _: 1 }, L, w));
                                  else
                                    return [createVNode(V$1, null, { default: withCtx(() => [createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode($), createTextVNode(" \u6211\u7684\u4E3B\u9875")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(I), createTextVNode(" \u6536\u85CF\u6587\u7AE0")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { to: "/user/settings", class: "select-user" }, { default: withCtx(() => [createVNode(R), createTextVNode(" \u8BBE\u7F6E")]), _: 1 })]), _: 1 }), createVNode(r, { onClick: k }, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(M), createTextVNode(" \u9000\u51FA")]), _: 1 })]), _: 1 })]), _: 1 })];
                                }), default: withCtx((ae, u, L, w) => {
                                  if (u)
                                    u(`<div class="avatar" data-v-3f133fe9${w}>`), u(ssrRenderComponent(D, { size: 40 }, { icon: withCtx((Ze, ee, ce, ie) => {
                                      if (ee)
                                        ee(`<img${ssrRenderAttr("src", unref(a) ? unref(a).avatar : "/images/default-avatar.png")} alt="avatar" data-v-3f133fe9${ie}>`);
                                      else
                                        return [createVNode("img", { src: unref(a) ? unref(a).avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])];
                                    }), _: 1 }, L, w)), u(ssrRenderComponent(X, null, null, L, w)), u("</div>");
                                  else
                                    return [createVNode("div", { class: "avatar" }, [createVNode(D, { size: 40 }, { icon: withCtx(() => [createVNode("img", { src: unref(a) ? unref(a).avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 }), createVNode(X)])];
                                }), _: 1 }, O, j)) : (C(`<div data-v-3f133fe9${j}>`), C(ssrRenderComponent(d, { onClick: p, type: "text" }, { default: withCtx((ae, u, L, w) => {
                                  if (u)
                                    u("\u767B\u5F55");
                                  else
                                    return [createTextVNode("\u767B\u5F55")];
                                }), _: 1 }, O, j)), C(ssrRenderComponent(d, { onClick: z, shape: "round", ghost: "", type: "primary" }, { default: withCtx((ae, u, L, w) => {
                                  if (u)
                                    u("\u6CE8\u518C");
                                  else
                                    return [createTextVNode("\u6CE8\u518C")];
                                }), _: 1 }, O, j)), C("</div>"));
                              else
                                return [unref(a) ? (openBlock(), createBlock(N, { key: 1 }, { overlay: withCtx(() => [createVNode(V$1, null, { default: withCtx(() => [createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode($), createTextVNode(" \u6211\u7684\u4E3B\u9875")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(I), createTextVNode(" \u6536\u85CF\u6587\u7AE0")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { to: "/user/settings", class: "select-user" }, { default: withCtx(() => [createVNode(R), createTextVNode(" \u8BBE\u7F6E")]), _: 1 })]), _: 1 }), createVNode(r, { onClick: k }, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(M), createTextVNode(" \u9000\u51FA")]), _: 1 })]), _: 1 })]), _: 1 })]), default: withCtx(() => [createVNode("div", { class: "avatar" }, [createVNode(D, { size: 40 }, { icon: withCtx(() => [createVNode("img", { src: unref(a) ? unref(a).avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 }), createVNode(X)])]), _: 1 })) : (openBlock(), createBlock("div", { key: 0 }, [createVNode(d, { onClick: p, type: "text" }, { default: withCtx(() => [createTextVNode("\u767B\u5F55")]), _: 1 }), createVNode(d, { onClick: z, shape: "round", ghost: "", type: "primary" }, { default: withCtx(() => [createTextVNode("\u6CE8\u518C")]), _: 1 })]))];
                            }), _: 1 }, te, q)), G(ssrRenderComponent(s, null, { default: withCtx((ue, C, O, j) => {
                              if (C)
                                C(ssrRenderComponent(d, { onClick: y, shape: "round", type: "primary", style: { height: "40px", "font-size": "16px" } }, { default: withCtx((ae, u, L, w) => {
                                  if (u)
                                    u(ssrRenderComponent(H, { style: { "margin-right": "4px", "font-size": "16px", "vertical-align": "middle" } }, null, L, w)), u(" \u5199\u6587\u7AE0 ");
                                  else
                                    return [createVNode(H, { style: { "margin-right": "4px", "font-size": "16px", "vertical-align": "middle" } }), createTextVNode(" \u5199\u6587\u7AE0 ")];
                                }), _: 1 }, O, j));
                              else
                                return [createVNode(d, { onClick: y, shape: "round", type: "primary", style: { height: "40px", "font-size": "16px" } }, { default: withCtx(() => [createVNode(H, { style: { "margin-right": "4px", "font-size": "16px", "vertical-align": "middle" } }), createTextVNode(" \u5199\u6587\u7AE0 ")]), _: 1 })];
                            }), _: 1 }, te, q));
                          else
                            return [createVNode(s, null, { default: withCtx(() => [unref(a) ? (openBlock(), createBlock(N, { key: 1 }, { overlay: withCtx(() => [createVNode(V$1, null, { default: withCtx(() => [createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode($), createTextVNode(" \u6211\u7684\u4E3B\u9875")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(I), createTextVNode(" \u6536\u85CF\u6587\u7AE0")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { to: "/user/settings", class: "select-user" }, { default: withCtx(() => [createVNode(R), createTextVNode(" \u8BBE\u7F6E")]), _: 1 })]), _: 1 }), createVNode(r, { onClick: k }, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(M), createTextVNode(" \u9000\u51FA")]), _: 1 })]), _: 1 })]), _: 1 })]), default: withCtx(() => [createVNode("div", { class: "avatar" }, [createVNode(D, { size: 40 }, { icon: withCtx(() => [createVNode("img", { src: unref(a) ? unref(a).avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 }), createVNode(X)])]), _: 1 })) : (openBlock(), createBlock("div", { key: 0 }, [createVNode(d, { onClick: p, type: "text" }, { default: withCtx(() => [createTextVNode("\u767B\u5F55")]), _: 1 }), createVNode(d, { onClick: z, shape: "round", ghost: "", type: "primary" }, { default: withCtx(() => [createTextVNode("\u6CE8\u518C")]), _: 1 })]))]), _: 1 }), createVNode(s, null, { default: withCtx(() => [createVNode(d, { onClick: y, shape: "round", type: "primary", style: { height: "40px", "font-size": "16px" } }, { default: withCtx(() => [createVNode(H, { style: { "margin-right": "4px", "font-size": "16px", "vertical-align": "middle" } }), createTextVNode(" \u5199\u6587\u7AE0 ")]), _: 1 })]), _: 1 })];
                        }), _: 1 }, he, xe));
                      else
                        return [createVNode(i, { type: "flex", justify: "space-around" }, { default: withCtx(() => [createVNode(s, null, { default: withCtx(() => [unref(a) ? (openBlock(), createBlock(N, { key: 1 }, { overlay: withCtx(() => [createVNode(V$1, null, { default: withCtx(() => [createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode($), createTextVNode(" \u6211\u7684\u4E3B\u9875")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(I), createTextVNode(" \u6536\u85CF\u6587\u7AE0")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { to: "/user/settings", class: "select-user" }, { default: withCtx(() => [createVNode(R), createTextVNode(" \u8BBE\u7F6E")]), _: 1 })]), _: 1 }), createVNode(r, { onClick: k }, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(M), createTextVNode(" \u9000\u51FA")]), _: 1 })]), _: 1 })]), _: 1 })]), default: withCtx(() => [createVNode("div", { class: "avatar" }, [createVNode(D, { size: 40 }, { icon: withCtx(() => [createVNode("img", { src: unref(a) ? unref(a).avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 }), createVNode(X)])]), _: 1 })) : (openBlock(), createBlock("div", { key: 0 }, [createVNode(d, { onClick: p, type: "text" }, { default: withCtx(() => [createTextVNode("\u767B\u5F55")]), _: 1 }), createVNode(d, { onClick: z, shape: "round", ghost: "", type: "primary" }, { default: withCtx(() => [createTextVNode("\u6CE8\u518C")]), _: 1 })]))]), _: 1 }), createVNode(s, null, { default: withCtx(() => [createVNode(d, { onClick: y, shape: "round", type: "primary", style: { height: "40px", "font-size": "16px" } }, { default: withCtx(() => [createVNode(H, { style: { "margin-right": "4px", "font-size": "16px", "vertical-align": "middle" } }), createTextVNode(" \u5199\u6587\u7AE0 ")]), _: 1 })]), _: 1 })]), _: 1 })];
                    }), _: 1 }, we, Le));
                  else
                    return [createVNode(s, { span: 4 }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode("img", { class: "logo", alt: "logo", src: Q$1 })]), _: 1 })]), _: 1 }), createVNode(s, { span: 15 }, { default: withCtx(() => [createVNode(i, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/", class: "active" }, { default: withCtx(() => [createVNode(S), createTextVNode(" \u53D1\u73B0")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(v), createTextVNode(" \u5173\u6CE8")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(P), createTextVNode("\u4F1A\u5458")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(g), createTextVNode("IT\u6280\u672F")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(T), createTextVNode("\u6D88\u606F")]), _: 1 })]), _: 1 }), createVNode(s, { span: 7, class: "nav-item" }, { default: withCtx(() => [createVNode(i, { type: "flex", class: "search-box" }, { default: withCtx(() => [createVNode(m, { bordered: false, placeholder: "\u641C\u7D22" }, { suffix: withCtx(() => [createVNode(f, { title: "Extra information" }, { default: withCtx(() => [createVNode(h)]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 }), createVNode(s, { span: 5 }, { default: withCtx(() => [createVNode(i, { type: "flex", justify: "space-around" }, { default: withCtx(() => [createVNode(s, null, { default: withCtx(() => [unref(a) ? (openBlock(), createBlock(N, { key: 1 }, { overlay: withCtx(() => [createVNode(V$1, null, { default: withCtx(() => [createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode($), createTextVNode(" \u6211\u7684\u4E3B\u9875")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(I), createTextVNode(" \u6536\u85CF\u6587\u7AE0")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { to: "/user/settings", class: "select-user" }, { default: withCtx(() => [createVNode(R), createTextVNode(" \u8BBE\u7F6E")]), _: 1 })]), _: 1 }), createVNode(r, { onClick: k }, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(M), createTextVNode(" \u9000\u51FA")]), _: 1 })]), _: 1 })]), _: 1 })]), default: withCtx(() => [createVNode("div", { class: "avatar" }, [createVNode(D, { size: 40 }, { icon: withCtx(() => [createVNode("img", { src: unref(a) ? unref(a).avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 }), createVNode(X)])]), _: 1 })) : (openBlock(), createBlock("div", { key: 0 }, [createVNode(d, { onClick: p, type: "text" }, { default: withCtx(() => [createTextVNode("\u767B\u5F55")]), _: 1 }), createVNode(d, { onClick: z, shape: "round", ghost: "", type: "primary" }, { default: withCtx(() => [createTextVNode("\u6CE8\u518C")]), _: 1 })]))]), _: 1 }), createVNode(s, null, { default: withCtx(() => [createVNode(d, { onClick: y, shape: "round", type: "primary", style: { height: "40px", "font-size": "16px" } }, { default: withCtx(() => [createVNode(H, { style: { "margin-right": "4px", "font-size": "16px", "vertical-align": "middle" } }), createTextVNode(" \u5199\u6587\u7AE0 ")]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })];
                }), _: 1 }, nt, st));
              else
                return [createVNode(i, { type: "flex", justify: "space-between" }, { default: withCtx(() => [createVNode(s, { span: 4 }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode("img", { class: "logo", alt: "logo", src: Q$1 })]), _: 1 })]), _: 1 }), createVNode(s, { span: 15 }, { default: withCtx(() => [createVNode(i, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/", class: "active" }, { default: withCtx(() => [createVNode(S), createTextVNode(" \u53D1\u73B0")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(v), createTextVNode(" \u5173\u6CE8")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(P), createTextVNode("\u4F1A\u5458")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(g), createTextVNode("IT\u6280\u672F")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(T), createTextVNode("\u6D88\u606F")]), _: 1 })]), _: 1 }), createVNode(s, { span: 7, class: "nav-item" }, { default: withCtx(() => [createVNode(i, { type: "flex", class: "search-box" }, { default: withCtx(() => [createVNode(m, { bordered: false, placeholder: "\u641C\u7D22" }, { suffix: withCtx(() => [createVNode(f, { title: "Extra information" }, { default: withCtx(() => [createVNode(h)]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 }), createVNode(s, { span: 5 }, { default: withCtx(() => [createVNode(i, { type: "flex", justify: "space-around" }, { default: withCtx(() => [createVNode(s, null, { default: withCtx(() => [unref(a) ? (openBlock(), createBlock(N, { key: 1 }, { overlay: withCtx(() => [createVNode(V$1, null, { default: withCtx(() => [createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode($), createTextVNode(" \u6211\u7684\u4E3B\u9875")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(I), createTextVNode(" \u6536\u85CF\u6587\u7AE0")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { to: "/user/settings", class: "select-user" }, { default: withCtx(() => [createVNode(R), createTextVNode(" \u8BBE\u7F6E")]), _: 1 })]), _: 1 }), createVNode(r, { onClick: k }, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(M), createTextVNode(" \u9000\u51FA")]), _: 1 })]), _: 1 })]), _: 1 })]), default: withCtx(() => [createVNode("div", { class: "avatar" }, [createVNode(D, { size: 40 }, { icon: withCtx(() => [createVNode("img", { src: unref(a) ? unref(a).avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 }), createVNode(X)])]), _: 1 })) : (openBlock(), createBlock("div", { key: 0 }, [createVNode(d, { onClick: p, type: "text" }, { default: withCtx(() => [createTextVNode("\u767B\u5F55")]), _: 1 }), createVNode(d, { onClick: z, shape: "round", ghost: "", type: "primary" }, { default: withCtx(() => [createTextVNode("\u6CE8\u518C")]), _: 1 })]))]), _: 1 }), createVNode(s, null, { default: withCtx(() => [createVNode(d, { onClick: y, shape: "round", type: "primary", style: { height: "40px", "font-size": "16px" } }, { default: withCtx(() => [createVNode(H, { style: { "margin-right": "4px", "font-size": "16px", "vertical-align": "middle" } }), createTextVNode(" \u5199\u6587\u7AE0 ")]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })];
            }), _: 1 }, at, lt));
          else
            return [createVNode(s, { span: 19 }, { default: withCtx(() => [createVNode(i, { type: "flex", justify: "space-between" }, { default: withCtx(() => [createVNode(s, { span: 4 }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode("img", { class: "logo", alt: "logo", src: Q$1 })]), _: 1 })]), _: 1 }), createVNode(s, { span: 15 }, { default: withCtx(() => [createVNode(i, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/", class: "active" }, { default: withCtx(() => [createVNode(S), createTextVNode(" \u53D1\u73B0")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(v), createTextVNode(" \u5173\u6CE8")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(P), createTextVNode("\u4F1A\u5458")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(g), createTextVNode("IT\u6280\u672F")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(T), createTextVNode("\u6D88\u606F")]), _: 1 })]), _: 1 }), createVNode(s, { span: 7, class: "nav-item" }, { default: withCtx(() => [createVNode(i, { type: "flex", class: "search-box" }, { default: withCtx(() => [createVNode(m, { bordered: false, placeholder: "\u641C\u7D22" }, { suffix: withCtx(() => [createVNode(f, { title: "Extra information" }, { default: withCtx(() => [createVNode(h)]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 }), createVNode(s, { span: 5 }, { default: withCtx(() => [createVNode(i, { type: "flex", justify: "space-around" }, { default: withCtx(() => [createVNode(s, null, { default: withCtx(() => [unref(a) ? (openBlock(), createBlock(N, { key: 1 }, { overlay: withCtx(() => [createVNode(V$1, null, { default: withCtx(() => [createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode($), createTextVNode(" \u6211\u7684\u4E3B\u9875")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(I), createTextVNode(" \u6536\u85CF\u6587\u7AE0")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { to: "/user/settings", class: "select-user" }, { default: withCtx(() => [createVNode(R), createTextVNode(" \u8BBE\u7F6E")]), _: 1 })]), _: 1 }), createVNode(r, { onClick: k }, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(M), createTextVNode(" \u9000\u51FA")]), _: 1 })]), _: 1 })]), _: 1 })]), default: withCtx(() => [createVNode("div", { class: "avatar" }, [createVNode(D, { size: 40 }, { icon: withCtx(() => [createVNode("img", { src: unref(a) ? unref(a).avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 }), createVNode(X)])]), _: 1 })) : (openBlock(), createBlock("div", { key: 0 }, [createVNode(d, { onClick: p, type: "text" }, { default: withCtx(() => [createTextVNode("\u767B\u5F55")]), _: 1 }), createVNode(d, { onClick: z, shape: "round", ghost: "", type: "primary" }, { default: withCtx(() => [createTextVNode("\u6CE8\u518C")]), _: 1 })]))]), _: 1 }), createVNode(s, null, { default: withCtx(() => [createVNode(d, { onClick: y, shape: "round", type: "primary", style: { height: "40px", "font-size": "16px" } }, { default: withCtx(() => [createVNode(H, { style: { "margin-right": "4px", "font-size": "16px", "vertical-align": "middle" } }), createTextVNode(" \u5199\u6587\u7AE0 ")]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })];
        }), _: 1 }, Se, We));
      else
        return [createVNode(i, { type: "flex", justify: "center" }, { default: withCtx(() => [createVNode(s, { span: 19 }, { default: withCtx(() => [createVNode(i, { type: "flex", justify: "space-between" }, { default: withCtx(() => [createVNode(s, { span: 4 }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode("img", { class: "logo", alt: "logo", src: Q$1 })]), _: 1 })]), _: 1 }), createVNode(s, { span: 15 }, { default: withCtx(() => [createVNode(i, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/", class: "active" }, { default: withCtx(() => [createVNode(S), createTextVNode(" \u53D1\u73B0")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(v), createTextVNode(" \u5173\u6CE8")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(P), createTextVNode("\u4F1A\u5458")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(g), createTextVNode("IT\u6280\u672F")]), _: 1 })]), _: 1 }), createVNode(s, { span: 3, class: "nav-item" }, { default: withCtx(() => [createVNode(n, { to: "/" }, { default: withCtx(() => [createVNode(T), createTextVNode("\u6D88\u606F")]), _: 1 })]), _: 1 }), createVNode(s, { span: 7, class: "nav-item" }, { default: withCtx(() => [createVNode(i, { type: "flex", class: "search-box" }, { default: withCtx(() => [createVNode(m, { bordered: false, placeholder: "\u641C\u7D22" }, { suffix: withCtx(() => [createVNode(f, { title: "Extra information" }, { default: withCtx(() => [createVNode(h)]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 }), createVNode(s, { span: 5 }, { default: withCtx(() => [createVNode(i, { type: "flex", justify: "space-around" }, { default: withCtx(() => [createVNode(s, null, { default: withCtx(() => [unref(a) ? (openBlock(), createBlock(N, { key: 1 }, { overlay: withCtx(() => [createVNode(V$1, null, { default: withCtx(() => [createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode($), createTextVNode(" \u6211\u7684\u4E3B\u9875")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(I), createTextVNode(" \u6536\u85CF\u6587\u7AE0")]), _: 1 })]), _: 1 }), createVNode(r, null, { default: withCtx(() => [createVNode(n, { to: "/user/settings", class: "select-user" }, { default: withCtx(() => [createVNode(R), createTextVNode(" \u8BBE\u7F6E")]), _: 1 })]), _: 1 }), createVNode(r, { onClick: k }, { default: withCtx(() => [createVNode(n, { class: "select-user" }, { default: withCtx(() => [createVNode(M), createTextVNode(" \u9000\u51FA")]), _: 1 })]), _: 1 })]), _: 1 })]), default: withCtx(() => [createVNode("div", { class: "avatar" }, [createVNode(D, { size: 40 }, { icon: withCtx(() => [createVNode("img", { src: unref(a) ? unref(a).avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 }), createVNode(X)])]), _: 1 })) : (openBlock(), createBlock("div", { key: 0 }, [createVNode(d, { onClick: p, type: "text" }, { default: withCtx(() => [createTextVNode("\u767B\u5F55")]), _: 1 }), createVNode(d, { onClick: z, shape: "round", ghost: "", type: "primary" }, { default: withCtx(() => [createTextVNode("\u6CE8\u518C")]), _: 1 })]))]), _: 1 }), createVNode(s, null, { default: withCtx(() => [createVNode(d, { onClick: y, shape: "round", type: "primary", style: { height: "40px", "font-size": "16px" } }, { default: withCtx(() => [createVNode(H, { style: { "margin-right": "4px", "font-size": "16px", "vertical-align": "middle" } }), createTextVNode(" \u5199\u6587\u7AE0 ")]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })];
    }), _: 1 }, A));
  };
} });
const Qe = Oe.setup;
Oe.setup = (c, a) => {
  const y = useSSRContext();
  return (y.modules || (y.modules = /* @__PURE__ */ new Set())).add("components/NavBar.vue"), Qe ? Qe(c, a) : void 0;
};
const $l = Ea$1(Oe, [["__scopeId", "data-v-3f133fe9"]]);

export { $l as $, bl as b, ge as g, zl as z };
//# sourceMappingURL=NavBar-24cf260a.mjs.map
