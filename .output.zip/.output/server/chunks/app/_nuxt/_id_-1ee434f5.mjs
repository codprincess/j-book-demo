import { $ as $l, g as ge } from './NavBar-24cf260a.mjs';
import { V } from './nuxt-link-00da5e11.mjs';
import { createElementVNode, ref, withAsyncContext, withCtx, createVNode, unref, createTextVNode, toDisplayString, useSSRContext, openBlock, createElementBlock } from 'vue';
import { E as Ea, V as Vr, W as Wr, C as Ci } from '../server.mjs';
import { d as ci, e as ei, t as ti, J as Jo } from './useHttpFetch-0d93f309.mjs';
import { r } from './diamond-353edae5.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderStyle } from 'vue/server-renderer';
import St from '@bytemd/plugin-gfm';
import { Viewer } from '@bytemd/vue-next';
import _t from '@bytemd/plugin-highlight';
import z from 'moment';
import './index-4f8e2b3b.mjs';
import '@babel/runtime/helpers/esm/defineProperty';
import '@babel/runtime/helpers/esm/objectSpread2';
import '@babel/runtime/helpers/esm/toConsumableArray';
import '@babel/runtime/helpers/esm/typeof';
import 'lodash-es/uniq.js';
import '@babel/runtime/helpers/esm/objectWithoutProperties';
import '@babel/runtime/helpers/esm/extends';
import '@babel/runtime/helpers/esm/slicedToArray';
import 'lodash-es/isPlainObject.js';
import 'resize-observer-polyfill';
import './logo-7f124be9.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'vue-types';
import '@ant-design/colors';
import '@ctrl/tinycolor';
import 'dom-align';
import 'lodash-es/isEqual.js';

const xt = { viewBox: "0 0 24 24", width: "1.2em", height: "1.2em" }, yt = createElementVNode("path", { fill: "currentColor", d: "M12 11.18c3.3-3 5-4.54 5-6.49C17 3.19 15.75 2 14.25 2c-.86 0-1.68.36-2.25 1c-.57-.64-1.39-1-2.31-1C8.19 2 7 3.25 7 4.75c0 1.89 1.7 3.43 5 6.43m-.82.82c-3-3.3-4.54-5-6.49-5C3.19 7 2 8.25 2 9.75c0 .86.36 1.68 1 2.25c-.64.57-1 1.39-1 2.31C2 15.81 3.25 17 4.75 17c1.89 0 3.43-1.7 6.43-5m1.65 0c2.99 3.3 4.53 5 6.48 5c1.5 0 2.69-1.25 2.69-2.75c0-.86-.36-1.68-1-2.25c.64-.57 1-1.39 1-2.31C22 8.19 20.75 7 19.25 7c-1.89 0-3.43 1.7-6.42 5m-.83.82c-3.3 3-5 4.54-5 6.49C7 20.81 8.25 22 9.75 22c.86 0 1.68-.36 2.25-1c.57.64 1.39 1 2.31 1c1.5 0 2.69-1.25 2.69-2.75c0-1.89-1.7-3.43-5-6.43Z" }, null, -1), bt = [yt];
function $t(k, _) {
  return openBlock(), createElementBlock("svg", xt, bt);
}
const zt = { name: "mdi-clover", render: $t }, kt = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, Yt = createElementVNode("path", { fill: "currentColor", d: "M468 128H160c-17.7 0-32 14.3-32 32v308c0 4.4 3.6 8 8 8h332c4.4 0 8-3.6 8-8V136c0-4.4-3.6-8-8-8zm-56 284H192V192h220v220zm-138-74h56c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8h-56c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8zm194 210H136c-4.4 0-8 3.6-8 8v308c0 17.7 14.3 32 32 32h308c4.4 0 8-3.6 8-8V556c0-4.4-3.6-8-8-8zm-56 284H192V612h220v220zm-138-74h56c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8h-56c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8zm590-630H556c-4.4 0-8 3.6-8 8v332c0 4.4 3.6 8 8 8h332c4.4 0 8-3.6 8-8V160c0-17.7-14.3-32-32-32zm-32 284H612V192h220v220zm-138-74h56c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8h-56c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8zm194 210h-48c-4.4 0-8 3.6-8 8v134h-78V556c0-4.4-3.6-8-8-8H556c-4.4 0-8 3.6-8 8v332c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V644h78v102c0 4.4 3.6 8 8 8h190c4.4 0 8-3.6 8-8V556c0-4.4-3.6-8-8-8zM746 832h-48c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8zm142 0h-48c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8z" }, null, -1), Ht = [Yt];
function Bt(k, _) {
  return openBlock(), createElementBlock("svg", kt, Ht);
}
const Mt = { name: "ant-design-qrcode-outlined", render: Bt }, Dt = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, Nt = createElementVNode("path", { fill: "currentColor", d: "M885.9 533.7c16.8-22.2 26.1-49.4 26.1-77.7c0-44.9-25.1-87.4-65.5-111.1a67.67 67.67 0 0 0-34.3-9.3H572.4l6-122.9c1.4-29.7-9.1-57.9-29.5-79.4A106.62 106.62 0 0 0 471 99.9c-52 0-98 35-111.8 85.1l-85.9 311h-.3v428h472.3c9.2 0 18.2-1.8 26.5-5.4c47.6-20.3 78.3-66.8 78.3-118.4c0-12.6-1.8-25-5.4-37c16.8-22.2 26.1-49.4 26.1-77.7c0-12.6-1.8-25-5.4-37c16.8-22.2 26.1-49.4 26.1-77.7c-.2-12.6-2-25.1-5.6-37.1zM112 528v364c0 17.7 14.3 32 32 32h65V496h-65c-17.7 0-32 14.3-32 32z" }, null, -1), wt = [Nt];
function Ct(k, _) {
  return openBlock(), createElementBlock("svg", Dt, wt);
}
const Vt = { name: "ant-design-like-filled", render: Ct };
const F = { __name: "[id]", __ssrInlineRender: true, async setup(k) {
  let _, Y;
  const H = [St(), _t()], i = ref({}), Q = Vr(), { data: T } = ([_, Y] = withAsyncContext(() => ci({ method: "GET", server: true, params: { noteId: Q.params.id } })), _ = await _, Y(), _);
  if (T.value.code === 1)
    throw Wr({ statusCode: 500, statusMessage: "\u670D\u52A1\u5668\u9519\u8BEF" });
  return i.value = T.value.data, Ci({ title: i.value.title, meta: [{ name: "description", content: i.value.subTitle }, { name: "keywords", content: i.value.subTitle }] }), (jt, w, q, Pt) => {
    const U = $l, c = ei, v = ti, B = Vt, M = Mt, d = V, y = ge, b = zt, g = Jo, $ = r;
    w("<!--[-->"), w(ssrRenderComponent(U, null, null, q)), w(ssrRenderComponent(c, { type: "flex", justify: "center", style: { "background-color": "#F9F9F9", "min-height": "100vh", "padding-top": "66px" } }, { default: withCtx((Rt, L, W, X) => {
      if (L)
        L(ssrRenderComponent(v, { span: 15 }, { default: withCtx((At, G, I, tt) => {
          if (G)
            G(ssrRenderComponent(c, null, { default: withCtx((St, C, V, j) => {
              if (C)
                C(ssrRenderComponent(v, { span: 2 }, { default: withCtx((Z, o, m, s) => {
                  if (o)
                    o(`<div class="left-sider" data-v-9e8cd877${s}><div class="like-btn" data-v-9e8cd877${s}><div class="icon-item" data-v-9e8cd877${s}>`), o(ssrRenderComponent(B, null, null, m, s)), o(`</div><p data-v-9e8cd877${s}>10\u8D5E</p></div><div class="like-btn" data-v-9e8cd877${s}><div class="icon-item" data-v-9e8cd877${s}>\u8D4F</div><p data-v-9e8cd877${s}>\u8D5E\u8D4F</p></div><div class="like-btn" data-v-9e8cd877${s}><div class="icon-item" data-v-9e8cd877${s}>`), o(ssrRenderComponent(M, null, null, m, s)), o(`</div><p data-v-9e8cd877${s}>\u66F4\u591A\u597D\u6587</p></div></div>`);
                  else
                    return [createVNode("div", { class: "left-sider" }, [createVNode("div", { class: "like-btn" }, [createVNode("div", { class: "icon-item" }, [createVNode(B)]), createVNode("p", null, "10\u8D5E")]), createVNode("div", { class: "like-btn" }, [createVNode("div", { class: "icon-item" }, "\u8D4F"), createVNode("p", null, "\u8D5E\u8D4F")]), createVNode("div", { class: "like-btn" }, [createVNode("div", { class: "icon-item" }, [createVNode(M)]), createVNode("p", null, "\u66F4\u591A\u597D\u6587")])])];
                }), _: 1 }, V, j)), C(ssrRenderComponent(v, { span: 16, class: "note-content" }, { default: withCtx((Z, o, m, s) => {
                  if (o)
                    o(`<div class="author-box" data-v-9e8cd877${s}><h1 data-v-9e8cd877${s}>${ssrInterpolate(unref(i).title)}</h1><div class="author-info" data-v-9e8cd877${s}>`), o(ssrRenderComponent(d, null, { default: withCtx((h, n, p, u) => {
                      if (n)
                        n(ssrRenderComponent(y, { size: 44 }, { icon: withCtx((J, x, K, P) => {
                          if (x)
                            x(`<img${ssrRenderAttr("src", unref(i).author.avatar ? unref(i).author.avatar : "/images/default-avatar.png")} alt="avatar" data-v-9e8cd877${P}>`);
                          else
                            return [createVNode("img", { src: unref(i).author.avatar ? unref(i).author.avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])];
                        }), _: 1 }, p, u));
                      else
                        return [createVNode(y, { size: 44 }, { icon: withCtx(() => [createVNode("img", { src: unref(i).author.avatar ? unref(i).author.avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 })];
                    }), _: 1 }, m, s)), o(`<div class="author-des" data-v-9e8cd877${s}>`), o(ssrRenderComponent(c, { type: "flex", align: "middle" }, { default: withCtx((h, n, p, u) => {
                      if (n)
                        n(`<span data-v-9e8cd877${u}>${ssrInterpolate(unref(i).author.nickname)}</span>`), n(ssrRenderComponent(b, { style: { color: "#00BB29" } }, null, p, u)), n(ssrRenderComponent(g, { style: { height: "22px", padding: "0 6px", "font-size": "12px", "margin-left": "6px" }, shape: "round", size: "small", danger: "" }, { default: withCtx((J, x, K, P) => {
                          if (x)
                            x("\u5173\u6CE8");
                          else
                            return [createTextVNode("\u5173\u6CE8")];
                        }), _: 1 }, p, u)), n(`<span class="ip" data-v-9e8cd877${u}>IP\u5C5E\u5730\uFF1A\u4E0A\u6D77</span>`);
                      else
                        return [createVNode("span", null, toDisplayString(unref(i).author.nickname), 1), createVNode(b, { style: { color: "#00BB29" } }), createVNode(g, { style: { height: "22px", padding: "0 6px", "font-size": "12px", "margin-left": "6px" }, shape: "round", size: "small", danger: "" }, { default: withCtx(() => [createTextVNode("\u5173\u6CE8")]), _: 1 }), createVNode("span", { class: "ip" }, "IP\u5C5E\u5730\uFF1A\u4E0A\u6D77")];
                    }), _: 1 }, m, s)), o(ssrRenderComponent(c, { type: "flex", align: "middle", style: { "margin-top": "6px" } }, { default: withCtx((h, n, p, u) => {
                      if (n)
                        n(`<span class="jsd-meta" data-v-9e8cd877${u}>`), n(ssrRenderComponent($, null, null, p, u)), n(`136.0</span><span class="ip" data-v-9e8cd877${u}>${ssrInterpolate(unref(z)(unref(i).created_at).format("YYYY-MM-DD:HH:mm:ss"))}</span><span class="ip" data-v-9e8cd877${u}>\u5B57\u6570 310</span><span class="ip" data-v-9e8cd877${u}>\u9605\u8BFB 420</span>`);
                      else
                        return [createVNode("span", { class: "jsd-meta" }, [createVNode($), createTextVNode("136.0")]), createVNode("span", { class: "ip" }, toDisplayString(unref(z)(unref(i).created_at).format("YYYY-MM-DD:HH:mm:ss")), 1), createVNode("span", { class: "ip" }, "\u5B57\u6570 310"), createVNode("span", { class: "ip" }, "\u9605\u8BFB 420")];
                    }), _: 1 }, m, s)), o("</div></div></div>"), o(ssrRenderComponent(unref(Viewer), { value: unref(i).content_md, plugins: H }, null, m, s));
                  else
                    return [createVNode("div", { class: "author-box" }, [createVNode("h1", null, toDisplayString(unref(i).title), 1), createVNode("div", { class: "author-info" }, [createVNode(d, null, { default: withCtx(() => [createVNode(y, { size: 44 }, { icon: withCtx(() => [createVNode("img", { src: unref(i).author.avatar ? unref(i).author.avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 })]), _: 1 }), createVNode("div", { class: "author-des" }, [createVNode(c, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode("span", null, toDisplayString(unref(i).author.nickname), 1), createVNode(b, { style: { color: "#00BB29" } }), createVNode(g, { style: { height: "22px", padding: "0 6px", "font-size": "12px", "margin-left": "6px" }, shape: "round", size: "small", danger: "" }, { default: withCtx(() => [createTextVNode("\u5173\u6CE8")]), _: 1 }), createVNode("span", { class: "ip" }, "IP\u5C5E\u5730\uFF1A\u4E0A\u6D77")]), _: 1 }), createVNode(c, { type: "flex", align: "middle", style: { "margin-top": "6px" } }, { default: withCtx(() => [createVNode("span", { class: "jsd-meta" }, [createVNode($), createTextVNode("136.0")]), createVNode("span", { class: "ip" }, toDisplayString(unref(z)(unref(i).created_at).format("YYYY-MM-DD:HH:mm:ss")), 1), createVNode("span", { class: "ip" }, "\u5B57\u6570 310"), createVNode("span", { class: "ip" }, "\u9605\u8BFB 420")]), _: 1 })])])]), createVNode(unref(Viewer), { value: unref(i).content_md, plugins: H }, null, 8, ["value"])];
                }), _: 1 }, V, j)), C(ssrRenderComponent(v, { span: 6, class: "right-sider" }, { default: withCtx((Z, o, m, s) => {
                  if (o)
                    o(`<div class="right-author" data-v-9e8cd877${s}><div class="author-des" style="${ssrRenderStyle({ "border-bottom": "1px solid #f0f0f0", "padding-bottom": "10px" })}" data-v-9e8cd877${s}>`), o(ssrRenderComponent(c, { type: "flex", align: "middle" }, { default: withCtx((h, n, p, u) => {
                      if (n)
                        n(`<span style="${ssrRenderStyle({ flex: "1" })}" data-v-9e8cd877${u}>\u5E72\u7269\u59B9\u5C0F\u57CB</span>`), n(ssrRenderComponent(g, { style: { height: "22px", padding: "0 6px", "font-size": "12px", "margin-left": "6px" }, shape: "round", size: "small", danger: "" }, { default: withCtx((J, x, K, P) => {
                          if (x)
                            x("\u5173\u6CE8");
                          else
                            return [createTextVNode("\u5173\u6CE8")];
                        }), _: 1 }, p, u));
                      else
                        return [createVNode("span", { style: { flex: "1" } }, "\u5E72\u7269\u59B9\u5C0F\u57CB"), createVNode(g, { style: { height: "22px", padding: "0 6px", "font-size": "12px", "margin-left": "6px" }, shape: "round", size: "small", danger: "" }, { default: withCtx(() => [createTextVNode("\u5173\u6CE8")]), _: 1 })];
                    }), _: 1 }, m, s)), o(ssrRenderComponent(c, { type: "flex", align: "middle", style: { "margin-top": "6px" } }, { default: withCtx((h, n, p, u) => {
                      if (n)
                        n(`<span class="ip" data-v-9e8cd877${u}>\u603B\u8D44\u4EA7 310</span>`);
                      else
                        return [createVNode("span", { class: "ip" }, "\u603B\u8D44\u4EA7 310")];
                    }), _: 1 }, m, s)), o(`</div><div class="author-note" data-v-9e8cd877${s}><div class="author-note-item" data-v-9e8cd877${s}>`), o(ssrRenderComponent(d, null, { default: withCtx((h, n, p, u) => {
                      if (n)
                        n("\u600E\u4E48\u6837\u624D\u80FD\u5B9E\u73B0\u66B4\u5BCC");
                      else
                        return [createTextVNode("\u600E\u4E48\u6837\u624D\u80FD\u5B9E\u73B0\u66B4\u5BCC")];
                    }), _: 1 }, m, s)), o(`<p class="read" data-v-9e8cd877${s}>\u9605\u8BFB 5349</p></div><div class="author-note-item" data-v-9e8cd877${s}>`), o(ssrRenderComponent(d, null, { default: withCtx((h, n, p, u) => {
                      if (n)
                        n("Nuxt3\u5F00\u53D1\u6CE8\u610F\u4E8B\u9879\uFF0C\u65B0\u624B\u5FC5\u770B\u6587\u7AE0\uFF0C\u770B\u5B8C\u5C31\u5B66\u4F1A");
                      else
                        return [createTextVNode("Nuxt3\u5F00\u53D1\u6CE8\u610F\u4E8B\u9879\uFF0C\u65B0\u624B\u5FC5\u770B\u6587\u7AE0\uFF0C\u770B\u5B8C\u5C31\u5B66\u4F1A")];
                    }), _: 1 }, m, s)), o(`<p class="read" data-v-9e8cd877${s}>\u9605\u8BFB 5349</p></div><div class="author-note-item" data-v-9e8cd877${s}>`), o(ssrRenderComponent(d, null, { default: withCtx((h, n, p, u) => {
                      if (n)
                        n("\u600E\u4E48\u624D\u662F\u8D22\u5BCC\u81EA\u7531");
                      else
                        return [createTextVNode("\u600E\u4E48\u624D\u662F\u8D22\u5BCC\u81EA\u7531")];
                    }), _: 1 }, m, s)), o(`<p class="read" data-v-9e8cd877${s}>\u9605\u8BFB 5349</p></div></div></div><div class="hot-note" data-v-9e8cd877${s}><h3 data-v-9e8cd877${s}>\u70ED\u95E8\u6587\u7AE0</h3><div class="author-note" data-v-9e8cd877${s}><div class="author-note-item" style="${ssrRenderStyle({ "margin-bottom": "10px" })}" data-v-9e8cd877${s}>`), o(ssrRenderComponent(d, null, { default: withCtx((h, n, p, u) => {
                      if (n)
                        n("\u600E\u4E48\u6837\u624D\u80FD\u5B9E\u73B0\u66B4\u5BCC");
                      else
                        return [createTextVNode("\u600E\u4E48\u6837\u624D\u80FD\u5B9E\u73B0\u66B4\u5BCC")];
                    }), _: 1 }, m, s)), o(`</div><div class="author-note-item" style="${ssrRenderStyle({ "margin-bottom": "10px" })}" data-v-9e8cd877${s}>`), o(ssrRenderComponent(d, null, { default: withCtx((h, n, p, u) => {
                      if (n)
                        n("Nuxt3\u5F00\u53D1\u6CE8\u610F\u4E8B\u9879\uFF0C\u65B0\u624B\u5FC5\u770B\u6587\u7AE0\uFF0C\u770B\u5B8C\u5C31\u5B66\u4F1A");
                      else
                        return [createTextVNode("Nuxt3\u5F00\u53D1\u6CE8\u610F\u4E8B\u9879\uFF0C\u65B0\u624B\u5FC5\u770B\u6587\u7AE0\uFF0C\u770B\u5B8C\u5C31\u5B66\u4F1A")];
                    }), _: 1 }, m, s)), o(`</div><div class="author-note-item" style="${ssrRenderStyle({ "margin-bottom": "10px" })}" data-v-9e8cd877${s}>`), o(ssrRenderComponent(d, null, { default: withCtx((h, n, p, u) => {
                      if (n)
                        n("\u600E\u4E48\u624D\u662F\u8D22\u5BCC\u81EA\u7531");
                      else
                        return [createTextVNode("\u600E\u4E48\u624D\u662F\u8D22\u5BCC\u81EA\u7531")];
                    }), _: 1 }, m, s)), o("</div></div></div>");
                  else
                    return [createVNode("div", { class: "right-author" }, [createVNode("div", { class: "author-des", style: { "border-bottom": "1px solid #f0f0f0", "padding-bottom": "10px" } }, [createVNode(c, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode("span", { style: { flex: "1" } }, "\u5E72\u7269\u59B9\u5C0F\u57CB"), createVNode(g, { style: { height: "22px", padding: "0 6px", "font-size": "12px", "margin-left": "6px" }, shape: "round", size: "small", danger: "" }, { default: withCtx(() => [createTextVNode("\u5173\u6CE8")]), _: 1 })]), _: 1 }), createVNode(c, { type: "flex", align: "middle", style: { "margin-top": "6px" } }, { default: withCtx(() => [createVNode("span", { class: "ip" }, "\u603B\u8D44\u4EA7 310")]), _: 1 })]), createVNode("div", { class: "author-note" }, [createVNode("div", { class: "author-note-item" }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u6837\u624D\u80FD\u5B9E\u73B0\u66B4\u5BCC")]), _: 1 }), createVNode("p", { class: "read" }, "\u9605\u8BFB 5349")]), createVNode("div", { class: "author-note-item" }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("Nuxt3\u5F00\u53D1\u6CE8\u610F\u4E8B\u9879\uFF0C\u65B0\u624B\u5FC5\u770B\u6587\u7AE0\uFF0C\u770B\u5B8C\u5C31\u5B66\u4F1A")]), _: 1 }), createVNode("p", { class: "read" }, "\u9605\u8BFB 5349")]), createVNode("div", { class: "author-note-item" }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u624D\u662F\u8D22\u5BCC\u81EA\u7531")]), _: 1 }), createVNode("p", { class: "read" }, "\u9605\u8BFB 5349")])])]), createVNode("div", { class: "hot-note" }, [createVNode("h3", null, "\u70ED\u95E8\u6587\u7AE0"), createVNode("div", { class: "author-note" }, [createVNode("div", { class: "author-note-item", style: { "margin-bottom": "10px" } }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u6837\u624D\u80FD\u5B9E\u73B0\u66B4\u5BCC")]), _: 1 })]), createVNode("div", { class: "author-note-item", style: { "margin-bottom": "10px" } }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("Nuxt3\u5F00\u53D1\u6CE8\u610F\u4E8B\u9879\uFF0C\u65B0\u624B\u5FC5\u770B\u6587\u7AE0\uFF0C\u770B\u5B8C\u5C31\u5B66\u4F1A")]), _: 1 })]), createVNode("div", { class: "author-note-item", style: { "margin-bottom": "10px" } }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u624D\u662F\u8D22\u5BCC\u81EA\u7531")]), _: 1 })])])])];
                }), _: 1 }, V, j));
              else
                return [createVNode(v, { span: 2 }, { default: withCtx(() => [createVNode("div", { class: "left-sider" }, [createVNode("div", { class: "like-btn" }, [createVNode("div", { class: "icon-item" }, [createVNode(B)]), createVNode("p", null, "10\u8D5E")]), createVNode("div", { class: "like-btn" }, [createVNode("div", { class: "icon-item" }, "\u8D4F"), createVNode("p", null, "\u8D5E\u8D4F")]), createVNode("div", { class: "like-btn" }, [createVNode("div", { class: "icon-item" }, [createVNode(M)]), createVNode("p", null, "\u66F4\u591A\u597D\u6587")])])]), _: 1 }), createVNode(v, { span: 16, class: "note-content" }, { default: withCtx(() => [createVNode("div", { class: "author-box" }, [createVNode("h1", null, toDisplayString(unref(i).title), 1), createVNode("div", { class: "author-info" }, [createVNode(d, null, { default: withCtx(() => [createVNode(y, { size: 44 }, { icon: withCtx(() => [createVNode("img", { src: unref(i).author.avatar ? unref(i).author.avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 })]), _: 1 }), createVNode("div", { class: "author-des" }, [createVNode(c, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode("span", null, toDisplayString(unref(i).author.nickname), 1), createVNode(b, { style: { color: "#00BB29" } }), createVNode(g, { style: { height: "22px", padding: "0 6px", "font-size": "12px", "margin-left": "6px" }, shape: "round", size: "small", danger: "" }, { default: withCtx(() => [createTextVNode("\u5173\u6CE8")]), _: 1 }), createVNode("span", { class: "ip" }, "IP\u5C5E\u5730\uFF1A\u4E0A\u6D77")]), _: 1 }), createVNode(c, { type: "flex", align: "middle", style: { "margin-top": "6px" } }, { default: withCtx(() => [createVNode("span", { class: "jsd-meta" }, [createVNode($), createTextVNode("136.0")]), createVNode("span", { class: "ip" }, toDisplayString(unref(z)(unref(i).created_at).format("YYYY-MM-DD:HH:mm:ss")), 1), createVNode("span", { class: "ip" }, "\u5B57\u6570 310"), createVNode("span", { class: "ip" }, "\u9605\u8BFB 420")]), _: 1 })])])]), createVNode(unref(Viewer), { value: unref(i).content_md, plugins: H }, null, 8, ["value"])]), _: 1 }), createVNode(v, { span: 6, class: "right-sider" }, { default: withCtx(() => [createVNode("div", { class: "right-author" }, [createVNode("div", { class: "author-des", style: { "border-bottom": "1px solid #f0f0f0", "padding-bottom": "10px" } }, [createVNode(c, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode("span", { style: { flex: "1" } }, "\u5E72\u7269\u59B9\u5C0F\u57CB"), createVNode(g, { style: { height: "22px", padding: "0 6px", "font-size": "12px", "margin-left": "6px" }, shape: "round", size: "small", danger: "" }, { default: withCtx(() => [createTextVNode("\u5173\u6CE8")]), _: 1 })]), _: 1 }), createVNode(c, { type: "flex", align: "middle", style: { "margin-top": "6px" } }, { default: withCtx(() => [createVNode("span", { class: "ip" }, "\u603B\u8D44\u4EA7 310")]), _: 1 })]), createVNode("div", { class: "author-note" }, [createVNode("div", { class: "author-note-item" }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u6837\u624D\u80FD\u5B9E\u73B0\u66B4\u5BCC")]), _: 1 }), createVNode("p", { class: "read" }, "\u9605\u8BFB 5349")]), createVNode("div", { class: "author-note-item" }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("Nuxt3\u5F00\u53D1\u6CE8\u610F\u4E8B\u9879\uFF0C\u65B0\u624B\u5FC5\u770B\u6587\u7AE0\uFF0C\u770B\u5B8C\u5C31\u5B66\u4F1A")]), _: 1 }), createVNode("p", { class: "read" }, "\u9605\u8BFB 5349")]), createVNode("div", { class: "author-note-item" }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u624D\u662F\u8D22\u5BCC\u81EA\u7531")]), _: 1 }), createVNode("p", { class: "read" }, "\u9605\u8BFB 5349")])])]), createVNode("div", { class: "hot-note" }, [createVNode("h3", null, "\u70ED\u95E8\u6587\u7AE0"), createVNode("div", { class: "author-note" }, [createVNode("div", { class: "author-note-item", style: { "margin-bottom": "10px" } }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u6837\u624D\u80FD\u5B9E\u73B0\u66B4\u5BCC")]), _: 1 })]), createVNode("div", { class: "author-note-item", style: { "margin-bottom": "10px" } }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("Nuxt3\u5F00\u53D1\u6CE8\u610F\u4E8B\u9879\uFF0C\u65B0\u624B\u5FC5\u770B\u6587\u7AE0\uFF0C\u770B\u5B8C\u5C31\u5B66\u4F1A")]), _: 1 })]), createVNode("div", { class: "author-note-item", style: { "margin-bottom": "10px" } }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u624D\u662F\u8D22\u5BCC\u81EA\u7531")]), _: 1 })])])])]), _: 1 })];
            }), _: 1 }, I, tt));
          else
            return [createVNode(c, null, { default: withCtx(() => [createVNode(v, { span: 2 }, { default: withCtx(() => [createVNode("div", { class: "left-sider" }, [createVNode("div", { class: "like-btn" }, [createVNode("div", { class: "icon-item" }, [createVNode(B)]), createVNode("p", null, "10\u8D5E")]), createVNode("div", { class: "like-btn" }, [createVNode("div", { class: "icon-item" }, "\u8D4F"), createVNode("p", null, "\u8D5E\u8D4F")]), createVNode("div", { class: "like-btn" }, [createVNode("div", { class: "icon-item" }, [createVNode(M)]), createVNode("p", null, "\u66F4\u591A\u597D\u6587")])])]), _: 1 }), createVNode(v, { span: 16, class: "note-content" }, { default: withCtx(() => [createVNode("div", { class: "author-box" }, [createVNode("h1", null, toDisplayString(unref(i).title), 1), createVNode("div", { class: "author-info" }, [createVNode(d, null, { default: withCtx(() => [createVNode(y, { size: 44 }, { icon: withCtx(() => [createVNode("img", { src: unref(i).author.avatar ? unref(i).author.avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 })]), _: 1 }), createVNode("div", { class: "author-des" }, [createVNode(c, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode("span", null, toDisplayString(unref(i).author.nickname), 1), createVNode(b, { style: { color: "#00BB29" } }), createVNode(g, { style: { height: "22px", padding: "0 6px", "font-size": "12px", "margin-left": "6px" }, shape: "round", size: "small", danger: "" }, { default: withCtx(() => [createTextVNode("\u5173\u6CE8")]), _: 1 }), createVNode("span", { class: "ip" }, "IP\u5C5E\u5730\uFF1A\u4E0A\u6D77")]), _: 1 }), createVNode(c, { type: "flex", align: "middle", style: { "margin-top": "6px" } }, { default: withCtx(() => [createVNode("span", { class: "jsd-meta" }, [createVNode($), createTextVNode("136.0")]), createVNode("span", { class: "ip" }, toDisplayString(unref(z)(unref(i).created_at).format("YYYY-MM-DD:HH:mm:ss")), 1), createVNode("span", { class: "ip" }, "\u5B57\u6570 310"), createVNode("span", { class: "ip" }, "\u9605\u8BFB 420")]), _: 1 })])])]), createVNode(unref(Viewer), { value: unref(i).content_md, plugins: H }, null, 8, ["value"])]), _: 1 }), createVNode(v, { span: 6, class: "right-sider" }, { default: withCtx(() => [createVNode("div", { class: "right-author" }, [createVNode("div", { class: "author-des", style: { "border-bottom": "1px solid #f0f0f0", "padding-bottom": "10px" } }, [createVNode(c, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode("span", { style: { flex: "1" } }, "\u5E72\u7269\u59B9\u5C0F\u57CB"), createVNode(g, { style: { height: "22px", padding: "0 6px", "font-size": "12px", "margin-left": "6px" }, shape: "round", size: "small", danger: "" }, { default: withCtx(() => [createTextVNode("\u5173\u6CE8")]), _: 1 })]), _: 1 }), createVNode(c, { type: "flex", align: "middle", style: { "margin-top": "6px" } }, { default: withCtx(() => [createVNode("span", { class: "ip" }, "\u603B\u8D44\u4EA7 310")]), _: 1 })]), createVNode("div", { class: "author-note" }, [createVNode("div", { class: "author-note-item" }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u6837\u624D\u80FD\u5B9E\u73B0\u66B4\u5BCC")]), _: 1 }), createVNode("p", { class: "read" }, "\u9605\u8BFB 5349")]), createVNode("div", { class: "author-note-item" }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("Nuxt3\u5F00\u53D1\u6CE8\u610F\u4E8B\u9879\uFF0C\u65B0\u624B\u5FC5\u770B\u6587\u7AE0\uFF0C\u770B\u5B8C\u5C31\u5B66\u4F1A")]), _: 1 }), createVNode("p", { class: "read" }, "\u9605\u8BFB 5349")]), createVNode("div", { class: "author-note-item" }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u624D\u662F\u8D22\u5BCC\u81EA\u7531")]), _: 1 }), createVNode("p", { class: "read" }, "\u9605\u8BFB 5349")])])]), createVNode("div", { class: "hot-note" }, [createVNode("h3", null, "\u70ED\u95E8\u6587\u7AE0"), createVNode("div", { class: "author-note" }, [createVNode("div", { class: "author-note-item", style: { "margin-bottom": "10px" } }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u6837\u624D\u80FD\u5B9E\u73B0\u66B4\u5BCC")]), _: 1 })]), createVNode("div", { class: "author-note-item", style: { "margin-bottom": "10px" } }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("Nuxt3\u5F00\u53D1\u6CE8\u610F\u4E8B\u9879\uFF0C\u65B0\u624B\u5FC5\u770B\u6587\u7AE0\uFF0C\u770B\u5B8C\u5C31\u5B66\u4F1A")]), _: 1 })]), createVNode("div", { class: "author-note-item", style: { "margin-bottom": "10px" } }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u624D\u662F\u8D22\u5BCC\u81EA\u7531")]), _: 1 })])])])]), _: 1 })]), _: 1 })];
        }), _: 1 }, W, X));
      else
        return [createVNode(v, { span: 15 }, { default: withCtx(() => [createVNode(c, null, { default: withCtx(() => [createVNode(v, { span: 2 }, { default: withCtx(() => [createVNode("div", { class: "left-sider" }, [createVNode("div", { class: "like-btn" }, [createVNode("div", { class: "icon-item" }, [createVNode(B)]), createVNode("p", null, "10\u8D5E")]), createVNode("div", { class: "like-btn" }, [createVNode("div", { class: "icon-item" }, "\u8D4F"), createVNode("p", null, "\u8D5E\u8D4F")]), createVNode("div", { class: "like-btn" }, [createVNode("div", { class: "icon-item" }, [createVNode(M)]), createVNode("p", null, "\u66F4\u591A\u597D\u6587")])])]), _: 1 }), createVNode(v, { span: 16, class: "note-content" }, { default: withCtx(() => [createVNode("div", { class: "author-box" }, [createVNode("h1", null, toDisplayString(unref(i).title), 1), createVNode("div", { class: "author-info" }, [createVNode(d, null, { default: withCtx(() => [createVNode(y, { size: 44 }, { icon: withCtx(() => [createVNode("img", { src: unref(i).author.avatar ? unref(i).author.avatar : "/images/default-avatar.png", alt: "avatar" }, null, 8, ["src"])]), _: 1 })]), _: 1 }), createVNode("div", { class: "author-des" }, [createVNode(c, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode("span", null, toDisplayString(unref(i).author.nickname), 1), createVNode(b, { style: { color: "#00BB29" } }), createVNode(g, { style: { height: "22px", padding: "0 6px", "font-size": "12px", "margin-left": "6px" }, shape: "round", size: "small", danger: "" }, { default: withCtx(() => [createTextVNode("\u5173\u6CE8")]), _: 1 }), createVNode("span", { class: "ip" }, "IP\u5C5E\u5730\uFF1A\u4E0A\u6D77")]), _: 1 }), createVNode(c, { type: "flex", align: "middle", style: { "margin-top": "6px" } }, { default: withCtx(() => [createVNode("span", { class: "jsd-meta" }, [createVNode($), createTextVNode("136.0")]), createVNode("span", { class: "ip" }, toDisplayString(unref(z)(unref(i).created_at).format("YYYY-MM-DD:HH:mm:ss")), 1), createVNode("span", { class: "ip" }, "\u5B57\u6570 310"), createVNode("span", { class: "ip" }, "\u9605\u8BFB 420")]), _: 1 })])])]), createVNode(unref(Viewer), { value: unref(i).content_md, plugins: H }, null, 8, ["value"])]), _: 1 }), createVNode(v, { span: 6, class: "right-sider" }, { default: withCtx(() => [createVNode("div", { class: "right-author" }, [createVNode("div", { class: "author-des", style: { "border-bottom": "1px solid #f0f0f0", "padding-bottom": "10px" } }, [createVNode(c, { type: "flex", align: "middle" }, { default: withCtx(() => [createVNode("span", { style: { flex: "1" } }, "\u5E72\u7269\u59B9\u5C0F\u57CB"), createVNode(g, { style: { height: "22px", padding: "0 6px", "font-size": "12px", "margin-left": "6px" }, shape: "round", size: "small", danger: "" }, { default: withCtx(() => [createTextVNode("\u5173\u6CE8")]), _: 1 })]), _: 1 }), createVNode(c, { type: "flex", align: "middle", style: { "margin-top": "6px" } }, { default: withCtx(() => [createVNode("span", { class: "ip" }, "\u603B\u8D44\u4EA7 310")]), _: 1 })]), createVNode("div", { class: "author-note" }, [createVNode("div", { class: "author-note-item" }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u6837\u624D\u80FD\u5B9E\u73B0\u66B4\u5BCC")]), _: 1 }), createVNode("p", { class: "read" }, "\u9605\u8BFB 5349")]), createVNode("div", { class: "author-note-item" }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("Nuxt3\u5F00\u53D1\u6CE8\u610F\u4E8B\u9879\uFF0C\u65B0\u624B\u5FC5\u770B\u6587\u7AE0\uFF0C\u770B\u5B8C\u5C31\u5B66\u4F1A")]), _: 1 }), createVNode("p", { class: "read" }, "\u9605\u8BFB 5349")]), createVNode("div", { class: "author-note-item" }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u624D\u662F\u8D22\u5BCC\u81EA\u7531")]), _: 1 }), createVNode("p", { class: "read" }, "\u9605\u8BFB 5349")])])]), createVNode("div", { class: "hot-note" }, [createVNode("h3", null, "\u70ED\u95E8\u6587\u7AE0"), createVNode("div", { class: "author-note" }, [createVNode("div", { class: "author-note-item", style: { "margin-bottom": "10px" } }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u6837\u624D\u80FD\u5B9E\u73B0\u66B4\u5BCC")]), _: 1 })]), createVNode("div", { class: "author-note-item", style: { "margin-bottom": "10px" } }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("Nuxt3\u5F00\u53D1\u6CE8\u610F\u4E8B\u9879\uFF0C\u65B0\u624B\u5FC5\u770B\u6587\u7AE0\uFF0C\u770B\u5B8C\u5C31\u5B66\u4F1A")]), _: 1 })]), createVNode("div", { class: "author-note-item", style: { "margin-bottom": "10px" } }, [createVNode(d, null, { default: withCtx(() => [createTextVNode("\u600E\u4E48\u624D\u662F\u8D22\u5BCC\u81EA\u7531")]), _: 1 })])])])]), _: 1 })]), _: 1 })]), _: 1 })];
    }), _: 1 }, q)), w("<!--]-->");
  };
} }, O = F.setup;
F.setup = (k, _) => {
  const Y = useSSRContext();
  return (Y.modules || (Y.modules = /* @__PURE__ */ new Set())).add("pages/p/[id].vue"), O ? O(k, _) : void 0;
};
const Ia = Ea(F, [["__scopeId", "data-v-9e8cd877"]]);

export { Ia as default };
//# sourceMappingURL=_id_-1ee434f5.mjs.map
