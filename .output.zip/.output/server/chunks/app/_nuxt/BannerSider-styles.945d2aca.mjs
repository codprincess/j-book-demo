const a = `.board[data-v-77f317c5]{width:100%}.board img[data-v-77f317c5]{border-radius:4px;margin-bottom:6px;min-height:39px;width:100%}
`;

const BannerSiderStyles_945d2aca = [a];

export { BannerSiderStyles_945d2aca as default };
//# sourceMappingURL=BannerSider-styles.945d2aca.mjs.map
