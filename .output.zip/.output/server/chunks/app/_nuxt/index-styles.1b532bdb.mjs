const t = `#components-back-top-demo-custom .ant-back-top[data-v-79687a53]{bottom:100px}#components-back-top-demo-custom .ant-back-top-inner[data-v-79687a53]{border:1px solid #e05344;border-radius:4px;color:#e05344;font-size:20px;height:40px;line-height:40px;text-align:center;width:40px}
`;

const indexStyles_1b532bdb = [t];

export { indexStyles_1b532bdb as default };
//# sourceMappingURL=index-styles.1b532bdb.mjs.map
