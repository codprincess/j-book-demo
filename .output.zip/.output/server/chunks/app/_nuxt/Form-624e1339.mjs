import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { createElementVNode, openBlock, createElementBlock, defineComponent, computed, ref, watch, createVNode, TransitionGroup, Fragment, watchEffect, provide, inject, shallowRef, toRaw, nextTick, unref, reactive, cloneVNode } from 'vue';
import fe from '@babel/runtime/helpers/esm/toConsumableArray';
import ee$1 from '@babel/runtime/helpers/esm/typeof';
import x from '@babel/runtime/helpers/esm/defineProperty';
import v$1 from '@babel/runtime/helpers/esm/objectSpread2';
import { k as ke$1, f as Vo, p as pe, g as Eo, F as Fo, h as Mt, O as Oi, a as pt, H as Ho, T as Ti, w as we$1, j as an, l as hr, r as rn, z as ze$1, I as Ii } from '../server.mjs';
import oe from 'lodash-es/cloneDeep.js';
import { Z as Zo, x as xo, g as qo, y as yo, b as bt } from './useHttpFetch-0d93f309.mjs';
import fe$1 from '@babel/runtime/helpers/esm/asyncToGenerator';
import ee from '@babel/runtime/regenerator';
import sr from 'async-validator';
import cr from '@babel/runtime/helpers/esm/toArray';
import dr from 'lodash-es/find.js';
import xe$1 from '@babel/runtime/helpers/esm/slicedToArray';
import Te from 'lodash-es/isEqual.js';
import compute from 'compute-scroll-into-view';
import { J } from './logo-7f124be9.mjs';
import ce from '@babel/runtime/helpers/esm/extends';
import Fr from 'lodash-es/intersection.js';
import yr from 'lodash-es/debounce.js';
import Cr from 'lodash-es/omit.js';

const s = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, _ = createElementVNode("path", { fill: "currentColor", d: "M824.8 613.2c-16-51.4-34.4-94.6-62.7-165.3C766.5 262.2 689.3 112 511.5 112C331.7 112 256.2 265.2 261 447.9c-28.4 70.8-46.7 113.7-62.7 165.3c-34 109.5-23 154.8-14.6 155.8c18 2.2 70.1-82.4 70.1-82.4c0 49 25.2 112.9 79.8 159c-26.4 8.1-85.7 29.9-71.6 53.8c11.4 19.3 196.2 12.3 249.5 6.3c53.3 6 238.1 13 249.5-6.3c14.1-23.8-45.3-45.7-71.6-53.8c54.6-46.2 79.8-110.1 79.8-159c0 0 52.1 84.6 70.1 82.4c8.5-1.1 19.5-46.4-14.5-155.8z" }, null, -1), i = [_];
function r(t, o) {
  return openBlock(), createElementBlock("svg", s, i);
}
const w = { name: "ant-design-qq-outlined", render: r }, l = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, a = createElementVNode("path", { fill: "currentColor", d: "M690.1 377.4c5.9 0 11.8.2 17.6.5c-24.4-128.7-158.3-227.1-319.9-227.1C209 150.8 64 271.4 64 420.2c0 81.1 43.6 154.2 111.9 203.6a21.5 21.5 0 0 1 9.1 17.6c0 2.4-.5 4.6-1.1 6.9c-5.5 20.3-14.2 52.8-14.6 54.3c-.7 2.6-1.7 5.2-1.7 7.9c0 5.9 4.8 10.8 10.8 10.8c2.3 0 4.2-.9 6.2-2l70.9-40.9c5.3-3.1 11-5 17.2-5c3.2 0 6.4.5 9.5 1.4c33.1 9.5 68.8 14.8 105.7 14.8c6 0 11.9-.1 17.8-.4c-7.1-21-10.9-43.1-10.9-66c0-135.8 132.2-245.8 295.3-245.8zm-194.3-86.5c23.8 0 43.2 19.3 43.2 43.1s-19.3 43.1-43.2 43.1c-23.8 0-43.2-19.3-43.2-43.1s19.4-43.1 43.2-43.1zm-215.9 86.2c-23.8 0-43.2-19.3-43.2-43.1s19.3-43.1 43.2-43.1s43.2 19.3 43.2 43.1s-19.4 43.1-43.2 43.1zm586.8 415.6c56.9-41.2 93.2-102 93.2-169.7c0-124-120.8-224.5-269.9-224.5c-149 0-269.9 100.5-269.9 224.5S540.9 847.5 690 847.5c30.8 0 60.6-4.4 88.1-12.3c2.6-.8 5.2-1.2 7.9-1.2c5.2 0 9.9 1.6 14.3 4.1l59.1 34c1.7 1 3.3 1.7 5.2 1.7a9 9 0 0 0 6.4-2.6a9 9 0 0 0 2.6-6.4c0-2.2-.9-4.4-1.4-6.6c-.3-1.2-7.6-28.3-12.2-45.3c-.5-1.9-.9-3.8-.9-5.7c.1-5.9 3.1-11.2 7.6-14.5zM600.2 587.2c-19.9 0-36-16.1-36-35.9c0-19.8 16.1-35.9 36-35.9s36 16.1 36 35.9c0 19.8-16.2 35.9-36 35.9zm179.9 0c-19.9 0-36-16.1-36-35.9c0-19.8 16.1-35.9 36-35.9s36 16.1 36 35.9a36.08 36.08 0 0 1-36 35.9z" }, null, -1), d = [a];
function h(t, o) {
  return openBlock(), createElementBlock("svg", l, d);
}
const C = { name: "ant-design-wechat-outlined", render: h }, m = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, u = createElementVNode("path", { fill: "currentColor", d: "M832 464h-68V240c0-70.7-57.3-128-128-128H388c-70.7 0-128 57.3-128 128v224h-68c-17.7 0-32 14.3-32 32v384c0 17.7 14.3 32 32 32h640c17.7 0 32-14.3 32-32V496c0-17.7-14.3-32-32-32zM540 701v53c0 4.4-3.6 8-8 8h-40c-4.4 0-8-3.6-8-8v-53a48.01 48.01 0 1 1 56 0zm152-237H332V240c0-30.9 25.1-56 56-56h248c30.9 0 56 25.1 56 56v224z" }, null, -1), g = [u];
function p(t, o) {
  return openBlock(), createElementBlock("svg", m, g);
}
const B = { name: "ant-design-lock-filled", render: p }, v = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, $ = createElementVNode("path", { fill: "currentColor", d: "M288 320a224 224 0 1 0 448 0a224 224 0 1 0-448 0zm544 608H160a32 32 0 0 1-32-32v-96a160 160 0 0 1 160-160h448a160 160 0 0 1 160 160v96a32 32 0 0 1-32 32z" }, null, -1), z$1 = [$];
function f(t, o) {
  return openBlock(), createElementBlock("svg", v, z$1);
}
const M = { name: "ep-user-filled", render: f };
const b = "" + publicAssetsURL("images/sign_bg.png"), V = "" + publicAssetsURL("images/login_page_download.png");

function isOptionsObject(options) {
  return options === Object(options) && Object.keys(options).length !== 0;
}
function defaultBehavior(actions, behavior) {
  if (behavior === void 0) {
    behavior = 'auto';
  }
  var canSmoothScroll = ('scrollBehavior' in document.body.style);
  actions.forEach(function (_ref) {
    var el = _ref.el,
      top = _ref.top,
      left = _ref.left;
    if (el.scroll && canSmoothScroll) {
      el.scroll({
        top: top,
        left: left,
        behavior: behavior
      });
    } else {
      el.scrollTop = top;
      el.scrollLeft = left;
    }
  });
}
function getOptions(options) {
  if (options === false) {
    return {
      block: 'end',
      inline: 'nearest'
    };
  }
  if (isOptionsObject(options)) {
    return options;
  }
  return {
    block: 'start',
    inline: 'nearest'
  };
}
function scrollIntoView(target, options) {
  var isTargetAttached = target.isConnected || target.ownerDocument.documentElement.contains(target);
  if (isOptionsObject(options) && typeof options.behavior === 'function') {
    return options.behavior(isTargetAttached ? compute(target, options) : []);
  }
  if (!isTargetAttached) {
    return;
  }
  var computeOptions = getOptions(options);
  return defaultBehavior(compute(target, computeOptions), computeOptions.behavior);
}

function Z(a) {
  return a == null ? [] : Array.isArray(a) ? a : [a];
}
function Be(a, e) {
  for (var n = a, r = 0; r < e.length; r += 1) {
    if (n == null)
      return;
    n = n[e[r]];
  }
  return n;
}
function De(a, e, n, r) {
  if (!e.length)
    return n;
  var l = cr(e), u = l[0], s = l.slice(1), d;
  return !a && typeof u == "number" ? d = [] : Array.isArray(a) ? d = fe(a) : d = v$1({}, a), r && n === void 0 && s.length === 1 ? delete d[u][s[0]] : d[u] = De(d[u], s, n, r), d;
}
function wr(a, e, n) {
  var r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : false;
  return e.length && r && n === void 0 && !Be(a, e.slice(0, -1)) ? a : De(a, e, n, r);
}
function Fe(a) {
  return Z(a);
}
function xr(a, e) {
  var n = Be(a, e);
  return n;
}
function $r(a, e, n) {
  var r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : false, l = wr(a, e, n, r);
  return l;
}
function Pr(a, e) {
  return a && a.some(function(n) {
    return Vr(n, e);
  });
}
function je(a) {
  return ee$1(a) === "object" && a !== null && Object.getPrototypeOf(a) === Object.prototype;
}
function We(a, e) {
  var n = Array.isArray(a) ? fe(a) : v$1({}, a);
  return e && Object.keys(e).forEach(function(r) {
    var l = n[r], u = e[r], s = je(l) && je(u);
    n[r] = s ? We(l, u || {}) : u;
  }), n;
}
function kr(a) {
  for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++)
    n[r - 1] = arguments[r];
  return n.reduce(function(l, u) {
    return We(l, u);
  }, a);
}
function qe(a, e) {
  var n = {};
  return e.forEach(function(r) {
    var l = xr(a, r);
    n = $r(n, r, l);
  }), n;
}
function Vr(a, e) {
  return !a || !e || a.length !== e.length ? false : a.every(function(n, r) {
    return e[r] === n;
  });
}
var z = "'${name}' is not a valid ${type}", ve = { default: "Validation error on field '${name}'", required: "'${name}' is required", enum: "'${name}' must be one of [${enum}]", whitespace: "'${name}' cannot be empty", date: { format: "'${name}' is invalid for format date", parse: "'${name}' could not be parsed as date", invalid: "'${name}' is invalid date" }, types: { string: z, method: z, array: z, object: z, number: z, date: z, boolean: z, integer: z, float: z, regexp: z, email: z, url: z, hex: z }, string: { len: "'${name}' must be exactly ${len} characters", min: "'${name}' must be at least ${min} characters", max: "'${name}' cannot be longer than ${max} characters", range: "'${name}' must be between ${min} and ${max} characters" }, number: { len: "'${name}' must equal ${len}", min: "'${name}' cannot be less than ${min}", max: "'${name}' cannot be greater than ${max}", range: "'${name}' must be between ${min} and ${max}" }, array: { len: "'${name}' must be exactly ${len} in length", min: "'${name}' cannot be less than ${min} in length", max: "'${name}' cannot be greater than ${max} in length", range: "'${name}' must be between ${min} and ${max} in length" }, pattern: { mismatch: "'${name}' does not match pattern ${pattern}" } }, Ar = sr;
function jr(a, e) {
  return a.replace(/\$\{\w+\}/g, function(n) {
    var r = n.slice(2, -1);
    return e[r];
  });
}
function ye(a, e, n, r, l) {
  return Ce.apply(this, arguments);
}
function Ce() {
  return Ce = fe$1(ee.mark(function a(e, n, r, l, u) {
    var s, d, h, y, f, m, V, O;
    return ee.wrap(function(b) {
      for (; ; )
        switch (b.prev = b.next) {
          case 0:
            return s = v$1({}, r), delete s.ruleIndex, delete s.trigger, d = null, s && s.type === "array" && s.defaultField && (d = s.defaultField, delete s.defaultField), h = new Ar(x({}, e, [s])), y = kr({}, ve, l.validateMessages), h.messages(y), f = [], b.prev = 9, b.next = 12, Promise.resolve(h.validate(x({}, e, n), v$1({}, l)));
          case 12:
            b.next = 17;
            break;
          case 14:
            b.prev = 14, b.t0 = b.catch(9), b.t0.errors ? f = b.t0.errors.map(function(P, k) {
              var j = P.message;
              return Ii(j) ? cloneVNode(j, { key: "error_".concat(k) }) : j;
            }) : f = [y.default()];
          case 17:
            if (!(!f.length && d)) {
              b.next = 22;
              break;
            }
            return b.next = 20, Promise.all(n.map(function(P, k) {
              return ye("".concat(e, ".").concat(k), P, d, l, u);
            }));
          case 20:
            return m = b.sent, b.abrupt("return", m.reduce(function(P, k) {
              return [].concat(fe(P), fe(k));
            }, []));
          case 22:
            return V = v$1(v$1({}, r), {}, { name: e, enum: (r.enum || []).join(", ") }, u), O = f.map(function(P) {
              return typeof P == "string" ? jr(P, V) : P;
            }), b.abrupt("return", O);
          case 25:
          case "end":
            return b.stop();
        }
    }, a, null, [[9, 14]]);
  })), Ce.apply(this, arguments);
}
function Ke(a, e, n, r, l, u) {
  var s = a.join("."), d = n.map(function(f, m) {
    var V = f.validator, O = v$1(v$1({}, f), {}, { ruleIndex: m });
    return V && (O.validator = function(A, b, P) {
      var k = false, j = function() {
        for (var c = arguments.length, p = new Array(c), $ = 0; $ < c; $++)
          p[$] = arguments[$];
        Promise.resolve().then(function() {
          k || P.apply(void 0, p);
        });
      }, q = V(A, b, j);
      k = q && typeof q.then == "function" && typeof q.catch == "function", k && q.then(function() {
        P();
      }).catch(function(i) {
        P(i || " ");
      });
    }), O;
  }).sort(function(f, m) {
    var V = f.warningOnly, O = f.ruleIndex, A = m.warningOnly, b = m.ruleIndex;
    return !!V == !!A ? O - b : V ? 1 : -1;
  }), h;
  if (l === true)
    h = new Promise(function() {
      var f = fe$1(ee.mark(function m(V, O) {
        var A, b, P;
        return ee.wrap(function(j) {
          for (; ; )
            switch (j.prev = j.next) {
              case 0:
                A = 0;
              case 1:
                if (!(A < d.length)) {
                  j.next = 12;
                  break;
                }
                return b = d[A], j.next = 5, ye(s, e, b, r, u);
              case 5:
                if (P = j.sent, !P.length) {
                  j.next = 9;
                  break;
                }
                return O([{ errors: P, rule: b }]), j.abrupt("return");
              case 9:
                A += 1, j.next = 1;
                break;
              case 12:
                V([]);
              case 13:
              case "end":
                return j.stop();
            }
        }, m);
      }));
      return function(m, V) {
        return f.apply(this, arguments);
      };
    }());
  else {
    var y = d.map(function(f) {
      return ye(s, e, f, r, u).then(function(m) {
        return { errors: m, rule: f };
      });
    });
    h = (l ? Ir(y) : qr(y)).then(function(f) {
      return Promise.reject(f);
    });
  }
  return h.catch(function(f) {
    return f;
  }), h;
}
function qr(a) {
  return we.apply(this, arguments);
}
function we() {
  return we = fe$1(ee.mark(function a(e) {
    return ee.wrap(function(r) {
      for (; ; )
        switch (r.prev = r.next) {
          case 0:
            return r.abrupt("return", Promise.all(e).then(function(l) {
              var u, s = (u = []).concat.apply(u, fe(l));
              return s;
            }));
          case 1:
          case "end":
            return r.stop();
        }
    }, a);
  })), we.apply(this, arguments);
}
function Ir(a) {
  return xe.apply(this, arguments);
}
function xe() {
  return xe = fe$1(ee.mark(function a(e) {
    var n;
    return ee.wrap(function(l) {
      for (; ; )
        switch (l.prev = l.next) {
          case 0:
            return n = 0, l.abrupt("return", new Promise(function(u) {
              e.forEach(function(s) {
                s.then(function(d) {
                  d.errors.length && u([d]), n += 1, n === e.length && u([]);
                });
              });
            }));
          case 2:
          case "end":
            return l.stop();
        }
    }, a);
  })), xe.apply(this, arguments);
}
var Ge = Symbol("formContextKey"), ze = function(e) {
  provide(Ge, e);
}, Pe = function() {
  return inject(Ge, { name: computed(function() {
  }), labelAlign: computed(function() {
    return "right";
  }), vertical: computed(function() {
    return false;
  }), addField: function(n, r) {
  }, removeField: function(n) {
  }, model: computed(function() {
  }), rules: computed(function() {
  }), colon: computed(function() {
  }), labelWrap: computed(function() {
  }), labelCol: computed(function() {
  }), requiredMark: computed(function() {
    return false;
  }), validateTrigger: computed(function() {
  }), onValidate: function() {
  }, validateMessages: computed(function() {
    return ve;
  }) });
}, Je = Symbol("formItemPrefixContextKey"), Or = function(e) {
  provide(Je, e);
}, Mr = function() {
  return inject(Je, { prefixCls: computed(function() {
    return "";
  }) });
}, ke = function(e, n) {
  var r, l, u, s, d = n.slots, h = n.emit, y = n.attrs, f = v$1(v$1({}, e), y), m = f.prefixCls, V = f.htmlFor, O = f.labelCol, A = f.labelAlign, b = f.colon, P = f.required, k = f.requiredMark, j = Ti("Form"), q = xe$1(j, 1), i = q[0], c = (r = e.label) !== null && r !== void 0 ? r : (l = d.label) === null || l === void 0 ? void 0 : l.call(d);
  if (!c)
    return null;
  var p = Pe(), $ = p.vertical, I = p.labelAlign, x$1 = p.labelCol, W = p.labelWrap, N = p.colon, E = O || (x$1 == null ? void 0 : x$1.value) || {}, U = A || (I == null ? void 0 : I.value), D = "".concat(m, "-item-label"), L = pe(D, U === "left" && "".concat(D, "-left"), E.class, x({}, "".concat(D, "-wrap"), !!W.value)), _ = c, v = b === true || (N == null ? void 0 : N.value) !== false && b !== false, F = v && !$.value;
  if (F && typeof c == "string" && c.trim() !== "" && (_ = c.replace(/[:|：]\s*$/, "")), _ = createVNode(Fragment, null, [_, (u = d.tooltip) === null || u === void 0 ? void 0 : u.call(d, { class: "".concat(m, "-item-tooltip") })]), k === "optional" && !P) {
    var t, o;
    _ = createVNode(Fragment, null, [_, createVNode("span", { class: "".concat(m, "-item-optional") }, [((t = i.value) === null || t === void 0 ? void 0 : t.optional) || ((o = we$1.Form) === null || o === void 0 ? void 0 : o.optional)])]);
  }
  var C = pe((s = {}, x(s, "".concat(m, "-item-required"), P), x(s, "".concat(m, "-item-required-mark-optional"), k === "optional"), x(s, "".concat(m, "-item-no-colon"), !v), s));
  return createVNode(xo, v$1(v$1({}, E), {}, { class: L }), { default: function() {
    return [createVNode("label", { for: V, class: C, title: typeof c == "string" ? c : "", onClick: function(K) {
      return h("click", K);
    } }, [_])];
  } });
};
ke.displayName = "FormItemLabel";
ke.inheritAttrs = false;
const Sr = ke, _r = defineComponent({ compatConfig: { MODE: 3 }, name: "ErrorList", props: ["errors", "help", "onDomErrorVisibleChange", "helpStatus", "warnings"], setup: function(e) {
  var n = ke$1("", e), r = n.prefixCls, l = Mr(), u = l.prefixCls, s = l.status, d = computed(function() {
    return "".concat(u.value, "-item-explain");
  }), h = computed(function() {
    return !!(e.errors && e.errors.length);
  }), y = ref(s.value);
  return watch([h, s], function() {
    h.value && (y.value = s.value);
  }), function() {
    var f, m, V = Zo("".concat(r.value, "-show-help-item")), O = Vo("".concat(r.value, "-show-help-item"), V);
    return O.class = d.value, (f = e.errors) !== null && f !== void 0 && f.length ? createVNode(TransitionGroup, v$1(v$1({}, O), {}, { tag: "div" }), { default: function() {
      return [(m = e.errors) === null || m === void 0 ? void 0 : m.map(function(b, P) {
        return createVNode("div", { key: P, role: "alert", class: y.value ? "".concat(d.value, "-").concat(y.value) : "" }, [b]);
      })];
    } }) : null;
  };
} });
var Er = { success: an, warning: hr, error: rn, validating: ze$1 }, Rr = defineComponent({ compatConfig: { MODE: 3 }, slots: ["help", "extra", "errors"], inheritAttrs: false, props: ["prefixCls", "errors", "hasFeedback", "onDomErrorVisibleChange", "wrapperCol", "help", "extra", "status"], setup: function(e, n) {
  var r = n.slots, l = Pe(), u = l.wrapperCol, s = v$1({}, l);
  return delete s.labelCol, delete s.wrapperCol, ze(s), Or({ prefixCls: computed(function() {
    return e.prefixCls;
  }), status: computed(function() {
    return e.status;
  }) }), function() {
    var d, h, y, f = e.prefixCls, m = e.wrapperCol, V = e.help, O = V === void 0 ? (d = r.help) === null || d === void 0 ? void 0 : d.call(r) : V, A = e.errors, b = A === void 0 ? (h = r.errors) === null || h === void 0 ? void 0 : h.call(r) : A, P = e.hasFeedback, k = e.status, j = e.extra, q = j === void 0 ? (y = r.extra) === null || y === void 0 ? void 0 : y.call(r) : j, i = "".concat(f, "-item"), c = m || (u == null ? void 0 : u.value) || {}, p = pe("".concat(i, "-control"), c.class), $ = k && Er[k];
    return createVNode(xo, v$1(v$1({}, c), {}, { class: p }), { default: function() {
      var x;
      return createVNode(Fragment, null, [createVNode("div", { class: "".concat(i, "-control-input") }, [createVNode("div", { class: "".concat(i, "-control-input-content") }, [(x = r.default) === null || x === void 0 ? void 0 : x.call(r)]), P && $ ? createVNode("span", { class: "".concat(i, "-children-icon") }, [createVNode($, null, null)]) : null]), createVNode(_r, { errors: b, help: O, class: "".concat(i, "-explain-connected") }, null), q ? createVNode("div", { class: "".concat(i, "-extra") }, [q]) : null]);
    } });
  };
} });
const Nr = Rr;
function Lr(a) {
  var e = shallowRef(a.value.slice()), n = null;
  return watchEffect(function() {
    clearTimeout(n), n = setTimeout(function() {
      e.value = a.value;
    }, a.value.length ? 0 : 10);
  }), e;
}
Eo("success", "warning", "error", "validating", "");
function ge(a, e, n) {
  var r = a, l = e, u = 0;
  try {
    for (var s = l.length; u < s - 1 && !(!r && !n); ++u) {
      var d = l[u];
      if (d in r)
        r = r[d];
      else {
        if (n)
          throw Error("please transfer a valid name path to form item!");
        break;
      }
    }
    if (n && !r)
      throw Error("please transfer a valid name path to form item!");
  } catch {
  }
  return { o: r, k: l[u], v: r ? r[l[u]] : void 0 };
}
var Tr = function() {
  return { htmlFor: String, prefixCls: String, label: pt.any, help: pt.any, extra: pt.any, labelCol: { type: Object }, wrapperCol: { type: Object }, hasFeedback: { type: Boolean, default: false }, colon: { type: Boolean, default: void 0 }, labelAlign: pt.oneOf(Eo("left", "right")), prop: { type: [String, Number, Array] }, name: { type: [String, Number, Array] }, rules: [Array, Object], autoLink: { type: Boolean, default: true }, required: { type: Boolean, default: void 0 }, validateFirst: { type: Boolean, default: void 0 }, validateStatus: pt.oneOf(Eo("", "success", "warning", "error", "validating")), validateTrigger: { type: [String, Array] }, messageVariables: { type: Object }, hidden: Boolean, noStyle: Boolean };
}, Br = 0, Dr = "form_item";
const Wr = defineComponent({ compatConfig: { MODE: 3 }, name: "AFormItem", inheritAttrs: false, __ANT_NEW_FORM_ITEM: true, props: Tr(), slots: ["help", "label", "extra"], setup: function(e, n) {
  var r = n.slots, l = n.attrs, u = n.expose;
  Fo(e.prop === void 0);
  var s = "form-item-".concat(++Br), d = ke$1("form", e), h = d.prefixCls, y = Pe(), f = computed(function() {
    return e.name || e.prop;
  }), m = ref([]), V = ref(false), O = ref(), A = computed(function() {
    var t = f.value;
    return Fe(t);
  }), b = computed(function() {
    if (A.value.length) {
      var t = y.name.value, o = A.value.join("_");
      return t ? "".concat(t, "_").concat(o) : "".concat(Dr, "_").concat(o);
    } else
      return;
  }), P = function() {
    var o = y.model.value;
    if (!(!o || !f.value))
      return ge(o, A.value, true).v;
  }, k = computed(function() {
    return P();
  }), j = ref(oe(k.value)), q = computed(function() {
    var t = e.validateTrigger !== void 0 ? e.validateTrigger : y.validateTrigger.value;
    return t = t === void 0 ? "change" : t, Z(t);
  }), i = computed(function() {
    var t = y.rules.value, o = e.rules, C = e.required !== void 0 ? { required: !!e.required, trigger: q.value } : [], M = ge(t, A.value);
    t = t ? M.o[M.k] || M.v : [];
    var R = [].concat(o || t || []);
    return dr(R, function(K) {
      return K.required;
    }) ? R : R.concat(C);
  }), c = computed(function() {
    var t = i.value, o = false;
    return t && t.length && t.every(function(C) {
      return C.required ? (o = true, false) : true;
    }), o || e.required;
  }), p = ref();
  watchEffect(function() {
    p.value = e.validateStatus;
  });
  var $ = computed(function() {
    var t = {};
    return typeof e.label == "string" ? t.label = e.label : e.name && (t.label = String(name)), e.messageVariables && (t = v$1(v$1({}, t), e.messageVariables)), t;
  }), I = function(o) {
    if (A.value.length !== 0) {
      var C = e.validateFirst, M = C === void 0 ? false : C, R = o || {}, K = R.triggerName, T = i.value;
      if (K && (T = T.filter(function(G) {
        var re = G.trigger;
        if (!re && !q.value.length)
          return true;
        var H = Z(re || q.value);
        return H.includes(K);
      })), !T.length)
        return Promise.resolve();
      var J = Ke(A.value, k.value, T, v$1({ validateMessages: y.validateMessages.value }, o), M, $.value);
      return p.value = "validating", m.value = [], J.catch(function(G) {
        return G;
      }).then(function() {
        var G = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [];
        if (p.value === "validating") {
          var re = G.filter(function(H) {
            return H && H.errors.length;
          });
          p.value = re.length ? "error" : "success", m.value = re.map(function(H) {
            return H.errors;
          }), y.onValidate(f.value, !m.value.length, m.value.length ? toRaw(m.value[0]) : null);
        }
      }), J;
    }
  }, x$1 = function() {
    I({ triggerName: "blur" });
  }, W = function() {
    if (V.value) {
      V.value = false;
      return;
    }
    I({ triggerName: "change" });
  }, N = function() {
    p.value = e.validateStatus, V.value = false, m.value = [];
  }, E = function() {
    p.value = e.validateStatus, V.value = true, m.value = [];
    var o = y.model.value || {}, C = k.value, M = ge(o, A.value, true);
    Array.isArray(C) ? M.o[M.k] = [].concat(j.value) : M.o[M.k] = j.value, nextTick(function() {
      V.value = false;
    });
  }, U = computed(function() {
    return e.htmlFor === void 0 ? b.value : e.htmlFor;
  }), D = function() {
    var o = U.value;
    if (!(!o || !O.value)) {
      var C = O.value.$el.querySelector('[id="'.concat(o, '"]'));
      C && C.focus && C.focus();
    }
  };
  u({ onFieldBlur: x$1, onFieldChange: W, clearValidate: N, resetField: E }), qo({ id: b, onFieldBlur: function() {
    e.autoLink && x$1();
  }, onFieldChange: function() {
    e.autoLink && W();
  }, clearValidate: N }, computed(function() {
    return !!(e.autoLink && y.model.value && f.value);
  }));
  var L = false;
  watch(f, function(t) {
    t ? L || (L = true, y.addField(s, { fieldValue: k, fieldId: b, fieldName: f, resetField: E, clearValidate: N, namePath: A, validateRules: I, rules: i })) : (L = false, y.removeField(s));
  }, { immediate: true });
  var _ = Lr(m), v = computed(function() {
    return e.validateStatus !== void 0 ? e.validateStatus : _.value.length ? "error" : p.value;
  }), F = computed(function() {
    var t;
    return t = {}, x(t, "".concat(h.value, "-item"), true), x(t, "".concat(h.value, "-item-has-feedback"), v.value && e.hasFeedback), x(t, "".concat(h.value, "-item-has-success"), v.value === "success"), x(t, "".concat(h.value, "-item-has-warning"), v.value === "warning"), x(t, "".concat(h.value, "-item-has-error"), v.value === "error"), x(t, "".concat(h.value, "-item-is-validating"), v.value === "validating"), x(t, "".concat(h.value, "-item-hidden"), e.hidden), t;
  });
  return function() {
    var t, o;
    if (e.noStyle)
      return (t = r.default) === null || t === void 0 ? void 0 : t.call(r);
    var C = (o = e.help) !== null && o !== void 0 ? o : r.help ? Mt(r.help()) : null;
    return createVNode(yo, v$1(v$1({}, l), {}, { class: [F.value, C != null || _.value.length ? "".concat(h.value, "-item-with-help") : "", l.class], key: "row" }), { default: function() {
      var R, K, T, J;
      return createVNode(Fragment, null, [createVNode(Sr, v$1(v$1({}, e), {}, { htmlFor: U.value, required: c.value, requiredMark: y.requiredMark.value, prefixCls: h.value, onClick: D, label: (R = e.label) !== null && R !== void 0 ? R : (K = r.label) === null || K === void 0 ? void 0 : K.call(r) }), null), createVNode(Nr, v$1(v$1({}, e), {}, { errors: C != null ? Z(C) : _.value, prefixCls: h.value, status: v.value, ref: O, help: C, extra: (T = e.extra) !== null && T !== void 0 ? T : (J = r.extra) === null || J === void 0 ? void 0 : J.call(r) }), { default: r.default })]);
    } });
  };
} });
function Ue(a) {
  var e = false, n = a.length, r = [];
  return a.length ? new Promise(function(l, u) {
    a.forEach(function(s, d) {
      s.catch(function(h) {
        return e = true, h;
      }).then(function(h) {
        n -= 1, r[d] = h, !(n > 0) && (e && u(r), l(r));
      });
    });
  }) : Promise.resolve([]);
}
function Ie(a) {
  var e = false;
  return a && a.length && a.every(function(n) {
    return n.required ? (e = true, false) : true;
  }), e;
}
function Oe(a) {
  return a == null ? [] : Array.isArray(a) ? a : [a];
}
function he(a, e, n) {
  var r = a;
  e = e.replace(/\[(\w+)\]/g, ".$1"), e = e.replace(/^\./, "");
  for (var l = e.split("."), u = 0, s = l.length; u < s - 1 && !(!r && !n); ++u) {
    var d = l[u];
    if (d in r)
      r = r[d];
    else {
      if (n)
        throw new Error("please transfer a valid name path to validate!");
      break;
    }
  }
  return { o: r, k: l[u], v: r ? r[l[u]] : null, isValid: r && l[u] in r };
}
function Kr(a) {
  var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : ref({}), n = arguments.length > 2 ? arguments[2] : void 0, r = oe(unref(a)), l = reactive({}), u = shallowRef([]), s = function(i) {
    ce(unref(a), v$1(v$1({}, oe(r)), i)), nextTick(function() {
      Object.keys(l).forEach(function(c) {
        l[c] = { autoLink: false, required: Ie(unref(e)[c]) };
      });
    });
  }, d = function() {
    var i = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], c = arguments.length > 1 ? arguments[1] : void 0;
    return c.length ? i.filter(function(p) {
      var $ = Oe(p.trigger || "change");
      return Fr($, c).length;
    }) : i;
  }, h = null, y = function(i) {
    for (var c = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, p = arguments.length > 2 ? arguments[2] : void 0, $ = [], I = {}, x = function() {
      var L = i[W], _ = he(unref(a), L, p);
      if (!_.isValid)
        return "continue";
      I[L] = _.v;
      var v = d(unref(e)[L], Oe(c && c.trigger));
      v.length && $.push(f(L, _.v, v, c || {}).then(function() {
        return { name: L, errors: [], warnings: [] };
      }).catch(function(F) {
        var t = [], o = [];
        return F.forEach(function(C) {
          var M = C.rule.warningOnly, R = C.errors;
          M ? o.push.apply(o, fe(R)) : t.push.apply(t, fe(R));
        }), t.length ? Promise.reject({ name: L, errors: t, warnings: o }) : { name: L, errors: t, warnings: o };
      }));
    }, W = 0; W < i.length; W++)
      var N = x();
    var E = Ue($);
    h = E;
    var U = E.then(function() {
      return h === E ? Promise.resolve(I) : Promise.reject([]);
    }).catch(function(D) {
      var L = D.filter(function(_) {
        return _ && _.errors.length;
      });
      return Promise.reject({ values: I, errorFields: L, outOfDate: h !== E });
    });
    return U.catch(function(D) {
      return D;
    }), U;
  }, f = function(i, c, p) {
    var $ = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {}, I = Ke([i], c, p, v$1({ validateMessages: ve }, $), !!$.validateFirst);
    return l[i] ? (l[i].validateStatus = "validating", I.catch(function(x) {
      return x;
    }).then(function() {
      var x = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [];
      if (l[i].validateStatus === "validating") {
        var W, N = x.filter(function(E) {
          return E && E.errors.length;
        });
        l[i].validateStatus = N.length ? "error" : "success", l[i].help = N.length ? N.map(function(E) {
          return E.errors;
        }) : null, n == null || (W = n.onValidate) === null || W === void 0 || W.call(n, i, !N.length, N.length ? toRaw(l[i].help[0]) : null);
      }
    }), I) : I.catch(function(x) {
      return x;
    });
  }, m = function(i, c) {
    var p = [], $ = true;
    i ? Array.isArray(i) ? p = i : p = [i] : ($ = false, p = u.value);
    var I = y(p, c || {}, $);
    return I.catch(function(x) {
      return x;
    }), I;
  }, V = function(i) {
    var c = [];
    i ? Array.isArray(i) ? c = i : c = [i] : c = u.value, c.forEach(function(p) {
      l[p] && ce(l[p], { validateStatus: "", help: null });
    });
  }, O = function(i) {
    for (var c = { autoLink: false }, p = [], $ = Array.isArray(i) ? i : [i], I = 0; I < $.length; I++) {
      var x = $[I];
      (x == null ? void 0 : x.validateStatus) === "error" && (c.validateStatus = "error", x.help && p.push(x.help)), c.required = c.required || (x == null ? void 0 : x.required);
    }
    return c.help = p, c;
  }, A = r, b = true, P = function(i) {
    var c = [];
    u.value.forEach(function(p) {
      var $ = he(i, p, false), I = he(A, p, false), x = b && (n == null ? void 0 : n.immediate) && $.isValid;
      (x || !Te($.v, I.v)) && c.push(p);
    }), m(c, { trigger: "change" }), b = false, A = oe(toRaw(i));
  }, k = n == null ? void 0 : n.debounce, j = true;
  return watch(e, function() {
    u.value = e ? Object.keys(unref(e)) : [], !j && n && n.validateOnRuleChange && m(), j = false;
  }, { deep: true, immediate: true }), watch(u, function() {
    var q = {};
    u.value.forEach(function(c) {
      q[c] = ce({}, l[c], { autoLink: false, required: Ie(unref(e)[c]) }), delete l[c];
    });
    for (var i in l)
      Object.prototype.hasOwnProperty.call(l, i) && delete l[i];
    ce(l, q);
  }, { immediate: true }), watch(a, k && k.wait ? yr(P, k.wait, Cr(k, ["wait"])) : P, { immediate: n && !!n.immediate, deep: true }), { modelRef: a, rulesRef: e, initialModel: r, validateInfos: l, resetFields: s, validate: m, validateField: f, mergeValidateInfo: O, clearValidate: V };
}
var Gr = function() {
  return { layout: pt.oneOf(Eo("horizontal", "inline", "vertical")), labelCol: { type: Object }, wrapperCol: { type: Object }, colon: { type: Boolean, default: void 0 }, labelAlign: pt.oneOf(Eo("left", "right")), labelWrap: { type: Boolean, default: void 0 }, prefixCls: String, requiredMark: { type: [String, Boolean], default: void 0 }, hideRequiredMark: { type: Boolean, default: void 0 }, model: pt.object, rules: { type: Object }, validateMessages: { type: Object, default: void 0 }, validateOnRuleChange: { type: Boolean, default: void 0 }, scrollToFirstError: { type: [Boolean, Object] }, onSubmit: Function, name: String, validateTrigger: { type: [String, Array] }, size: { type: String }, onValuesChange: { type: Function }, onFieldsChange: { type: Function }, onFinish: { type: Function }, onFinishFailed: { type: Function }, onValidate: { type: Function } };
};
function zr(a, e) {
  return Te(Z(a), Z(e));
}
var Jr = defineComponent({ compatConfig: { MODE: 3 }, name: "AForm", inheritAttrs: false, props: bt(Gr(), { layout: "horizontal", hideRequiredMark: false, colon: true }), Item: Wr, useForm: Kr, setup: function(e, n) {
  var r = n.emit, l = n.slots, u = n.expose, s = n.attrs, d = J(e), h = ke$1("form", e), y = h.prefixCls, f = h.direction, m = h.form, V = computed(function() {
    return e.requiredMark === "" || e.requiredMark;
  }), O = computed(function() {
    var v;
    return V.value !== void 0 ? V.value : m && ((v = m.value) === null || v === void 0 ? void 0 : v.requiredMark) !== void 0 ? m.value.requiredMark : !e.hideRequiredMark;
  }), A = computed(function() {
    var v, F;
    return (v = e.colon) !== null && v !== void 0 ? v : (F = m.value) === null || F === void 0 ? void 0 : F.colon;
  }), b = Oi(), P = b.validateMessages, k = computed(function() {
    return v$1(v$1(v$1({}, ve), P.value), e.validateMessages);
  }), j = computed(function() {
    var v;
    return pe(y.value, (v = {}, x(v, "".concat(y.value, "-").concat(e.layout), true), x(v, "".concat(y.value, "-hide-required-mark"), O.value === false), x(v, "".concat(y.value, "-rtl"), f.value === "rtl"), x(v, "".concat(y.value, "-").concat(d.value), d.value), v));
  }), q = ref(), i = {}, c = function(F, t) {
    i[F] = t;
  }, p = function(F) {
    delete i[F];
  }, $ = function(F) {
    var t = !!F, o = t ? Z(F).map(Fe) : [];
    return t ? Object.values(i).filter(function(C) {
      return o.findIndex(function(M) {
        return zr(M, C.fieldName.value);
      }) > -1;
    }) : Object.values(i);
  }, I = function(F) {
    if (!e.model) {
      Ho(false, "Form", "model is required for resetFields to work.");
      return;
    }
    $(F).forEach(function(t) {
      t.resetField();
    });
  }, x$1 = function(F) {
    $(F).forEach(function(t) {
      t.clearValidate();
    });
  }, W = function(F) {
    var t = e.scrollToFirstError;
    if (r("finishFailed", F), t && F.errorFields.length) {
      var o = {};
      ee$1(t) === "object" && (o = t), E(F.errorFields[0].name, o);
    }
  }, N = function() {
    return L.apply(void 0, arguments);
  }, E = function(F) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, o = $(F ? [F] : void 0);
    if (o.length) {
      var C = o[0].fieldId.value, M = C ? document.getElementById(C) : null;
      M && scrollIntoView(M, v$1({ scrollMode: "if-needed", block: "nearest" }, t));
    }
  }, U = function() {
    var F = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : true;
    if (F === true) {
      var t = [];
      return Object.values(i).forEach(function(o) {
        var C = o.namePath;
        t.push(C.value);
      }), qe(e.model, t);
    } else
      return qe(e.model, F);
  }, D = function(F, t) {
    if (Ho(!(F instanceof Function), "Form", "validateFields/validateField/validate not support callback, please use promise instead"), !e.model)
      return Ho(false, "Form", "model is required for validateFields to work."), Promise.reject("Form `model` is required for validateFields to work.");
    var o = !!F, C = o ? Z(F).map(Fe) : [], M = [];
    Object.values(i).forEach(function(T) {
      var J;
      if (o || C.push(T.namePath.value), !!((J = T.rules) !== null && J !== void 0 && J.value.length)) {
        var G = T.namePath.value;
        if (!o || Pr(C, G)) {
          var re = T.validateRules(v$1({ validateMessages: k.value }, t));
          M.push(re.then(function() {
            return { name: G, errors: [], warnings: [] };
          }).catch(function(H) {
            var te = [], ie = [];
            return H.forEach(function(Ve) {
              var Ye = Ve.rule.warningOnly, Ae = Ve.errors;
              Ye ? ie.push.apply(ie, fe(Ae)) : te.push.apply(te, fe(Ae));
            }), te.length ? Promise.reject({ name: G, errors: te, warnings: ie }) : { name: G, errors: te, warnings: ie };
          }));
        }
      }
    });
    var R = Ue(M);
    q.value = R;
    var K = R.then(function() {
      return q.value === R ? Promise.resolve(U(C)) : Promise.reject([]);
    }).catch(function(T) {
      var J = T.filter(function(G) {
        return G && G.errors.length;
      });
      return Promise.reject({ values: U(C), errorFields: J, outOfDate: q.value !== R });
    });
    return K.catch(function(T) {
      return T;
    }), K;
  }, L = function() {
    return D.apply(void 0, arguments);
  }, _ = function(F) {
    if (F.preventDefault(), F.stopPropagation(), r("submit", F), e.model) {
      var t = D();
      t.then(function(o) {
        r("finish", o);
      }).catch(function(o) {
        W(o);
      });
    }
  };
  return u({ resetFields: I, clearValidate: x$1, validateFields: D, getFieldsValue: U, validate: N, scrollToField: E }), ze({ model: computed(function() {
    return e.model;
  }), name: computed(function() {
    return e.name;
  }), labelAlign: computed(function() {
    return e.labelAlign;
  }), labelCol: computed(function() {
    return e.labelCol;
  }), labelWrap: computed(function() {
    return e.labelWrap;
  }), wrapperCol: computed(function() {
    return e.wrapperCol;
  }), vertical: computed(function() {
    return e.layout === "vertical";
  }), colon: A, requiredMark: O, validateTrigger: computed(function() {
    return e.validateTrigger;
  }), rules: computed(function() {
    return e.rules;
  }), addField: c, removeField: p, onValidate: function(F, t, o) {
    r("validate", F, t, o);
  }, validateMessages: k }), watch(function() {
    return e.rules;
  }, function() {
    e.validateOnRuleChange && D();
  }), function() {
    var v;
    return createVNode("form", v$1(v$1({}, s), {}, { onSubmit: _, class: [j.value, s.class] }), [(v = l.default) === null || v === void 0 ? void 0 : v.call(l)]);
  };
} });
const Fa = Jr;

export { B, C, Fa as F, M, V, Wr as W, b, w };
//# sourceMappingURL=Form-624e1339.mjs.map
