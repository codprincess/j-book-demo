import { defineComponent, ref, onUpdated, getCurrentInstance, createVNode, computed, Transition, withDirectives, vShow, watch, watchEffect, createElementVNode, nextTick, Fragment, withAsyncContext, withCtx, createTextVNode, unref, isRef, withModifiers, openBlock, createBlock, createCommentVNode, renderList, toDisplayString, useSSRContext, render, createElementBlock } from 'vue';
import { a as pt, R as Ri, p as pe, T as Ti, k as ke, b as Ai, t as tn, E as Ea$1, c as An, D as Dn, M as Mn, Y as Yt, $, W as Wr, B as Be, d as Br, s as se, e as N } from '../server.mjs';
import { X as Xe, b as bt, C as Ce, A as At$1, J as Jo, Q as Qo, r as re, a as ri, l as li, s as si, e as ei, t as ti, o as oi } from './useHttpFetch-0d93f309.mjs';
import { D as Dt$1, l as lr, L as Le, _ as _e, n as nn } from './index-4f8e2b3b.mjs';
import { ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import St from '@bytemd/plugin-gfm';
import { Editor } from '@bytemd/vue-next';
import { debounce } from 'lodash-es';
import x from '@babel/runtime/helpers/esm/defineProperty';
import he from '@babel/runtime/helpers/esm/objectWithoutProperties';
import v from '@babel/runtime/helpers/esm/objectSpread2';
import xe from '@babel/runtime/helpers/esm/slicedToArray';
import { m } from './pickAttrs-bd971e90.mjs';
import ce from '@babel/runtime/helpers/esm/extends';
import fe from '@babel/runtime/helpers/esm/toConsumableArray';
import Bn from '@babel/runtime/helpers/esm/objectDestructuringEmpty';
import jn from '@babel/runtime/helpers/esm/createClass';
import En from '@babel/runtime/helpers/esm/classCallCheck';
import { v as v4 } from '../../v4.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import 'ufo';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import '@babel/runtime/helpers/esm/typeof';
import 'vue-types';
import '@ant-design/colors';
import '@ctrl/tinycolor';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';
import 'dom-align';
import 'resize-observer-polyfill';
import 'lodash-es/isEqual.js';
import 'lodash-es/uniq.js';
import 'lodash-es/isPlainObject.js';
import 'crypto';

function Jt(o2) {
  return 0;
}
function et(o2) {
  var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, i = e.element, l = i === void 0 ? document.body : i, a = {}, d = Object.keys(o2);
  return d.forEach(function(y) {
    a[y] = l.style[y];
  }), d.forEach(function(y) {
    l.style[y] = o2[y];
  }), a;
}
function Fn() {
  return document.body.scrollHeight > (window.innerHeight || document.documentElement.clientHeight) && window.innerWidth > document.body.offsetWidth;
}
var kt = {};
const zn = function(o2) {
  if (!(!Fn() && !o2)) {
    var e = "ant-scrolling-effect", i = new RegExp("".concat(e), "g"), l = document.body.className;
    if (o2) {
      if (!i.test(l))
        return;
      et(kt), kt = {}, document.body.className = l.replace(i, "").trim();
      return;
    }
    var a = Jt();
    if (a && (kt = et({ position: "relative", width: "calc(100% - ".concat(a, "px)") }), !i.test(l))) {
      var d = "".concat(l, " ").concat(e);
      document.body.className = d.trim();
    }
  }
};
var oe = [], Qt = "ant-scrolling-effect", _t = new RegExp("".concat(Qt), "g"), Ln = 0, ht = /* @__PURE__ */ new Map(), Vn = jn(function o(e) {
  var i = this;
  En(this, o), x(this, "getContainer", function() {
    var l;
    return (l = i.options) === null || l === void 0 ? void 0 : l.container;
  }), x(this, "reLock", function(l) {
    var a = oe.find(function(d) {
      var y = d.target;
      return y === i.lockTarget;
    });
    a && i.unLock(), i.options = l, a && (a.options = l, i.lock());
  }), x(this, "lock", function() {
    var l;
    if (!oe.some(function(f) {
      var _ = f.target;
      return _ === i.lockTarget;
    })) {
      if (oe.some(function(f) {
        var _, g = f.options;
        return (g == null ? void 0 : g.container) === ((_ = i.options) === null || _ === void 0 ? void 0 : _.container);
      })) {
        oe = [].concat(fe(oe), [{ target: i.lockTarget, options: i.options }]);
        return;
      }
      var a = 0, d = ((l = i.options) === null || l === void 0 ? void 0 : l.container) || document.body;
      (d === document.body && window.innerWidth - document.documentElement.clientWidth > 0 || d.scrollHeight > d.clientHeight) && (a = Jt());
      var y = d.className;
      if (oe.filter(function(f) {
        var _, g = f.options;
        return (g == null ? void 0 : g.container) === ((_ = i.options) === null || _ === void 0 ? void 0 : _.container);
      }).length === 0 && ht.set(d, et({ width: a !== 0 ? "calc(100% - ".concat(a, "px)") : void 0, overflow: "hidden", overflowX: "hidden", overflowY: "hidden" }, { element: d })), !_t.test(y)) {
        var N = "".concat(y, " ").concat(Qt);
        d.className = N.trim();
      }
      oe = [].concat(fe(oe), [{ target: i.lockTarget, options: i.options }]);
    }
  }), x(this, "unLock", function() {
    var l, a = oe.find(function(N) {
      var f = N.target;
      return f === i.lockTarget;
    });
    if (oe = oe.filter(function(N) {
      var f = N.target;
      return f !== i.lockTarget;
    }), !(!a || oe.some(function(N) {
      var f, _ = N.options;
      return (_ == null ? void 0 : _.container) === ((f = a.options) === null || f === void 0 ? void 0 : f.container);
    }))) {
      var d = ((l = i.options) === null || l === void 0 ? void 0 : l.container) || document.body, y = d.className;
      _t.test(y) && (et(ht.get(d), { element: d }), ht.delete(d), d.className = d.className.replace(_t, "").trim());
    }
  }), this.lockTarget = Ln++, this.options = e;
}), Un = 0, jt = {}, Et = function(e) {
  return null;
};
const Hn = defineComponent({ compatConfig: { MODE: 3 }, name: "PortalWrapper", inheritAttrs: false, props: { wrapperClassName: String, forceRender: { type: Boolean, default: void 0 }, getContainer: pt.any, visible: { type: Boolean, default: void 0 } }, setup: function(e, i) {
  var l = i.slots, a = ref(), d = ref();
  ref();
  var y = new Vn({ container: Et(e.getContainer) }), N = function() {
    var c = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
    if (c || a.value && !a.value.parentNode) {
      var p = Et(e.getContainer);
      return p ? (p.appendChild(a.value), true) : false;
    }
    return true;
  }, f = function() {
    return null;
  }, _ = function() {
    var c = e.wrapperClassName;
    a.value && c && c !== a.value.className && (a.value.className = c);
  };
  onUpdated(function() {
    _(), N();
  });
  var g = function() {
    et(jt), jt = {}, zn(true);
  };
  return getCurrentInstance(), function() {
    var v = e.forceRender, c = e.visible, p = null, C = { getOpenCount: function() {
      return Un;
    }, getContainer: f, switchScrollingEffect: g, scrollLocker: y };
    return (v || c || d.value) && (p = createVNode(Xe, { getContainer: f, ref: d }, { default: function() {
      var O;
      return (O = l.default) === null || O === void 0 ? void 0 : O.call(l, C);
    } })), p;
  };
} });
function xt() {
  return { keyboard: { type: Boolean, default: void 0 }, mask: { type: Boolean, default: void 0 }, afterClose: Function, closable: { type: Boolean, default: void 0 }, maskClosable: { type: Boolean, default: void 0 }, visible: { type: Boolean, default: void 0 }, destroyOnClose: { type: Boolean, default: void 0 }, mousePosition: pt.shape({ x: Number, y: Number }).loose, title: pt.any, footer: pt.any, transitionName: String, maskTransitionName: String, animation: pt.any, maskAnimation: pt.any, wrapStyle: { type: Object, default: void 0 }, bodyStyle: { type: Object, default: void 0 }, maskStyle: { type: Object, default: void 0 }, prefixCls: String, wrapClassName: String, rootClassName: String, width: [String, Number], height: [String, Number], zIndex: Number, bodyProps: pt.any, maskProps: pt.any, wrapProps: pt.any, getContainer: pt.any, dialogStyle: { type: Object, default: void 0 }, dialogClass: String, closeIcon: pt.any, forceRender: { type: Boolean, default: void 0 }, getOpenCount: Function, focusTriggerAfterClose: { type: Boolean, default: void 0 }, onClose: Function, modalRender: Function };
}
function Rt(o2, e, i) {
  var l = e;
  return !l && i && (l = "".concat(o2, "-").concat(i)), l;
}
var At = -1;
function Wn() {
  return At += 1, At;
}
function Dt(o2, e) {
  var i = o2["page".concat(e ? "Y" : "X", "Offset")], l = "scroll".concat(e ? "Top" : "Left");
  if (typeof i != "number") {
    var a = o2.document;
    i = a.documentElement[l], typeof i != "number" && (i = a.body[l]);
  }
  return i;
}
function In(o2) {
  var e = o2.getBoundingClientRect(), i = { left: e.left, top: e.top }, l = o2.ownerDocument, a = l.defaultView || l.parentWindow;
  return i.left += Dt(a), i.top += Dt(a, true), i;
}
var Mt = { width: 0, height: 0, overflow: "hidden", outline: "none" };
const Kn = defineComponent({ compatConfig: { MODE: 3 }, name: "Content", inheritAttrs: false, props: v(v({}, xt()), {}, { motionName: String, ariaId: String, onVisibleChanged: Function, onMousedown: Function, onMouseup: Function }), setup: function(e, i) {
  var l = i.expose, a = i.slots, d = i.attrs, y = ref(), N = ref(), f = ref();
  l({ focus: function() {
    var C;
    (C = y.value) === null || C === void 0 || C.focus();
  }, changeActive: function(C) {
    var h = document, O = h.activeElement;
    C && O === N.value ? y.value.focus() : !C && O === y.value && N.value.focus();
  } });
  var _ = ref(), g = computed(function() {
    var p = e.width, C = e.height, h = {};
    return p !== void 0 && (h.width = typeof p == "number" ? "".concat(p, "px") : p), C !== void 0 && (h.height = typeof C == "number" ? "".concat(C, "px") : C), _.value && (h.transformOrigin = _.value), h;
  }), v$1 = function() {
    nextTick(function() {
      if (f.value) {
        var C = In(f.value);
        _.value = e.mousePosition ? "".concat(e.mousePosition.x - C.left, "px ").concat(e.mousePosition.y - C.top, "px") : "";
      }
    });
  }, c = function(C) {
    e.onVisibleChanged(C);
  };
  return function() {
    var p, C, h, O, R = e.prefixCls, w = e.footer, $ = w === void 0 ? (p = a.footer) === null || p === void 0 ? void 0 : p.call(a) : w, B = e.title, U = B === void 0 ? (C = a.title) === null || C === void 0 ? void 0 : C.call(a) : B, K = e.ariaId, L = e.closable, Z = e.closeIcon, G = Z === void 0 ? (h = a.closeIcon) === null || h === void 0 ? void 0 : h.call(a) : Z, le = e.onClose, q = e.bodyStyle, X = e.bodyProps, me = e.onMousedown, ge = e.onMouseup, te = e.visible, re = e.modalRender, ne = re === void 0 ? a.modalRender : re, je = e.destroyOnClose, S = e.motionName, ye;
    $ && (ye = createVNode("div", { class: "".concat(R, "-footer") }, [$]));
    var z;
    U && (z = createVNode("div", { class: "".concat(R, "-header") }, [createVNode("div", { class: "".concat(R, "-title"), id: K }, [U])]));
    var Le;
    L && (Le = createVNode("button", { type: "button", onClick: le, "aria-label": "Close", class: "".concat(R, "-close") }, [G || createVNode("span", { class: "".concat(R, "-close-x") }, null)]));
    var Ve = createVNode("div", { class: "".concat(R, "-content") }, [Le, z, createVNode("div", v({ class: "".concat(R, "-body"), style: q }, X), [(O = a.default) === null || O === void 0 ? void 0 : O.call(a)]), ye]), Ee = Ri(S);
    return createVNode(Transition, v(v({}, Ee), {}, { onBeforeEnter: v$1, onAfterEnter: function() {
      return c(true);
    }, onAfterLeave: function() {
      return c(false);
    } }), { default: function() {
      return [te || !je ? withDirectives(createVNode("div", v(v({}, d), {}, { ref: f, key: "dialog-element", role: "document", style: [g.value, d.style], class: [R, d.class], onMousedown: me, onMouseup: ge }), [createVNode("div", { tabindex: 0, ref: y, style: Mt, "aria-hidden": "true" }, null), ne ? ne({ originVNode: Ve }) : Ve, createVNode("div", { tabindex: 0, ref: N, style: Mt, "aria-hidden": "true" }, null)]), [[vShow, te]]) : null];
    } });
  };
} }), Zn = defineComponent({ compatConfig: { MODE: 3 }, name: "Mask", props: { prefixCls: String, visible: Boolean, motionName: String, maskProps: Object }, setup: function(e, i) {
  return Bn(i), function() {
    var l = e.prefixCls, a = e.visible, d = e.maskProps, y = e.motionName, N = Ri(y);
    return createVNode(Transition, N, { default: function() {
      return [withDirectives(createVNode("div", v({ class: "".concat(l, "-mask") }, d), null), [[vShow, a]])];
    } });
  };
} }), Ft = defineComponent({ compatConfig: { MODE: 3 }, name: "Dialog", inheritAttrs: false, props: bt(v(v({}, xt()), {}, { getOpenCount: Function, scrollLocker: Object }), { mask: true, visible: false, keyboard: true, closable: true, maskClosable: true, destroyOnClose: false, prefixCls: "rc-dialog", getOpenCount: function() {
  return null;
}, focusTriggerAfterClose: true }), setup: function(e, i) {
  var l = i.attrs, a = i.slots, d = ref(), y = ref(), N = ref(), f = ref(e.visible), _ = ref("vcDialogTitle".concat(Wn())), g = function($) {
    if ($) {
      if (!re(y.value, document.activeElement)) {
        var B;
        d.value = document.activeElement, (B = N.value) === null || B === void 0 || B.focus();
      }
    } else {
      var U = f.value;
      if (f.value = false, e.mask && d.value && e.focusTriggerAfterClose) {
        try {
          d.value.focus({ preventScroll: true });
        } catch {
        }
        d.value = null;
      }
      if (U) {
        var K;
        (K = e.afterClose) === null || K === void 0 || K.call(e);
      }
    }
  }, v$1 = function($) {
    var B;
    (B = e.onClose) === null || B === void 0 || B.call(e, $);
  }, c = ref(false), p = ref(), C = function() {
    clearTimeout(p.value), c.value = true;
  }, h = function() {
    p.value = setTimeout(function() {
      c.value = false;
    });
  }, O = function($) {
    if (!e.maskClosable)
      return null;
    c.value ? c.value = false : y.value === $.target && v$1($);
  }, R = function($) {
    if (e.keyboard && $.keyCode === Dt$1.ESC) {
      $.stopPropagation(), v$1($);
      return;
    }
    e.visible && $.keyCode === Dt$1.TAB && N.value.changeActive(!$.shiftKey);
  };
  return watch(function() {
    return e.visible;
  }, function() {
    e.visible && (f.value = true);
  }, { flush: "post" }), watchEffect(function() {
    var w;
    if ((w = e.scrollLocker) === null || w === void 0 || w.unLock(), f.value) {
      var $;
      ($ = e.scrollLocker) === null || $ === void 0 || $.lock();
    }
  }), function() {
    var w = e.prefixCls, $ = e.mask, B = e.visible, U = e.maskTransitionName, K = e.maskAnimation, L = e.zIndex, Z = e.wrapClassName, G = e.rootClassName, le = e.wrapStyle, q = e.closable, X = e.maskProps, me = e.maskStyle, ge = e.transitionName, te = e.animation, re = e.wrapProps, ne = e.title, je = ne === void 0 ? a.title : ne, S = l.style, ye = l.class;
    return createVNode("div", v({ class: ["".concat(w, "-root"), G] }, m(e, { data: true })), [createVNode(Zn, { prefixCls: w, visible: $ && B, motionName: Rt(w, U, K), style: v({ zIndex: L }, me), maskProps: X }, null), createVNode("div", v({ tabIndex: -1, onKeydown: R, class: pe("".concat(w, "-wrap"), Z), ref: y, onClick: O, role: "dialog", "aria-labelledby": je ? _.value : null, style: v(v({ zIndex: L }, le), {}, { display: f.value ? null : "none" }) }, re), [createVNode(Kn, v(v({}, Ce(e, ["scrollLocker"])), {}, { style: S, class: ye, onMousedown: C, onMouseup: h, ref: N, closable: q, ariaId: _.value, prefixCls: w, visible: B, onClose: v$1, onVisibleChanged: g, motionName: Rt(w, ge, te) }), a)])]);
  };
} });
var Gn = xt(), qn = defineComponent({ compatConfig: { MODE: 3 }, name: "DialogWrap", inheritAttrs: false, props: bt(Gn, { visible: false }), setup: function(e, i) {
  var l = i.attrs, a = i.slots, d = ref(e.visible);
  return At$1({}, { inTriggerContext: false }), watch(function() {
    return e.visible;
  }, function() {
    e.visible && (d.value = true);
  }, { flush: "post" }), function() {
    var y = e.visible, N = e.getContainer, f = e.forceRender, _ = e.destroyOnClose, g = _ === void 0 ? false : _, v$1 = e.afterClose, c = v(v(v({}, e), l), {}, { ref: "_component", key: "dialog" });
    return N === false ? createVNode(Ft, v(v({}, c), {}, { getOpenCount: function() {
      return 2;
    } }), a) : !f && g && !d.value ? null : createVNode(Hn, { visible: y, forceRender: f, getContainer: N }, { default: function(C) {
      return c = v(v(v({}, c), C), {}, { afterClose: function() {
        v$1 == null || v$1(), d.value = false;
      } }), createVNode(Ft, c, a);
    } });
  };
} });
const Xn = qn;
var Yn = ["prefixCls", "visible", "wrapClassName", "centered", "getContainer", "closeIcon", "focusTriggerAfterClose"], Jn = null, Qn = function() {
  return { prefixCls: String, visible: { type: Boolean, default: void 0 }, confirmLoading: { type: Boolean, default: void 0 }, title: pt.any, closable: { type: Boolean, default: void 0 }, closeIcon: pt.any, onOk: Function, onCancel: Function, "onUpdate:visible": Function, onChange: Function, afterClose: Function, centered: { type: Boolean, default: void 0 }, width: [String, Number], footer: pt.any, okText: pt.any, okType: String, cancelText: pt.any, icon: pt.any, maskClosable: { type: Boolean, default: void 0 }, forceRender: { type: Boolean, default: void 0 }, okButtonProps: Object, cancelButtonProps: Object, destroyOnClose: { type: Boolean, default: void 0 }, wrapClassName: String, maskTransitionName: String, transitionName: String, getContainer: { type: [String, Function, Boolean, Object], default: void 0 }, zIndex: Number, bodyStyle: { type: Object, default: void 0 }, maskStyle: { type: Object, default: void 0 }, mask: { type: Boolean, default: void 0 }, keyboard: { type: Boolean, default: void 0 }, wrapProps: Object, focusTriggerAfterClose: { type: Boolean, default: void 0 }, modalRender: Function };
}, Ge = [];
const ie = defineComponent({ compatConfig: { MODE: 3 }, name: "AModal", inheritAttrs: false, props: bt(Qn(), { width: 520, transitionName: "zoom", maskTransitionName: "fade", confirmLoading: false, visible: false, okType: "primary" }), setup: function(e, i) {
  var l = i.emit, a = i.slots, d = i.attrs, y = Ti("Modal"), N = xe(y, 1), f = N[0], _ = ke("modal", e), g = _.prefixCls, v$1 = _.rootPrefixCls, c = _.direction, p = _.getPopupContainer, C = function(w) {
    l("update:visible", false), l("cancel", w), l("change", false);
  }, h = function(w) {
    l("ok", w);
  }, O = function() {
    var w, $, B = e.okText, U = B === void 0 ? (w = a.okText) === null || w === void 0 ? void 0 : w.call(a) : B, K = e.okType, L = e.cancelText, Z = L === void 0 ? ($ = a.cancelText) === null || $ === void 0 ? void 0 : $.call(a) : L, G = e.confirmLoading;
    return createVNode(Fragment, null, [createVNode(Jo, v({ onClick: C }, e.cancelButtonProps), { default: function() {
      return [Z || f.value.cancelText];
    } }), createVNode(Jo, v(v({}, Qo(K)), {}, { loading: G, onClick: h }, e.okButtonProps), { default: function() {
      return [U || f.value.okText];
    } })]);
  };
  return function() {
    var R, w;
    e.prefixCls;
    var $ = e.visible, B = e.wrapClassName, U = e.centered, K = e.getContainer, L = e.closeIcon, Z = L === void 0 ? (R = a.closeIcon) === null || R === void 0 ? void 0 : R.call(a) : L, G = e.focusTriggerAfterClose, le = G === void 0 ? true : G, q = he(e, Yn), X = pe(B, (w = {}, x(w, "".concat(g.value, "-centered"), !!U), x(w, "".concat(g.value, "-wrap-rtl"), c.value === "rtl"), w));
    return createVNode(Xn, v(v(v({}, q), d), {}, { getContainer: K || p.value, prefixCls: g.value, wrapClassName: X, visible: $, mousePosition: Jn, onClose: C, focusTriggerAfterClose: le, transitionName: Ai(v$1.value, "zoom", e.transitionName), maskTransitionName: Ai(v$1.value, "fade", e.maskTransitionName) }), v(v({}, a), {}, { footer: a.footer || O, closeIcon: function() {
      return createVNode("span", { class: "".concat(g.value, "-close-x") }, [Z || createVNode(tn, { class: "".concat(g.value, "-close-icon") }, null)]);
    } }));
  };
} });
var ea = function() {
  var e = ref(false);
  return e;
};
const ta = ea;
var na = { type: { type: String }, actionFn: Function, close: Function, autofocus: Boolean, prefixCls: String, buttonProps: Object, emitEvent: Boolean, quitOnNullishReturnValue: Boolean };
function zt(o2) {
  return !!(o2 && o2.then);
}
const Lt = defineComponent({ compatConfig: { MODE: 3 }, name: "ActionButton", props: na, setup: function(e, i) {
  var l = i.slots, a = ref(false), d = ref(), y = ref(false), N = ta(), f = function(v) {
    var c = e.close;
    zt(v) && (y.value = true, v.then(function() {
      N.value || (y.value = false), c.apply(void 0, arguments), a.value = false;
    }, function(p) {
      N.value || (y.value = false), a.value = false;
    }));
  }, _ = function(v) {
    var c = e.actionFn, p = e.close, C = p === void 0 ? function() {
    } : p;
    if (!a.value) {
      if (a.value = true, !c) {
        C();
        return;
      }
      var h;
      if (e.emitEvent) {
        if (h = c(v), e.quitOnNullishReturnValue && !zt(h)) {
          a.value = false, C(v);
          return;
        }
      } else if (c.length)
        h = c(C), a.value = false;
      else if (h = c(), !h) {
        C();
        return;
      }
      f(h);
    }
  };
  return function() {
    var g = e.type, v$1 = e.prefixCls, c = e.buttonProps;
    return createVNode(Jo, v(v(v({}, Qo(g)), {}, { onClick: _, loading: y.value, prefixCls: v$1 }, c), {}, { ref: d }), l);
  };
} });
function Je(o2) {
  return typeof o2 == "function" ? o2() : o2;
}
const aa = defineComponent({ name: "ConfirmDialog", inheritAttrs: false, props: ["icon", "onCancel", "onOk", "close", "closable", "zIndex", "afterClose", "visible", "keyboard", "centered", "getContainer", "maskStyle", "okButtonProps", "cancelButtonProps", "okType", "prefixCls", "okCancel", "width", "mask", "maskClosable", "okText", "cancelText", "autoFocusButton", "transitionName", "maskTransitionName", "type", "title", "content", "direction", "rootPrefixCls", "bodyStyle", "closeIcon", "modalRender", "focusTriggerAfterClose", "wrapClassName"], setup: function(e, i) {
  var l = i.attrs, a = Ti("Modal"), d = xe(a, 1), y = d[0];
  return function() {
    var N = e.icon, f = e.onCancel, _ = e.onOk, g = e.close, v = e.closable, c = v === void 0 ? false : v, p = e.zIndex, C = e.afterClose, h = e.visible, O = e.keyboard, R = e.centered, w = e.getContainer, $ = e.maskStyle, B = e.okButtonProps, U = e.cancelButtonProps, K = e.okCancel, L = K === void 0 ? true : K, Z = e.width, G = Z === void 0 ? 416 : Z, le = e.mask, q = le === void 0 ? true : le, X = e.maskClosable, me = X === void 0 ? false : X, ge = e.type, te = e.title, re = e.content, ne = e.direction, je = e.closeIcon, S = e.modalRender, ye = e.focusTriggerAfterClose, z = e.rootPrefixCls, Le = e.bodyStyle, Ve = e.wrapClassName, Ee = e.okType || "primary", de = e.prefixCls || "ant-modal", se = "".concat(de, "-confirm"), ft = l.style || {}, nt = Je(e.okText) || (L ? y.value.okText : y.value.justOkText), qe = Je(e.cancelText) || y.value.cancelText, m = e.autoFocusButton === null ? false : e.autoFocusButton || "ok", A = pe(se, "".concat(se, "-").concat(ge), "".concat(de, "-").concat(ge), x({}, "".concat(se, "-rtl"), ne === "rtl"), l.class), Y = L && createVNode(Lt, { actionFn: f, close: g, autofocus: m === "cancel", buttonProps: U, prefixCls: "".concat(z, "-btn") }, { default: function() {
      return [qe];
    } });
    return createVNode(ie, { prefixCls: de, class: A, wrapClassName: pe(x({}, "".concat(se, "-centered"), !!R), Ve), onCancel: function(T) {
      return g({ triggerCancel: true }, T);
    }, visible: h, title: "", footer: "", transitionName: Ai(z, "zoom", e.transitionName), maskTransitionName: Ai(z, "fade", e.maskTransitionName), mask: q, maskClosable: me, maskStyle: $, style: ft, bodyStyle: Le, width: G, zIndex: p, afterClose: C, keyboard: O, centered: R, getContainer: w, closable: c, closeIcon: je, modalRender: S, focusTriggerAfterClose: ye }, { default: function() {
      return [createVNode("div", { class: "".concat(se, "-body-wrapper") }, [createVNode("div", { class: "".concat(se, "-body") }, [Je(N), te === void 0 ? null : createVNode("span", { class: "".concat(se, "-title") }, [Je(te)]), createVNode("div", { class: "".concat(se, "-content") }, [Je(re)])]), createVNode("div", { class: "".concat(se, "-btns") }, [Y, createVNode(Lt, { type: Ee, actionFn: _, close: g, autofocus: m === "ok", buttonProps: B, prefixCls: "".concat(z, "-btn") }, { default: function() {
        return [nt];
      } })])])];
    } });
  };
} });
var la = function(e) {
  var i = document.createDocumentFragment(), l = v(v({}, Ce(e, ["parentContext", "appContext"])), {}, { close: y, visible: true }), a = null;
  function d() {
    a && (render(null, i), a.component.update(), a = null);
    for (var g = arguments.length, v = new Array(g), c = 0; c < g; c++)
      v[c] = arguments[c];
    var p = v.some(function(O) {
      return O && O.triggerCancel;
    });
    e.onCancel && p && e.onCancel.apply(e, v);
    for (var C = 0; C < Ge.length; C++) {
      var h = Ge[C];
      if (h === y) {
        Ge.splice(C, 1);
        break;
      }
    }
  }
  function y() {
    for (var g = this, v$1 = arguments.length, c = new Array(v$1), p = 0; p < v$1; p++)
      c[p] = arguments[p];
    l = v(v({}, l), {}, { visible: false, afterClose: function() {
      typeof e.afterClose == "function" && e.afterClose(), d.apply(g, c);
    } }), N$1(l);
  }
  function N$1(g) {
    typeof g == "function" ? l = g(l) : l = v(v({}, l), g), a && (ce(a.component.props, l), a.component.update());
  }
  var f = function(v$1) {
    var c = N, p = c.prefixCls, C = v$1.prefixCls || "".concat(p, "-modal");
    return createVNode(se, v(v({}, c), {}, { notUpdateGlobalConfig: true, prefixCls: p }), { default: function() {
      return [createVNode(aa, v(v({}, v$1), {}, { rootPrefixCls: p, prefixCls: C }), null)];
    } });
  };
  function _(g) {
    var v$1 = createVNode(f, v({}, g));
    return v$1.appContext = e.parentContext || e.appContext || v$1.appContext, render(v$1, i), v$1;
  }
  return a = _(l), Ge.push(y), { destroy: y, update: N$1 };
};
const tt = la;
function oa(o2) {
  return v(v({ icon: function() {
    return createVNode(Yt, null, null);
  }, okCancel: false }, o2), {}, { type: "warning" });
}
function ia(o2) {
  return v(v({ icon: function() {
    return createVNode(An, null, null);
  }, okCancel: false }, o2), {}, { type: "info" });
}
function ra(o2) {
  return v(v({ icon: function() {
    return createVNode(Dn, null, null);
  }, okCancel: false }, o2), {}, { type: "success" });
}
function sa(o2) {
  return v(v({ icon: function() {
    return createVNode(Mn, null, null);
  }, okCancel: false }, o2), {}, { type: "error" });
}
function ca(o2) {
  return v(v({ icon: function() {
    return createVNode(Yt, null, null);
  }, okCancel: true }, o2), {}, { type: "confirm" });
}
function en(o2) {
  return tt(oa(o2));
}
ie.info = function(e) {
  return tt(ia(e));
};
ie.success = function(e) {
  return tt(ra(e));
};
ie.error = function(e) {
  return tt(sa(e));
};
ie.warning = en;
ie.warn = en;
ie.confirm = function(e) {
  return tt(ca(e));
};
ie.destroyAll = function() {
  for (; Ge.length; ) {
    var e = Ge.pop();
    e && e();
  }
};
ie.install = function(o2) {
  return o2.component(ie.name, ie), o2;
};
const ua = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, da = createElementVNode("path", { fill: "currentColor", d: "M878.08 448H241.92l-96 384h636.16l96-384zM832 384v-64H485.76L357.504 192H128v448l57.92-231.744A32 32 0 0 1 216.96 384H832zm-24.96 512H96a32 32 0 0 1-32-32V160a32 32 0 0 1 32-32h287.872l128.384 128H864a32 32 0 0 1 32 32v96h23.04a32 32 0 0 1 31.04 39.744l-112 448A32 32 0 0 1 807.04 896z" }, null, -1), fa = [da];
function va(o2, e) {
  return openBlock(), createElementBlock("svg", ua, fa);
}
const ma = { name: "ep-folder-opened", render: va }, ga = { viewBox: "0 0 24 24", width: "1.2em", height: "1.2em" }, ya = createElementVNode("path", { fill: "currentColor", d: "m21 12l-7-7v4C7 10 4 15 3 20c2.5-3.5 6-5.1 11-5.1V19l7-7Z" }, null, -1), Ca = [ya];
function pa(o2, e) {
  return openBlock(), createElementBlock("svg", ga, Ca);
}
const ka = { name: "mdi-share", render: pa }, _a = { viewBox: "0 0 256 256", width: "1.2em", height: "1.2em" }, ha = createElementVNode("path", { fill: "currentColor", d: "m213.66 82.34l-56-56A8 8 0 0 0 152 24H56a16 16 0 0 0-16 16v176a16 16 0 0 0 16 16h144a16 16 0 0 0 16-16V88a8 8 0 0 0-2.34-5.66ZM160 176H96a8 8 0 0 1 0-16h64a8 8 0 0 1 0 16Zm0-32H96a8 8 0 0 1 0-16h64a8 8 0 0 1 0 16Zm-8-56V44l44 44Z" }, null, -1), ba = [ha];
function xa(o2, e) {
  return openBlock(), createElementBlock("svg", _a, ba);
}
const wa = { name: "ph-file-text-fill", render: xa }, Na = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, $a = createElementVNode("path", { fill: "currentColor", d: "M512 64a448 448 0 1 1 0 896a448 448 0 0 1 0-896zm-38.4 409.6H326.4a38.4 38.4 0 1 0 0 76.8h147.2v147.2a38.4 38.4 0 0 0 76.8 0V550.4h147.2a38.4 38.4 0 0 0 0-76.8H550.4V326.4a38.4 38.4 0 1 0-76.8 0v147.2z" }, null, -1), Ta = [$a];
function Pa(o2, e) {
  return openBlock(), createElementBlock("svg", Na, Ta);
}
const Sa = { name: "ep-circle-plus-filled", render: Pa }, Oa = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, Ba = createElementVNode("path", { fill: "currentColor", d: "M160 256H96a32 32 0 0 1 0-64h256V95.936a32 32 0 0 1 32-32h256a32 32 0 0 1 32 32V192h256a32 32 0 1 1 0 64h-64v672a32 32 0 0 1-32 32H192a32 32 0 0 1-32-32V256zm448-64v-64H416v64h192zM224 896h576V256H224v640zm192-128a32 32 0 0 1-32-32V416a32 32 0 0 1 64 0v320a32 32 0 0 1-32 32zm192 0a32 32 0 0 1-32-32V416a32 32 0 0 1 64 0v320a32 32 0 0 1-32 32z" }, null, -1), ja = [Ba];
function Ea(o2, e) {
  return openBlock(), createElementBlock("svg", Oa, ja);
}
const Ra = { name: "ep-delete", render: Ea }, Aa = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, Da = createElementVNode("path", { fill: "currentColor", d: "M832 512a32 32 0 1 1 64 0v352a32 32 0 0 1-32 32H160a32 32 0 0 1-32-32V160a32 32 0 0 1 32-32h352a32 32 0 0 1 0 64H192v640h640V512z" }, null, -1), Ma = createElementVNode("path", { fill: "currentColor", d: "m469.952 554.24l52.8-7.552L847.104 222.4a32 32 0 1 0-45.248-45.248L477.44 501.44l-7.552 52.8zm422.4-422.4a96 96 0 0 1 0 135.808l-331.84 331.84a32 32 0 0 1-18.112 9.088L436.8 623.68a32 32 0 0 1-36.224-36.224l15.104-105.6a32 32 0 0 1 9.024-18.112l331.904-331.84a96 96 0 0 1 135.744 0z" }, null, -1), Fa = [Da, Ma];
function za(o2, e) {
  return openBlock(), createElementBlock("svg", Aa, Fa);
}
const La = { name: "ep-edit", render: za }, Va = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, Ua = createElementVNode("path", { fill: "currentColor", d: "M512.5 390.6c-29.9 0-57.9 11.6-79.1 32.8c-21.1 21.2-32.8 49.2-32.8 79.1c0 29.9 11.7 57.9 32.8 79.1c21.2 21.1 49.2 32.8 79.1 32.8c29.9 0 57.9-11.7 79.1-32.8c21.1-21.2 32.8-49.2 32.8-79.1c0-29.9-11.7-57.9-32.8-79.1a110.96 110.96 0 0 0-79.1-32.8zm412.3 235.5l-65.4-55.9c3.1-19 4.7-38.4 4.7-57.7s-1.6-38.8-4.7-57.7l65.4-55.9a32.03 32.03 0 0 0 9.3-35.2l-.9-2.6a442.5 442.5 0 0 0-79.6-137.7l-1.8-2.1a32.12 32.12 0 0 0-35.1-9.5l-81.2 28.9c-30-24.6-63.4-44-99.6-57.5l-15.7-84.9a32.05 32.05 0 0 0-25.8-25.7l-2.7-.5c-52-9.4-106.8-9.4-158.8 0l-2.7.5a32.05 32.05 0 0 0-25.8 25.7l-15.8 85.3a353.44 353.44 0 0 0-98.9 57.3l-81.8-29.1a32 32 0 0 0-35.1 9.5l-1.8 2.1a445.93 445.93 0 0 0-79.6 137.7l-.9 2.6c-4.5 12.5-.8 26.5 9.3 35.2l66.2 56.5c-3.1 18.8-4.6 38-4.6 57c0 19.2 1.5 38.4 4.6 57l-66 56.5a32.03 32.03 0 0 0-9.3 35.2l.9 2.6c18.1 50.3 44.8 96.8 79.6 137.7l1.8 2.1a32.12 32.12 0 0 0 35.1 9.5l81.8-29.1c29.8 24.5 63 43.9 98.9 57.3l15.8 85.3a32.05 32.05 0 0 0 25.8 25.7l2.7.5a448.27 448.27 0 0 0 158.8 0l2.7-.5a32.05 32.05 0 0 0 25.8-25.7l15.7-84.9c36.2-13.6 69.6-32.9 99.6-57.5l81.2 28.9a32 32 0 0 0 35.1-9.5l1.8-2.1c34.8-41.1 61.5-87.4 79.6-137.7l.9-2.6c4.3-12.4.6-26.3-9.5-35zm-412.3 52.2c-97.1 0-175.8-78.7-175.8-175.8s78.7-175.8 175.8-175.8s175.8 78.7 175.8 175.8s-78.7 175.8-175.8 175.8z" }, null, -1), Ha = [Ua];
function Wa(o2, e) {
  return openBlock(), createElementBlock("svg", Va, Ha);
}
const Ia = { name: "ant-design-setting-filled", render: Wa }, Ka = { viewBox: "0 0 24 24", width: "1.2em", height: "1.2em" }, Za = createElementVNode("path", { fill: "currentColor", d: "M20 14h-6v6h-4v-6H4v-4h6V4h4v6h6v4Z" }, null, -1), Ga = [Za];
function qa(o2, e) {
  return openBlock(), createElementBlock("svg", Ka, Ga);
}
const Xa = { name: "mdi-plus-thick", render: qa }, Ya = () => v4();
const wt = { __name: "writer", __ssrInlineRender: true, async setup(o2) {
  let e, i;
  const l = ref([St()]), { $message: a } = $(), d = ref(null), y = () => {
    Br("/");
  }, N = () => {
    let m = "";
    switch (S.value.state) {
      case 1:
        m = "\u7ACB\u5373\u53D1\u5E03";
        break;
      case 2:
        m = "\u5DF2\u53D1\u5E03";
        break;
      case 3:
        m = "\u53D1\u5E03\u66F4\u65B0";
        break;
    }
    l.value = [St(), { actions: [{ title: m, icon: m, position: "right", handler: { type: "action", click(A) {
      S.value.state = 2, z();
    } } }] }];
  }, f = ref([]), _ = async (m, A) => {
    const { data: Y } = await li({ method: "GET", server: m, key: "notesFetch", params: { notebookId: A } });
    if (Y.value.code === 1)
      throw Wr({ statusCode: 500, statusMessage: "\u670D\u52A1\u5668\u62A5\u9519\uFF01" });
    f.value = Y.value.data.list, m && (X.value = true, f.value.length && ye(true, f.value[0].id));
  }, g = ref(0), v = ref(0), { data: c, refresh: p } = ([e, i] = withAsyncContext(() => ri({ method: "GET", server: true, key: "notebookFetch" })), e = await e, i(), e);
  if (c.value.code === 1)
    throw Wr({ statusCode: 500, statusMessage: "\u670D\u52A1\u5668\u62A5\u9519\uFF01" });
  if (c.value.data && c.value.data.list.length > 0) {
    const m = c.value.data.list[0];
    v.value = m.id, _(true, m.id);
  }
  const C = (m, A) => {
    g.value = A, v.value = m.id, f.value = [], S.value = {}, S.value.content_md = "", q.value = 0, _(true, m.id);
  }, h = ref(""), O = ref(false), R = () => {
    ri({ method: "POST", body: { name: h.value }, server: false }).then(({ data: m }) => {
      if (m.value.code === 1) {
        a.error(m.value.msg);
        return;
      }
      p(), f.value = [], S.value = {}, O.value = false;
    });
  }, w = () => {
    O.value = !O.value;
  }, $$1 = ref(false), B = ref({}), U = (m) => {
    B.value = m, $$1.value = true;
  }, K = (m) => {
    ri({ method: "PUT", body: { id: B.value.id, name: B.value.name }, server: false, key: "editNotebook" }).then(({ data: A }) => {
      if (A.value.code === 1) {
        a.error(A.value.msg);
        return;
      }
      p(), B.value = {}, $$1.value = false;
    });
  }, L = ref(false), Z = ref({}), G = (m) => {
    Z.value = m, L.value = true;
  }, le = () => {
    ri({ method: "DELETE", body: { id: Z.value.id }, server: false, key: "deleteNotebook" }).then(({ data: m }) => {
      if (m.value.code === 1) {
        a.error(m.value.msg);
        return;
      }
      p(), L.value = false;
    });
  }, q = ref(0), X = ref(false), me = (m, A) => {
    q.value = A, X.value = true, ye(false, m.id);
  }, ge = () => {
    si({ method: "POST", body: { notebookId: v.value }, server: false, key: "createNote" }).then(({ data: m }) => {
      if (m.value.code === 1) {
        a.error(m.value.msg);
        return;
      }
      _(false, v.value);
    });
  }, te = ref(false), re = ref({}), ne = (m) => {
    re.value = m, te.value = true;
  }, je = () => {
    si({ method: "DELETE", body: { noteId: re.value.id }, server: false, key: "deleteNote" }).then(({ data: m }) => {
      if (m.value.code === 1) {
        a.error(m.value.msg);
        return;
      }
      a.info("\u5220\u9664\u6210\u529F\uFF01"), te.value = false, _(false, v.value);
    });
  }, S = ref({}), ye = async (m, A) => {
    const { data: Y } = await si({ method: "GET", params: { noteId: A }, server: m, key: "getNote" });
    if (Y.value.code === 1)
      throw Wr({ statusCode: 500, statusMessage: "\u670D\u52A1\u5668\u62A5\u9519\uFF01" });
    S.value = Y.value.data.list, N();
  }, z = () => {
    si({ method: "PUT", body: { noteId: S.value.id, title: S.value.title, content_md: S.value.content_md, state: S.value.state }, server: false, key: "notePush" }).then(({ data: m }) => {
      if (m.value.code === 1) {
        a.error(m.value.msg);
        return;
      }
      S.value.state === 2 && a.info("\u53D1\u5E03\u6210\u529F\uFF01"), _(false, v.value), N();
    });
  }, Le$1 = () => {
    if (X.value) {
      X.value = false;
      return;
    }
    S.value.state = S.value.state === 2 ? 3 : 1, z();
  }, Ve = debounce((m) => {
    if (X.value) {
      X.value = false;
      return;
    }
    S.value.content_md = m, S.value.state = S.value.state === 2 ? 3 : 1, z();
  }, 1e3), Ee = debounce(Le$1, 1e3), de = (m) => {
    Ve(m);
  };
  let se = null, ft = lr().value.id;
  const nt = Be(), qe = async (m) => Promise.all(m.map(async (A) => {
    const Y = A.name.slice(A.name.lastIndexOf(".") + 1);
    let Xe = "uploads/" + ft + "/note/" + Ya() + "." + Y;
    return { url: "//" + (await se.putObject({ Bucket: nt.public.BUCKET, Region: nt.public.REGION, Key: Xe, Body: A, onProgress: function(Re) {
    } })).Location };
  }));
  return (m, A, Y, Xe) => {
    const T = ei, Re = ti, Ce = Jo, vt = Xa, Ne = oi, Ue = Le, $e = Ia, Te = _e, E = nn, Ae = La, J = Ra, mt = Sa, gt = wa, De = ka, Me = ma, yt = ie;
    A("<!--[-->"), A(ssrRenderComponent(T, { style: { height: "100vh" } }, { default: withCtx((pe, ae, Fe, ce) => {
      if (ae)
        ae(ssrRenderComponent(Re, { span: 4 }, { default: withCtx((D, u, H, j) => {
          if (u)
            u(`<div class="notebook" data-v-7adcdb19${j}><div class="notebook-top" data-v-7adcdb19${j}>`), u(ssrRenderComponent(Ce, { onClick: y, class: "go-btn", type: "primary", ghost: "", shape: "round" }, { default: withCtx((b, M, ue, W) => {
              if (M)
                M("\u56DE\u9996\u9875");
              else
                return [createTextVNode("\u56DE\u9996\u9875")];
            }), _: 1 }, H, j)), u(`<div class="add-notebook" data-v-7adcdb19${j}>`), u(ssrRenderComponent(vt, null, null, H, j)), u("\u65B0\u5EFA\u6587\u96C6</div>"), unref(O) ? (u(`<div class="create-notebook" data-v-7adcdb19${j}>`), u(ssrRenderComponent(Ne, { value: unref(h), "onUpdate:value": (b) => isRef(h) ? h.value = b : null, class: "notebook-input", placeholder: "\u8BF7\u8F93\u5165\u6587\u96C6\u540D\u79F0..." }, null, H, j)), u(`<div class="action-box" data-v-7adcdb19${j}>`), u(ssrRenderComponent(Ce, { onClick: R, size: "small", shape: "round", ghost: "" }, { default: withCtx((b, M, ue, W) => {
              if (M)
                M("\u63D0\u4EA4");
              else
                return [createTextVNode("\u63D0\u4EA4")];
            }), _: 1 }, H, j)), u(ssrRenderComponent(Ce, { onClick: (b) => O.value = false, style: { color: "#9a9a9a" }, type: "text" }, { default: withCtx((b, M, ue, W) => {
              if (M)
                M("\u53D6\u6D88");
              else
                return [createTextVNode("\u53D6\u6D88")];
            }), _: 1 }, H, j)), u("</div></div>")) : u("<!---->"), u(`</div><div class="notebook-center" data-v-7adcdb19${j}>`), unref(c).data ? (u("<!--[-->"), ssrRenderList(unref(c).data.list, (b, M) => {
              u(`<div class="${ssrRenderClass([unref(g) === M ? "active" : "", "notebook-c-item"])}" data-v-7adcdb19${j}><span data-v-7adcdb19${j}>${ssrInterpolate(b.name)}</span>`), unref(g) === M ? u(ssrRenderComponent(Ue, { trigger: ["click"], overlayClassName: "overlayClassName" }, { overlay: withCtx((ue, W, ze, ke) => {
                if (W)
                  W(ssrRenderComponent(Te, null, { default: withCtx((at, Pe, He, We) => {
                    if (Pe)
                      Pe(ssrRenderComponent(E, { onClick: (fe) => U(b) }, { default: withCtx((fe, Q, _e, he) => {
                        if (Q)
                          Q(ssrRenderComponent(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx((lt, V, be, xe) => {
                            if (V)
                              V(ssrRenderComponent(Ae, { style: { "margin-right": "5px" } }, null, be, xe)), V(" \u4FEE\u6539\u6587\u96C6 ");
                            else
                              return [createVNode(Ae, { style: { "margin-right": "5px" } }), createTextVNode(" \u4FEE\u6539\u6587\u96C6 ")];
                          }), _: 2 }, _e, he));
                        else
                          return [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(Ae, { style: { "margin-right": "5px" } }), createTextVNode(" \u4FEE\u6539\u6587\u96C6 ")]), _: 1 })];
                      }), _: 2 }, He, We)), Pe(ssrRenderComponent(E, { onClick: (fe) => G(b) }, { default: withCtx((fe, Q, _e, he) => {
                        if (Q)
                          Q(ssrRenderComponent(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx((lt, V, be, xe) => {
                            if (V)
                              V(ssrRenderComponent(J, { style: { "margin-right": "5px" } }, null, be, xe)), V(" \u5220\u9664\u6587\u96C6 ");
                            else
                              return [createVNode(J, { style: { "margin-right": "5px" } }), createTextVNode(" \u5220\u9664\u6587\u96C6 ")];
                          }), _: 2 }, _e, he));
                        else
                          return [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(J, { style: { "margin-right": "5px" } }), createTextVNode(" \u5220\u9664\u6587\u96C6 ")]), _: 1 })];
                      }), _: 2 }, He, We));
                    else
                      return [createVNode(E, { onClick: (fe) => U(b) }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(Ae, { style: { "margin-right": "5px" } }), createTextVNode(" \u4FEE\u6539\u6587\u96C6 ")]), _: 1 })]), _: 2 }, 1032, ["onClick"]), createVNode(E, { onClick: (fe) => G(b) }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(J, { style: { "margin-right": "5px" } }), createTextVNode(" \u5220\u9664\u6587\u96C6 ")]), _: 1 })]), _: 2 }, 1032, ["onClick"])];
                  }), _: 2 }, ze, ke));
                else
                  return [createVNode(Te, null, { default: withCtx(() => [createVNode(E, { onClick: (at) => U(b) }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(Ae, { style: { "margin-right": "5px" } }), createTextVNode(" \u4FEE\u6539\u6587\u96C6 ")]), _: 1 })]), _: 2 }, 1032, ["onClick"]), createVNode(E, { onClick: (at) => G(b) }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(J, { style: { "margin-right": "5px" } }), createTextVNode(" \u5220\u9664\u6587\u96C6 ")]), _: 1 })]), _: 2 }, 1032, ["onClick"])]), _: 2 }, 1024)];
              }), default: withCtx((ue, W, ze, ke) => {
                if (W)
                  W(`<a style="${ssrRenderStyle({ color: "#ffffff" })}" data-v-7adcdb19${ke}>`), W(ssrRenderComponent($e, null, null, ze, ke)), W("</a>");
                else
                  return [createVNode("a", { style: { color: "#ffffff" }, onClick: withModifiers(() => {
                  }, ["prevent"]) }, [createVNode($e)], 8, ["onClick"])];
              }), _: 2 }, H, j)) : u("<!---->"), u("</div>");
            }), u("<!--]-->")) : u("<!---->"), u("</div></div>");
          else
            return [createVNode("div", { class: "notebook" }, [createVNode("div", { class: "notebook-top" }, [createVNode(Ce, { onClick: y, class: "go-btn", type: "primary", ghost: "", shape: "round" }, { default: withCtx(() => [createTextVNode("\u56DE\u9996\u9875")]), _: 1 }), createVNode("div", { onClick: w, class: "add-notebook" }, [createVNode(vt), createTextVNode("\u65B0\u5EFA\u6587\u96C6")]), unref(O) ? (openBlock(), createBlock("div", { key: 0, class: "create-notebook" }, [createVNode(Ne, { value: unref(h), "onUpdate:value": (b) => isRef(h) ? h.value = b : null, class: "notebook-input", placeholder: "\u8BF7\u8F93\u5165\u6587\u96C6\u540D\u79F0..." }, null, 8, ["value", "onUpdate:value"]), createVNode("div", { class: "action-box" }, [createVNode(Ce, { onClick: R, size: "small", shape: "round", ghost: "" }, { default: withCtx(() => [createTextVNode("\u63D0\u4EA4")]), _: 1 }), createVNode(Ce, { onClick: (b) => O.value = false, style: { color: "#9a9a9a" }, type: "text" }, { default: withCtx(() => [createTextVNode("\u53D6\u6D88")]), _: 1 }, 8, ["onClick"])])])) : createCommentVNode("", true)]), createVNode("div", { class: "notebook-center" }, [unref(c).data ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(c).data.list, (b, M) => (openBlock(), createBlock("div", { key: b.id, class: ["notebook-c-item", unref(g) === M ? "active" : ""], onClick: (ue) => C(b, M) }, [createVNode("span", null, toDisplayString(b.name), 1), unref(g) === M ? (openBlock(), createBlock(Ue, { key: 0, trigger: ["click"], overlayClassName: "overlayClassName" }, { overlay: withCtx(() => [createVNode(Te, null, { default: withCtx(() => [createVNode(E, { onClick: (ue) => U(b) }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(Ae, { style: { "margin-right": "5px" } }), createTextVNode(" \u4FEE\u6539\u6587\u96C6 ")]), _: 1 })]), _: 2 }, 1032, ["onClick"]), createVNode(E, { onClick: (ue) => G(b) }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(J, { style: { "margin-right": "5px" } }), createTextVNode(" \u5220\u9664\u6587\u96C6 ")]), _: 1 })]), _: 2 }, 1032, ["onClick"])]), _: 2 }, 1024)]), default: withCtx(() => [createVNode("a", { style: { color: "#ffffff" }, onClick: withModifiers(() => {
            }, ["prevent"]) }, [createVNode($e)], 8, ["onClick"])]), _: 2 }, 1024)) : createCommentVNode("", true)], 10, ["onClick"]))), 128)) : createCommentVNode("", true)])])];
        }), _: 1 }, Fe, ce)), ae(ssrRenderComponent(Re, { span: 5, class: "note-writer-list" }, { default: withCtx((D, u, H, j) => {
          if (u)
            u(`<div class="create" data-v-7adcdb19${j}>`), u(ssrRenderComponent(mt, null, null, H, j)), u(` \u65B0\u5EFA\u6587\u7AE0 </div><div class="note-create" data-v-7adcdb19${j}>`), unref(f) ? (u("<!--[-->"), ssrRenderList(unref(f), (b, M) => {
              u(`<div class="${ssrRenderClass([unref(q) === M ? "active" : "", "note-create-item"])}" data-v-7adcdb19${j}>`), u(ssrRenderComponent(gt, { class: "text-icon" }, null, H, j)), u(`<span data-v-7adcdb19${j}>${ssrInterpolate(b.title)}</span>`), unref(q) === M ? u(ssrRenderComponent(Ue, { trigger: ["click"], overlayClassName: "overlayClassName" }, { overlay: withCtx((ue, W, ze, ke) => {
                if (W)
                  W(ssrRenderComponent(Te, null, { default: withCtx((at, Pe, He, We) => {
                    if (Pe)
                      Pe(ssrRenderComponent(E, { onClick: z }, { default: withCtx((fe, Q, _e, he) => {
                        if (Q)
                          Q(ssrRenderComponent(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx((lt, V, be, xe) => {
                            if (V)
                              V(ssrRenderComponent(De, { style: { "margin-right": "5px" } }, null, be, xe)), V(" \u76F4\u63A5\u53D1\u5E03 ");
                            else
                              return [createVNode(De, { style: { "margin-right": "5px" } }), createTextVNode(" \u76F4\u63A5\u53D1\u5E03 ")];
                          }), _: 2 }, _e, he));
                        else
                          return [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(De, { style: { "margin-right": "5px" } }), createTextVNode(" \u76F4\u63A5\u53D1\u5E03 ")]), _: 1 })];
                      }), _: 2 }, He, We)), Pe(ssrRenderComponent(E, { onClick: z }, { default: withCtx((fe, Q, _e, he) => {
                        if (Q)
                          Q(ssrRenderComponent(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx((lt, V, be, xe) => {
                            if (V)
                              V(ssrRenderComponent(Me, { style: { "margin-right": "5px" } }, null, be, xe)), V(" \u79FB\u52A8\u6587\u7AE0 ");
                            else
                              return [createVNode(Me, { style: { "margin-right": "5px" } }), createTextVNode(" \u79FB\u52A8\u6587\u7AE0 ")];
                          }), _: 2 }, _e, he));
                        else
                          return [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(Me, { style: { "margin-right": "5px" } }), createTextVNode(" \u79FB\u52A8\u6587\u7AE0 ")]), _: 1 })];
                      }), _: 2 }, He, We)), Pe(ssrRenderComponent(E, { onClick: (fe) => ne(b) }, { default: withCtx((fe, Q, _e, he) => {
                        if (Q)
                          Q(ssrRenderComponent(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx((lt, V, be, xe) => {
                            if (V)
                              V(ssrRenderComponent(J, { style: { "margin-right": "5px" } }, null, be, xe)), V(" \u5220\u9664\u6587\u7AE0 ");
                            else
                              return [createVNode(J, { style: { "margin-right": "5px" } }), createTextVNode(" \u5220\u9664\u6587\u7AE0 ")];
                          }), _: 2 }, _e, he));
                        else
                          return [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(J, { style: { "margin-right": "5px" } }), createTextVNode(" \u5220\u9664\u6587\u7AE0 ")]), _: 1 })];
                      }), _: 2 }, He, We));
                    else
                      return [createVNode(E, { onClick: z }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(De, { style: { "margin-right": "5px" } }), createTextVNode(" \u76F4\u63A5\u53D1\u5E03 ")]), _: 1 })]), _: 1 }), createVNode(E, { onClick: z }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(Me, { style: { "margin-right": "5px" } }), createTextVNode(" \u79FB\u52A8\u6587\u7AE0 ")]), _: 1 })]), _: 1 }), createVNode(E, { onClick: (fe) => ne(b) }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(J, { style: { "margin-right": "5px" } }), createTextVNode(" \u5220\u9664\u6587\u7AE0 ")]), _: 1 })]), _: 2 }, 1032, ["onClick"])];
                  }), _: 2 }, ze, ke));
                else
                  return [createVNode(Te, null, { default: withCtx(() => [createVNode(E, { onClick: z }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(De, { style: { "margin-right": "5px" } }), createTextVNode(" \u76F4\u63A5\u53D1\u5E03 ")]), _: 1 })]), _: 1 }), createVNode(E, { onClick: z }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(Me, { style: { "margin-right": "5px" } }), createTextVNode(" \u79FB\u52A8\u6587\u7AE0 ")]), _: 1 })]), _: 1 }), createVNode(E, { onClick: (at) => ne(b) }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(J, { style: { "margin-right": "5px" } }), createTextVNode(" \u5220\u9664\u6587\u7AE0 ")]), _: 1 })]), _: 2 }, 1032, ["onClick"])]), _: 2 }, 1024)];
              }), default: withCtx((ue, W, ze, ke) => {
                if (W)
                  W(`<a style="${ssrRenderStyle({ color: "#595959" })}" data-v-7adcdb19${ke}>`), W(ssrRenderComponent($e, null, null, ze, ke)), W("</a>");
                else
                  return [createVNode("a", { style: { color: "#595959" }, onClick: withModifiers(() => {
                  }, ["prevent"]) }, [createVNode($e)], 8, ["onClick"])];
              }), _: 2 }, H, j)) : u("<!---->"), u("</div>");
            }), u("<!--]-->")) : u("<!---->"), u("</div>");
          else
            return [createVNode("div", { class: "create", onClick: ge }, [createVNode(mt), createTextVNode(" \u65B0\u5EFA\u6587\u7AE0 ")]), createVNode("div", { class: "note-create" }, [unref(f) ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(f), (b, M) => (openBlock(), createBlock("div", { key: b.id, class: ["note-create-item", unref(q) === M ? "active" : ""], onClick: (ue) => me(b, M) }, [createVNode(gt, { class: "text-icon" }), createVNode("span", null, toDisplayString(b.title), 1), unref(q) === M ? (openBlock(), createBlock(Ue, { key: 0, trigger: ["click"], overlayClassName: "overlayClassName" }, { overlay: withCtx(() => [createVNode(Te, null, { default: withCtx(() => [createVNode(E, { onClick: z }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(De, { style: { "margin-right": "5px" } }), createTextVNode(" \u76F4\u63A5\u53D1\u5E03 ")]), _: 1 })]), _: 1 }), createVNode(E, { onClick: z }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(Me, { style: { "margin-right": "5px" } }), createTextVNode(" \u79FB\u52A8\u6587\u7AE0 ")]), _: 1 })]), _: 1 }), createVNode(E, { onClick: (ue) => ne(b) }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(J, { style: { "margin-right": "5px" } }), createTextVNode(" \u5220\u9664\u6587\u7AE0 ")]), _: 1 })]), _: 2 }, 1032, ["onClick"])]), _: 2 }, 1024)]), default: withCtx(() => [createVNode("a", { style: { color: "#595959" }, onClick: withModifiers(() => {
            }, ["prevent"]) }, [createVNode($e)], 8, ["onClick"])]), _: 2 }, 1024)) : createCommentVNode("", true)], 10, ["onClick"]))), 128)) : createCommentVNode("", true)])];
        }), _: 1 }, Fe, ce)), ae(ssrRenderComponent(Re, { span: 15 }, { default: withCtx((D, u, H, j) => {
          if (u)
            u(`<div class="edit-note" data-v-7adcdb19${j}><div style="${ssrRenderStyle({ height: "80px", "line-height": "80px" })}" data-v-7adcdb19${j}>`), u(ssrRenderComponent(Ne, { onInput: unref(Ee), style: { "font-size": "30px" }, bordered: false, value: unref(S).title, "onUpdate:value": (b) => unref(S).title = b }, null, H, j)), u("</div>"), u(ssrRenderComponent(unref(Editor), { ref_key: "editor", ref: d, value: unref(S).content_md, "onUpdate:value": (b) => unref(S).content_md = b, plugins: unref(l), onChange: de, uploadImages: qe }, null, H, j)), u("</div>");
          else
            return [createVNode("div", { class: "edit-note" }, [createVNode("div", { style: { height: "80px", "line-height": "80px" } }, [createVNode(Ne, { onInput: unref(Ee), style: { "font-size": "30px" }, bordered: false, value: unref(S).title, "onUpdate:value": (b) => unref(S).title = b }, null, 8, ["onInput", "value", "onUpdate:value"])]), createVNode(unref(Editor), { ref_key: "editor", ref: d, value: unref(S).content_md, "onUpdate:value": (b) => unref(S).content_md = b, plugins: unref(l), onChange: de, uploadImages: qe }, null, 8, ["value", "onUpdate:value", "plugins"])])];
        }), _: 1 }, Fe, ce));
      else
        return [createVNode(Re, { span: 4 }, { default: withCtx(() => [createVNode("div", { class: "notebook" }, [createVNode("div", { class: "notebook-top" }, [createVNode(Ce, { onClick: y, class: "go-btn", type: "primary", ghost: "", shape: "round" }, { default: withCtx(() => [createTextVNode("\u56DE\u9996\u9875")]), _: 1 }), createVNode("div", { onClick: w, class: "add-notebook" }, [createVNode(vt), createTextVNode("\u65B0\u5EFA\u6587\u96C6")]), unref(O) ? (openBlock(), createBlock("div", { key: 0, class: "create-notebook" }, [createVNode(Ne, { value: unref(h), "onUpdate:value": (D) => isRef(h) ? h.value = D : null, class: "notebook-input", placeholder: "\u8BF7\u8F93\u5165\u6587\u96C6\u540D\u79F0..." }, null, 8, ["value", "onUpdate:value"]), createVNode("div", { class: "action-box" }, [createVNode(Ce, { onClick: R, size: "small", shape: "round", ghost: "" }, { default: withCtx(() => [createTextVNode("\u63D0\u4EA4")]), _: 1 }), createVNode(Ce, { onClick: (D) => O.value = false, style: { color: "#9a9a9a" }, type: "text" }, { default: withCtx(() => [createTextVNode("\u53D6\u6D88")]), _: 1 }, 8, ["onClick"])])])) : createCommentVNode("", true)]), createVNode("div", { class: "notebook-center" }, [unref(c).data ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(c).data.list, (D, u) => (openBlock(), createBlock("div", { key: D.id, class: ["notebook-c-item", unref(g) === u ? "active" : ""], onClick: (H) => C(D, u) }, [createVNode("span", null, toDisplayString(D.name), 1), unref(g) === u ? (openBlock(), createBlock(Ue, { key: 0, trigger: ["click"], overlayClassName: "overlayClassName" }, { overlay: withCtx(() => [createVNode(Te, null, { default: withCtx(() => [createVNode(E, { onClick: (H) => U(D) }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(Ae, { style: { "margin-right": "5px" } }), createTextVNode(" \u4FEE\u6539\u6587\u96C6 ")]), _: 1 })]), _: 2 }, 1032, ["onClick"]), createVNode(E, { onClick: (H) => G(D) }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(J, { style: { "margin-right": "5px" } }), createTextVNode(" \u5220\u9664\u6587\u96C6 ")]), _: 1 })]), _: 2 }, 1032, ["onClick"])]), _: 2 }, 1024)]), default: withCtx(() => [createVNode("a", { style: { color: "#ffffff" }, onClick: withModifiers(() => {
        }, ["prevent"]) }, [createVNode($e)], 8, ["onClick"])]), _: 2 }, 1024)) : createCommentVNode("", true)], 10, ["onClick"]))), 128)) : createCommentVNode("", true)])])]), _: 1 }), createVNode(Re, { span: 5, class: "note-writer-list" }, { default: withCtx(() => [createVNode("div", { class: "create", onClick: ge }, [createVNode(mt), createTextVNode(" \u65B0\u5EFA\u6587\u7AE0 ")]), createVNode("div", { class: "note-create" }, [unref(f) ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(f), (D, u) => (openBlock(), createBlock("div", { key: D.id, class: ["note-create-item", unref(q) === u ? "active" : ""], onClick: (H) => me(D, u) }, [createVNode(gt, { class: "text-icon" }), createVNode("span", null, toDisplayString(D.title), 1), unref(q) === u ? (openBlock(), createBlock(Ue, { key: 0, trigger: ["click"], overlayClassName: "overlayClassName" }, { overlay: withCtx(() => [createVNode(Te, null, { default: withCtx(() => [createVNode(E, { onClick: z }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(De, { style: { "margin-right": "5px" } }), createTextVNode(" \u76F4\u63A5\u53D1\u5E03 ")]), _: 1 })]), _: 1 }), createVNode(E, { onClick: z }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(Me, { style: { "margin-right": "5px" } }), createTextVNode(" \u79FB\u52A8\u6587\u7AE0 ")]), _: 1 })]), _: 1 }), createVNode(E, { onClick: (H) => ne(D) }, { default: withCtx(() => [createVNode(T, { type: "flex", justify: "center", align: "middle" }, { default: withCtx(() => [createVNode(J, { style: { "margin-right": "5px" } }), createTextVNode(" \u5220\u9664\u6587\u7AE0 ")]), _: 1 })]), _: 2 }, 1032, ["onClick"])]), _: 2 }, 1024)]), default: withCtx(() => [createVNode("a", { style: { color: "#595959" }, onClick: withModifiers(() => {
        }, ["prevent"]) }, [createVNode($e)], 8, ["onClick"])]), _: 2 }, 1024)) : createCommentVNode("", true)], 10, ["onClick"]))), 128)) : createCommentVNode("", true)])]), _: 1 }), createVNode(Re, { span: 15 }, { default: withCtx(() => [createVNode("div", { class: "edit-note" }, [createVNode("div", { style: { height: "80px", "line-height": "80px" } }, [createVNode(Ne, { onInput: unref(Ee), style: { "font-size": "30px" }, bordered: false, value: unref(S).title, "onUpdate:value": (D) => unref(S).title = D }, null, 8, ["onInput", "value", "onUpdate:value"])]), createVNode(unref(Editor), { ref_key: "editor", ref: d, value: unref(S).content_md, "onUpdate:value": (D) => unref(S).content_md = D, plugins: unref(l), onChange: de, uploadImages: qe }, null, 8, ["value", "onUpdate:value", "plugins"])])]), _: 1 })];
    }), _: 1 }, Y)), A(ssrRenderComponent(yt, { visible: unref($$1), "onUpdate:visible": (pe) => isRef($$1) ? $$1.value = pe : null, width: "25%", title: "\u4FEE\u6539\u6587\u96C6", okText: "\u63D0\u4EA4", cancelText: "\u53D6\u6D88", onOk: K }, { default: withCtx((pe, ae, Fe, ce) => {
      if (ae)
        ae(ssrRenderComponent(Ne, { value: unref(B).name, "onUpdate:value": (D) => unref(B).name = D, style: { height: "40px" }, placeholder: "\u8F93\u5165\u6587\u96C6\u540D\u79F0" }, null, Fe, ce));
      else
        return [createVNode(Ne, { value: unref(B).name, "onUpdate:value": (D) => unref(B).name = D, style: { height: "40px" }, placeholder: "\u8F93\u5165\u6587\u96C6\u540D\u79F0" }, null, 8, ["value", "onUpdate:value"])];
    }), _: 1 }, Y)), A(ssrRenderComponent(yt, { visible: unref(L), "onUpdate:visible": (pe) => isRef(L) ? L.value = pe : null, width: "20%", okText: "\u63D0\u4EA4", cancelText: "\u53D6\u6D88", onOk: le }, { default: withCtx((pe, ae, Fe, ce) => {
      if (ae)
        ae(`<div data-v-7adcdb19${ce}><p style="${ssrRenderStyle({ "margin-top": "30px" })}" data-v-7adcdb19${ce}>\u786E\u8BA4\u5220\u9664\u6587\u96C6\u300A${ssrInterpolate(unref(Z).name)}\u300B\uFF0C\u6587\u7AE0\u5C06\u88AB\u79FB\u52A8\u5230\u56DE\u6536\u7AD9\u3002</p></div>`);
      else
        return [createVNode("div", null, [createVNode("p", { style: { "margin-top": "30px" } }, "\u786E\u8BA4\u5220\u9664\u6587\u96C6\u300A" + toDisplayString(unref(Z).name) + "\u300B\uFF0C\u6587\u7AE0\u5C06\u88AB\u79FB\u52A8\u5230\u56DE\u6536\u7AD9\u3002", 1)])];
    }), _: 1 }, Y)), A(ssrRenderComponent(yt, { visible: unref(te), "onUpdate:visible": (pe) => isRef(te) ? te.value = pe : null, width: "20%", okText: "\u63D0\u4EA4", cancelText: "\u53D6\u6D88", onOk: je }, { default: withCtx((pe, ae, Fe, ce) => {
      if (ae)
        ae(`<div data-v-7adcdb19${ce}><p style="${ssrRenderStyle({ "margin-top": "30px" })}" data-v-7adcdb19${ce}>\u786E\u8BA4\u5220\u9664\u6587\u7AE0\u300A${ssrInterpolate(unref(re).title)}\u300B\uFF0C\u6587\u7AE0\u5C06\u88AB\u79FB\u52A8\u5230\u56DE\u6536\u7AD9\u3002</p></div>`);
      else
        return [createVNode("div", null, [createVNode("p", { style: { "margin-top": "30px" } }, "\u786E\u8BA4\u5220\u9664\u6587\u7AE0\u300A" + toDisplayString(unref(re).title) + "\u300B\uFF0C\u6587\u7AE0\u5C06\u88AB\u79FB\u52A8\u5230\u56DE\u6536\u7AD9\u3002", 1)])];
    }), _: 1 }, Y)), A("<!--]-->");
  };
} }, Vt = wt.setup;
wt.setup = (o2, e) => {
  const i = useSSRContext();
  return (i.modules || (i.modules = /* @__PURE__ */ new Set())).add("pages/note/writer.vue"), Vt ? Vt(o2, e) : void 0;
};
const so = Ea$1(wt, [["__scopeId", "data-v-7adcdb19"]]);

export { so as default };
//# sourceMappingURL=writer-c628936c.mjs.map
