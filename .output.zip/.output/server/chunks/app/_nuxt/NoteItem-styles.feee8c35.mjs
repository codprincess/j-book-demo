const e = `.note-item[data-v-8ef0b14d]{border-bottom:1px solid #f0f0f0;margin-bottom:30px;padding-bottom:25px}.note-item .title[data-v-8ef0b14d]{color:#333;cursor:pointer;display:inherit;font-size:18px;font-weight:700;line-height:1.5;margin:-7px 0 4px}.note-item .title[data-v-8ef0b14d]:hover{text-decoration:underline}.note-item .abstract[data-v-8ef0b14d]{-webkit-line-clamp:2;-webkit-box-orient:vertical;color:#999;display:-webkit-box;font-size:13px;line-height:24px;margin:0 0 8px;overflow:hidden;text-overflow:ellipsis}.note-item .note-img[data-v-8ef0b14d]{display:block;height:100px;width:100%}.note-item .note-img img[data-v-8ef0b14d]{border-radius:4px;height:100%;-o-object-fit:cover;object-fit:cover;overflow:clip;vertical-align:middle;width:100%}.note-item .meta[data-v-8ef0b14d]{font-size:12px;font-weight:400;line-height:20px}.note-item .meta svg[data-v-8ef0b14d]{font-size:11px}.note-item .meta .jsd-meta[data-v-8ef0b14d]{align-items:center;color:#e05344;display:flex;margin-right:10px}.note-item .meta a[data-v-8ef0b14d]{color:#b4b4b4}.note-item .meta a[data-v-8ef0b14d]:hover{color:#333}.note-item .meta .comments[data-v-8ef0b14d],.note-item .meta .like[data-v-8ef0b14d]{align-items:center;display:flex;margin-left:10px}
`;

const NoteItemStyles_feee8c35 = [e];

export { NoteItemStyles_feee8c35 as default };
//# sourceMappingURL=NoteItem-styles.feee8c35.mjs.map
