import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { g as ge, z as zl, $ as $l, b as bl } from './NavBar-24cf260a.mjs';
import { V } from './nuxt-link-00da5e11.mjs';
import { createVNode, defineComponent, ref, reactive, watch, nextTick, Transition, withDirectives, vShow, computed, createElementVNode, mergeProps, withCtx, createTextVNode, toDisplayString, openBlock, createBlock, createCommentVNode, useSSRContext, Fragment, renderList, withAsyncContext, unref, createElementBlock } from 'vue';
import { r } from './diamond-353edae5.mjs';
import { b as bt, C as Ce$1, c as ce, u as ui, n as ne, e as ei, t as ti } from './useHttpFetch-0d93f309.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrRenderStyle } from 'vue/server-renderer';
import { A as AntdIcon, k as ke, R as Ri, N as Nt, p as pe, E as Ea, C as Ci, W as Wr } from '../server.mjs';
import x from '@babel/runtime/helpers/esm/defineProperty';
import v from '@babel/runtime/helpers/esm/objectSpread2';
import ee from '@babel/runtime/helpers/esm/typeof';
import fe from '@babel/runtime/helpers/esm/toConsumableArray';
import 'vue-bundle-renderer/runtime';
import 'h3';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';
import './index-4f8e2b3b.mjs';
import 'lodash-es/uniq.js';
import '@babel/runtime/helpers/esm/objectWithoutProperties';
import '@babel/runtime/helpers/esm/extends';
import '@babel/runtime/helpers/esm/slicedToArray';
import 'lodash-es/isPlainObject.js';
import 'resize-observer-polyfill';
import './logo-7f124be9.mjs';
import 'dom-align';
import 'lodash-es/isEqual.js';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'vue-types';
import '@ant-design/colors';
import '@ctrl/tinycolor';

// This icon file is generated automatically.
var VerticalAlignTopOutlined$1 = { "icon": { "tag": "svg", "attrs": { "viewBox": "64 64 896 896", "focusable": "false" }, "children": [{ "tag": "path", "attrs": { "d": "M859.9 168H164.1c-4.5 0-8.1 3.6-8.1 8v60c0 4.4 3.6 8 8.1 8h695.8c4.5 0 8.1-3.6 8.1-8v-60c0-4.4-3.6-8-8.1-8zM518.3 355a8 8 0 00-12.6 0l-112 141.7a7.98 7.98 0 006.3 12.9h73.9V848c0 4.4 3.6 8 8 8h60c4.4 0 8-3.6 8-8V509.7H624c6.7 0 10.4-7.7 6.3-12.9L518.3 355z" } }] }, "name": "vertical-align-top", "theme": "outlined" };
const VerticalAlignTopOutlinedSvg = VerticalAlignTopOutlined$1;

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? Object(arguments[i]) : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var VerticalAlignTopOutlined = function VerticalAlignTopOutlined(props, context) {
  var p = _objectSpread({}, props, context.attrs);

  return createVNode(AntdIcon, _objectSpread({}, p, {
    "icon": VerticalAlignTopOutlinedSvg
  }), null);
};

VerticalAlignTopOutlined.displayName = 'VerticalAlignTopOutlined';
VerticalAlignTopOutlined.inheritAttrs = false;
const ye = VerticalAlignTopOutlined;

function xe(l) {
  var n, e = function(i) {
    return function() {
      n = null, l.apply(void 0, fe(i));
    };
  }, r = function() {
    if (n == null) {
      for (var i = arguments.length, v = new Array(i), o = 0; o < i; o++)
        v[o] = arguments[o];
      n = ne(e(v));
    }
  };
  return r.cancel = function() {
    return ne.cancel(n);
  }, r;
}
function Ce(l) {
  return l != null && l === l.window;
}
function Ut(l, n) {
  return 0;
}
function we(l, n, e, r) {
  var d = e - n;
  return l /= r / 2, l < 1 ? d / 2 * l * l * l + n : d / 2 * ((l -= 2) * l * l + 2) + n;
}
function $e(l) {
  var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, e = n.getContainer, r = e === void 0 ? function() {
    return window;
  } : e, d = n.callback, i = n.duration, v = i === void 0 ? 450 : i, o = r(), g = Ut(), s = Date.now(), c = function f() {
    var T = Date.now(), p = T - s, C = we(p > v ? v : p, g, l, v);
    Ce(o) ? o.scrollTo(window.pageXOffset, C) : o instanceof HTMLDocument || o.constructor.name === "HTMLDocument" ? o.documentElement.scrollTop = C : o.scrollTop = C, p < v ? ne(f) : typeof d == "function" && d();
  };
  ne(c);
}
var be = function() {
  return { visibilityHeight: { type: Number, default: 400 }, duration: { type: Number, default: 450 }, target: Function, prefixCls: String, onClick: Function };
}, Se = defineComponent({ compatConfig: { MODE: 3 }, name: "ABackTop", inheritAttrs: false, props: be(), setup: function(n, e) {
  var r = e.slots, d = e.attrs, i = e.emit, v$1 = ke("back-top", n), o = v$1.prefixCls, g = v$1.direction, s = ref(), c = reactive({ visible: false, scrollEvent: null }), f = function() {
    return s.value && s.value.ownerDocument ? s.value.ownerDocument : window;
  }, T = function(u) {
    var w = n.target, k = w === void 0 ? f : w, h = n.duration;
    $e(0, { getContainer: k, duration: h }), i("click", u);
  }, p = xe(function(_) {
    var u = n.visibilityHeight, w = Ut(_.target);
    c.visible = w > u;
  }), C = function() {
    var u = n.target, w = u || f, k = w();
    c.scrollEvent = ce(k, "scroll", function(h) {
      p(h);
    }), p({ target: k });
  }, x$1 = function() {
    c.scrollEvent && c.scrollEvent.remove(), p.cancel();
  };
  return watch(function() {
    return n.target;
  }, function() {
    x$1(), nextTick(function() {
      C();
    });
  }), function() {
    var _, u, w = createVNode("div", { class: "".concat(o.value, "-content") }, [createVNode("div", { class: "".concat(o.value, "-icon") }, [createVNode(ye, null, null)])]), k = v(v({}, d), {}, { onClick: T, class: (_ = {}, x(_, "".concat(o.value), true), x(_, "".concat(d.class), d.class), x(_, "".concat(o.value, "-rtl"), g.value === "rtl"), _) }), h = Ri("fade");
    return createVNode(Transition, h, { default: function() {
      return [withDirectives(createVNode("div", v(v({}, k), {}, { ref: s }), [((u = r.default) === null || u === void 0 ? void 0 : u.call(r)) || w]), [[vShow, c.visible]])];
    } });
  };
} });
const he = Nt(Se);
var Te = function() {
  return { prefixCls: String, width: { type: [Number, String] } };
}, Be = defineComponent({ compatConfig: { MODE: 3 }, name: "SkeletonTitle", props: Te(), setup: function(n) {
  return function() {
    var e = n.prefixCls, r = n.width, d = typeof r == "number" ? "".concat(r, "px") : r;
    return createVNode("h3", { class: e, style: { width: d } }, null);
  };
} });
const ht = Be;
var Le = function() {
  return { prefixCls: String, width: { type: [Number, String, Array] }, rows: Number };
}, Ae = defineComponent({ compatConfig: { MODE: 3 }, name: "SkeletonParagraph", props: Le(), setup: function(n) {
  var e = function(d) {
    var i = n.width, v = n.rows, o = v === void 0 ? 2 : v;
    if (Array.isArray(i))
      return i[d];
    if (o - 1 === d)
      return i;
  };
  return function() {
    var r = n.prefixCls, d = n.rows, i = fe(Array(d)).map(function(v, o) {
      var g = e(o);
      return createVNode("li", { key: o, style: { width: typeof g == "number" ? "".concat(g, "px") : g } }, null);
    });
    return createVNode("ul", { class: r }, [i]);
  };
} });
const Ee = Ae;
var ft = function() {
  return { prefixCls: String, size: [String, Number], shape: String, active: { type: Boolean, default: void 0 } };
}, Wt = function(n) {
  var e, r, d = n.prefixCls, i = n.size, v = n.shape, o = pe((e = {}, x(e, "".concat(d, "-lg"), i === "large"), x(e, "".concat(d, "-sm"), i === "small"), e)), g = pe((r = {}, x(r, "".concat(d, "-circle"), v === "circle"), x(r, "".concat(d, "-square"), v === "square"), x(r, "".concat(d, "-round"), v === "round"), r)), s = typeof i == "number" ? { width: "".concat(i, "px"), height: "".concat(i, "px"), lineHeight: "".concat(i, "px") } : {};
  return createVNode("span", { class: pe(d, o, g), style: s }, null);
};
Wt.displayName = "SkeletonElement";
const mt = Wt;
var Pe = function() {
  return { active: { type: Boolean, default: void 0 }, loading: { type: Boolean, default: void 0 }, prefixCls: String, avatar: { type: [Boolean, Object], default: void 0 }, title: { type: [Boolean, Object], default: void 0 }, paragraph: { type: [Boolean, Object], default: void 0 }, round: { type: Boolean, default: void 0 } };
};
function yt(l) {
  return l && ee(l) === "object" ? l : {};
}
function ze(l, n) {
  return l && !n ? { size: "large", shape: "square" } : { size: "large", shape: "circle" };
}
function Re(l, n) {
  return !l && n ? { width: "38%" } : l && n ? { width: "50%" } : {};
}
function De(l, n) {
  var e = {};
  return (!l || !n) && (e.width = "61%"), !l && n ? e.rows = 3 : e.rows = 2, e;
}
var Me = defineComponent({ compatConfig: { MODE: 3 }, name: "ASkeleton", props: bt(Pe(), { avatar: false, title: true, paragraph: true }), setup: function(n, e) {
  var r = e.slots, d = ke("skeleton", n), i = d.prefixCls, v$1 = d.direction;
  return function() {
    var o, g = n.loading, s = n.avatar, c = n.title, f = n.paragraph, T = n.active, p = n.round, C = i.value;
    if (g || n.loading === void 0) {
      var x$1, _ = !!s || s === "", u = !!c || c === "", w = !!f || f === "", k;
      if (_) {
        var h = v(v({ prefixCls: "".concat(C, "-avatar") }, ze(u, w)), yt(s));
        k = createVNode("div", { class: "".concat(C, "-header") }, [createVNode(mt, h, null)]);
      }
      var L;
      if (u || w) {
        var V;
        if (u) {
          var E = v(v({ prefixCls: "".concat(C, "-title") }, Re(_, w)), yt(c));
          V = createVNode(ht, E, null);
        }
        var O;
        if (w) {
          var z = v(v({ prefixCls: "".concat(C, "-paragraph") }, De(_, u)), yt(f));
          O = createVNode(Ee, z, null);
        }
        L = createVNode("div", { class: "".concat(C, "-content") }, [V, O]);
      }
      var H = pe(C, (x$1 = {}, x(x$1, "".concat(C, "-with-avatar"), _), x(x$1, "".concat(C, "-active"), T), x(x$1, "".concat(C, "-rtl"), v$1.value === "rtl"), x(x$1, "".concat(C, "-round"), p), x$1));
      return createVNode("div", { class: H }, [k, L]);
    }
    return (o = r.default) === null || o === void 0 ? void 0 : o.call(r);
  };
} });
const M = Me;
var je = function() {
  return v(v({}, ft()), {}, { size: String, block: Boolean });
}, Ne = defineComponent({ compatConfig: { MODE: 3 }, name: "ASkeletonButton", props: bt(je(), { size: "default" }), setup: function(n) {
  var e = ke("skeleton", n), r = e.prefixCls, d = computed(function() {
    var i;
    return pe(r.value, "".concat(r.value, "-element"), (i = {}, x(i, "".concat(r.value, "-active"), n.active), x(i, "".concat(r.value, "-block"), n.block), i));
  });
  return function() {
    return createVNode("div", { class: d.value }, [createVNode(mt, v(v({}, n), {}, { prefixCls: "".concat(r.value, "-button") }), null)]);
  };
} });
const It = Ne;
var Oe = defineComponent({ compatConfig: { MODE: 3 }, name: "ASkeletonInput", props: v(v({}, Ce$1(ft(), ["shape"])), {}, { size: String }), setup: function(n) {
  var e = ke("skeleton", n), r = e.prefixCls, d = computed(function() {
    return pe(r.value, "".concat(r.value, "-element"), x({}, "".concat(r.value, "-active"), n.active));
  });
  return function() {
    return createVNode("div", { class: d.value }, [createVNode(mt, v(v({}, n), {}, { prefixCls: "".concat(r.value, "-input") }), null)]);
  };
} });
const Zt = Oe;
var qe = "M365.714286 329.142857q0 45.714286-32.036571 77.677714t-77.677714 32.036571-77.677714-32.036571-32.036571-77.677714 32.036571-77.677714 77.677714-32.036571 77.677714 32.036571 32.036571 77.677714zM950.857143 548.571429l0 256-804.571429 0 0-109.714286 182.857143-182.857143 91.428571 91.428571 292.571429-292.571429zM1005.714286 146.285714l-914.285714 0q-7.460571 0-12.873143 5.412571t-5.412571 12.873143l0 694.857143q0 7.460571 5.412571 12.873143t12.873143 5.412571l914.285714 0q7.460571 0 12.873143-5.412571t5.412571-12.873143l0-694.857143q0-7.460571-5.412571-12.873143t-12.873143-5.412571zM1097.142857 164.571429l0 694.857143q0 37.741714-26.843429 64.585143t-64.585143 26.843429l-914.285714 0q-37.741714 0-64.585143-26.843429t-26.843429-64.585143l0-694.857143q0-37.741714 26.843429-64.585143t64.585143-26.843429l914.285714 0q37.741714 0 64.585143 26.843429t26.843429 64.585143z", He = defineComponent({ compatConfig: { MODE: 3 }, name: "ASkeletonImage", props: Ce$1(ft(), ["size", "shape", "active"]), setup: function(n) {
  var e = ke("skeleton", n), r = e.prefixCls, d = computed(function() {
    return pe(r.value, "".concat(r.value, "-element"));
  });
  return function() {
    return createVNode("div", { class: d.value }, [createVNode("div", { class: "".concat(r.value, "-image") }, [createVNode("svg", { viewBox: "0 0 1098 1024", xmlns: "http://www.w3.org/2000/svg", class: "".concat(r.value, "-image-svg") }, [createVNode("path", { d: qe, class: "".concat(r.value, "-image-path") }, null)])])]);
  };
} });
const Gt = He;
var Ve = function() {
  return v(v({}, ft()), {}, { shape: String });
}, Fe = defineComponent({ compatConfig: { MODE: 3 }, name: "ASkeletonAvatar", props: bt(Ve(), { size: "default", shape: "circle" }), setup: function(n) {
  var e = ke("skeleton", n), r = e.prefixCls, d = computed(function() {
    return pe(r.value, "".concat(r.value, "-element"), x({}, "".concat(r.value, "-active"), n.active));
  });
  return function() {
    return createVNode("div", { class: d.value }, [createVNode(mt, v(v({}, n), {}, { prefixCls: "".concat(r.value, "-avatar") }), null)]);
  };
} });
const Xt = Fe;
M.Button = It;
M.Avatar = Xt;
M.Input = Zt;
M.Image = Gt;
M.Title = ht;
M.install = function(l) {
  return l.component(M.name, M), l.component(M.Button.name, It), l.component(M.Avatar.name, Xt), l.component(M.Input.name, Zt), l.component(M.Image.name, Gt), l.component(M.Title.name, ht), l;
};
const Ue = { viewBox: "0 0 24 24", width: "1.2em", height: "1.2em" }, We = createElementVNode("path", { fill: "currentColor", d: "m12 21.35l-1.45-1.32C5.4 15.36 2 12.27 2 8.5C2 5.41 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.08C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.41 22 8.5c0 3.77-3.4 6.86-8.55 11.53L12 21.35Z" }, null, -1), Ie = [We];
function Ze(l, n) {
  return openBlock(), createElementBlock("svg", Ue, Ie);
}
const Ge = { name: "mdi-cards-heart", render: Ze }, Xe = { viewBox: "0 0 24 24", width: "1.2em", height: "1.2em" }, Je = createElementVNode("path", { fill: "currentColor", d: "M20 2H4a2 2 0 0 0-2 2v18l4-4h14a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2Z" }, null, -1), Ke = [Je];
function Qe(l, n) {
  return openBlock(), createElementBlock("svg", Xe, Ke);
}
const Ye = { name: "mdi-message", render: Qe };
const Tt = { __name: "NoteItem", __ssrInlineRender: true, props: ["note", "index"], emits: ["like"], setup(l, { emit: n }) {
  const e = l;
  function r$1() {
    n("like", e.note.like, e.index, e.note.flag);
  }
  return reactive({ data: [{ id: 1, item: "item 1" }, { id: 2, item: "item 2" }, { id: 3, item: "item 3" }, { id: 4, item: "item 4" }, { id: 5, item: "item 5" }, { id: 1, item: "item 1" }, { id: 2, item: "item 2" }, { id: 3, item: "item 3" }, { id: 4, item: "item 4" }, { id: 5, item: "item 5" }] }), (d, i, v, o) => {
    const g = ei, s = ti, c = V, f = r, T = Ye, p = Ge;
    e.note ? i(ssrRenderComponent(g, mergeProps({ class: "note-item" }, o), { default: withCtx((C, x, _, u) => {
      if (x)
        x(ssrRenderComponent(s, { span: e.note.cover ? 17 : 23 }, { default: withCtx((w, k, h, L) => {
          if (k)
            k(ssrRenderComponent(c, { to: { path: "/p/" + e.note.id }, class: "title" }, { default: withCtx((V, E, O, z) => {
              if (E)
                E(`${ssrInterpolate(e.note.title)}`);
              else
                return [createTextVNode(toDisplayString(e.note.title), 1)];
            }), _: 1 }, h, L)), k(`<p class="abstract" data-v-8ef0b14d${L}>${ssrInterpolate(e.note.subTitle)}</p>`), k(ssrRenderComponent(g, { class: "meta" }, { default: withCtx((V, E, O, z) => {
              if (E)
                E(ssrRenderComponent(s, { class: "jsd-meta" }, { default: withCtx((H, A, q, P) => {
                  if (A)
                    A(ssrRenderComponent(f, null, null, q, P)), A("136.0");
                  else
                    return [createVNode(f), createTextVNode("136.0")];
                }), _: 1 }, O, z)), E(ssrRenderComponent(c, { class: "nickname" }, { default: withCtx((H, A, q, P) => {
                  if (A)
                    A(`${ssrInterpolate(e.note.nickname)}`);
                  else
                    return [createTextVNode(toDisplayString(e.note.nickname), 1)];
                }), _: 1 }, O, z)), E(ssrRenderComponent(c, { class: "comments" }, { default: withCtx((H, A, q, P) => {
                  if (A)
                    A(ssrRenderComponent(T, null, null, q, P)), A(" 10");
                  else
                    return [createVNode(T), createTextVNode(" 10")];
                }), _: 1 }, O, z)), E(ssrRenderComponent(c, { class: "like", onClick: r$1 }, { default: withCtx((H, A, q, P) => {
                  if (A)
                    A(ssrRenderComponent(p, { style: { color: e.note.flag ? "red" : "" } }, null, q, P)), A(`${ssrInterpolate(e.note.like)}`);
                  else
                    return [createVNode(p, { style: { color: e.note.flag ? "red" : "" } }, null, 8, ["style"]), createTextVNode(toDisplayString(e.note.like), 1)];
                }), _: 1 }, O, z));
              else
                return [createVNode(s, { class: "jsd-meta" }, { default: withCtx(() => [createVNode(f), createTextVNode("136.0")]), _: 1 }), createVNode(c, { class: "nickname" }, { default: withCtx(() => [createTextVNode(toDisplayString(e.note.nickname), 1)]), _: 1 }), createVNode(c, { class: "comments" }, { default: withCtx(() => [createVNode(T), createTextVNode(" 10")]), _: 1 }), createVNode(c, { class: "like", onClick: r$1 }, { default: withCtx(() => [createVNode(p, { style: { color: e.note.flag ? "red" : "" } }, null, 8, ["style"]), createTextVNode(toDisplayString(e.note.like), 1)]), _: 1 })];
            }), _: 1 }, h, L));
          else
            return [createVNode(c, { to: { path: "/p/" + e.note.id }, class: "title" }, { default: withCtx(() => [createTextVNode(toDisplayString(e.note.title), 1)]), _: 1 }, 8, ["to"]), createVNode("p", { class: "abstract" }, toDisplayString(e.note.subTitle), 1), createVNode(g, { class: "meta" }, { default: withCtx(() => [createVNode(s, { class: "jsd-meta" }, { default: withCtx(() => [createVNode(f), createTextVNode("136.0")]), _: 1 }), createVNode(c, { class: "nickname" }, { default: withCtx(() => [createTextVNode(toDisplayString(e.note.nickname), 1)]), _: 1 }), createVNode(c, { class: "comments" }, { default: withCtx(() => [createVNode(T), createTextVNode(" 10")]), _: 1 }), createVNode(c, { class: "like", onClick: r$1 }, { default: withCtx(() => [createVNode(p, { style: { color: e.note.flag ? "red" : "" } }, null, 8, ["style"]), createTextVNode(toDisplayString(e.note.like), 1)]), _: 1 })]), _: 1 })];
        }), _: 1 }, _, u)), x(ssrRenderComponent(s, { span: 1 }, null, _, u)), e.note.cover ? x(ssrRenderComponent(s, { span: 6 }, { default: withCtx((w, k, h, L) => {
          if (k)
            k(ssrRenderComponent(c, { to: { path: "/p/" + e.note.id }, class: "note-img", style: {} }, { default: withCtx((V, E, O, z) => {
              if (E)
                E(`<img${ssrRenderAttr("src", e.note.cover)} alt="cover" data-v-8ef0b14d${z}>`);
              else
                return [createVNode("img", { src: e.note.cover, alt: "cover" }, null, 8, ["src"])];
            }), _: 1 }, h, L));
          else
            return [createVNode(c, { to: { path: "/p/" + e.note.id }, class: "note-img", style: {} }, { default: withCtx(() => [createVNode("img", { src: e.note.cover, alt: "cover" }, null, 8, ["src"])]), _: 1 }, 8, ["to"])];
        }), _: 1 }, _, u)) : x("<!---->");
      else
        return [createVNode(s, { span: e.note.cover ? 17 : 23 }, { default: withCtx(() => [createVNode(c, { to: { path: "/p/" + e.note.id }, class: "title" }, { default: withCtx(() => [createTextVNode(toDisplayString(e.note.title), 1)]), _: 1 }, 8, ["to"]), createVNode("p", { class: "abstract" }, toDisplayString(e.note.subTitle), 1), createVNode(g, { class: "meta" }, { default: withCtx(() => [createVNode(s, { class: "jsd-meta" }, { default: withCtx(() => [createVNode(f), createTextVNode("136.0")]), _: 1 }), createVNode(c, { class: "nickname" }, { default: withCtx(() => [createTextVNode(toDisplayString(e.note.nickname), 1)]), _: 1 }), createVNode(c, { class: "comments" }, { default: withCtx(() => [createVNode(T), createTextVNode(" 10")]), _: 1 }), createVNode(c, { class: "like", onClick: r$1 }, { default: withCtx(() => [createVNode(p, { style: { color: e.note.flag ? "red" : "" } }, null, 8, ["style"]), createTextVNode(toDisplayString(e.note.like), 1)]), _: 1 })]), _: 1 })]), _: 1 }, 8, ["span"]), createVNode(s, { span: 1 }), e.note.cover ? (openBlock(), createBlock(s, { key: 0, span: 6 }, { default: withCtx(() => [createVNode(c, { to: { path: "/p/" + e.note.id }, class: "note-img", style: {} }, { default: withCtx(() => [createVNode("img", { src: e.note.cover, alt: "cover" }, null, 8, ["src"])]), _: 1 }, 8, ["to"])]), _: 1 })) : createCommentVNode("", true)];
    }), _: 1 }, v)) : i("<!---->");
  };
} }, Rt = Tt.setup;
Tt.setup = (l, n) => {
  const e = useSSRContext();
  return (e.modules || (e.modules = /* @__PURE__ */ new Set())).add("components/NoteItem.vue"), Rt ? Rt(l, n) : void 0;
};
const tn = Ea(Tt, [["__scopeId", "data-v-8ef0b14d"]]), xt = "" + publicAssetsURL("images/banner-s-daily.png"), Ct = "" + publicAssetsURL("images/banner-s-club.png"), wt = "" + publicAssetsURL("images/banner-s.png"), $t = "" + publicAssetsURL("images/banner-s-5.png");
const Bt = {};
function en(l, n, e, r) {
  const d = ei, i = V;
  n(ssrRenderComponent(d, r, { default: withCtx((v, o, g, s) => {
    if (o)
      o(`<div class="board" data-v-77f317c5${s}>`), o(ssrRenderComponent(i, null, { default: withCtx((c, f, T, p) => {
        if (f)
          f(`<img${ssrRenderAttr("src", xt)} alt="" data-v-77f317c5${p}>`);
        else
          return [createVNode("img", { src: xt, alt: "" })];
      }), _: 1 }, g, s)), o(ssrRenderComponent(i, null, { default: withCtx((c, f, T, p) => {
        if (f)
          f(`<img${ssrRenderAttr("src", Ct)} alt="" data-v-77f317c5${p}>`);
        else
          return [createVNode("img", { src: Ct, alt: "" })];
      }), _: 1 }, g, s)), o(ssrRenderComponent(i, null, { default: withCtx((c, f, T, p) => {
        if (f)
          f(`<img${ssrRenderAttr("src", wt)} alt="" data-v-77f317c5${p}>`);
        else
          return [createVNode("img", { src: wt, alt: "" })];
      }), _: 1 }, g, s)), o(ssrRenderComponent(i, null, { default: withCtx((c, f, T, p) => {
        if (f)
          f(`<img${ssrRenderAttr("src", $t)} alt="" data-v-77f317c5${p}>`);
        else
          return [createVNode("img", { src: $t, alt: "" })];
      }), _: 1 }, g, s)), o("</div>");
    else
      return [createVNode("div", { class: "board" }, [createVNode(i, null, { default: withCtx(() => [createVNode("img", { src: xt, alt: "" })]), _: 1 }), createVNode(i, null, { default: withCtx(() => [createVNode("img", { src: Ct, alt: "" })]), _: 1 }), createVNode(i, null, { default: withCtx(() => [createVNode("img", { src: wt, alt: "" })]), _: 1 }), createVNode(i, null, { default: withCtx(() => [createVNode("img", { src: $t, alt: "" })]), _: 1 })])];
  }), _: 1 }, e));
}
const Dt = Bt.setup;
Bt.setup = (l, n) => {
  const e = useSSRContext();
  return (e.modules || (e.modules = /* @__PURE__ */ new Set())).add("components/BannerSider.vue"), Dt ? Dt(l, n) : void 0;
};
const nn = Ea(Bt, [["ssrRender", en], ["__scopeId", "data-v-77f317c5"]]), an = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, ln = createElementVNode("path", { fill: "currentColor", d: "M771.776 794.88A384 384 0 0 1 128 512h64a320 320 0 0 0 555.712 216.448H654.72a32 32 0 1 1 0-64h149.056a32 32 0 0 1 32 32v148.928a32 32 0 1 1-64 0v-50.56zM276.288 295.616h92.992a32 32 0 0 1 0 64H220.16a32 32 0 0 1-32-32V178.56a32 32 0 0 1 64 0v50.56A384 384 0 0 1 896.128 512h-64a320 320 0 0 0-555.776-216.384z" }, null, -1), on = [ln];
function rn(l, n) {
  return openBlock(), createElementBlock("svg", an, on);
}
const sn = { name: "ep-refresh", render: rn }, lt = "" + publicAssetsURL("images/default-avatar.png");
const Lt = {};
function cn(l, n, e, r) {
  const d = ei, i = V, v = sn, o = ge;
  n(ssrRenderComponent(d, r, { default: withCtx((g, s, c, f) => {
    if (s)
      s(`<div class="recommended-authors" data-v-df5074f5${f}><div class="title" data-v-df5074f5${f}><span data-v-df5074f5${f}>\u63A8\u8350\u4F5C\u8005</span>`), s(ssrRenderComponent(i, null, { default: withCtx((T, p, C, x) => {
        if (p)
          p(ssrRenderComponent(v, null, null, C, x)), p("\u6362\u4E00\u6279");
        else
          return [createVNode(v), createTextVNode("\u6362\u4E00\u6279")];
      }), _: 1 }, c, f)), s(`</div><div class="list" data-v-df5074f5${f}><!--[-->`), ssrRenderList([1, 2, 3, 4, 5], (T, p) => {
        s(`<div class="list-item" data-v-df5074f5${f}>`), s(ssrRenderComponent(i, null, { default: withCtx((C, x, _, u) => {
          if (x)
            x(ssrRenderComponent(o, { size: 44 }, { icon: withCtx((w, k, h, L) => {
              if (k)
                k(`<img${ssrRenderAttr("src", lt)} alt="avatar" data-v-df5074f5${L}>`);
              else
                return [createVNode("img", { src: lt, alt: "avatar" })];
            }), _: 2 }, _, u));
          else
            return [createVNode(o, { size: 44 }, { icon: withCtx(() => [createVNode("img", { src: lt, alt: "avatar" })]), _: 1 })];
        }), _: 2 }, c, f)), s(`<div class="authors-info" data-v-df5074f5${f}><div class="authors-name" data-v-df5074f5${f}><span data-v-df5074f5${f}>\u5C0F\u57CB</span>`), s(ssrRenderComponent(i, null, { default: withCtx((C, x, _, u) => {
          if (x)
            x("+ \u5173\u6CE8");
          else
            return [createTextVNode("+ \u5173\u6CE8")];
        }), _: 2 }, c, f)), s(`</div><p data-v-df5074f5${f}>\u5199\u4E86269.3k\u5B57 \xB7 31.6k\u559C\u6B22</p></div></div>`);
      }), s("<!--]--></div></div>");
    else
      return [createVNode("div", { class: "recommended-authors" }, [createVNode("div", { class: "title" }, [createVNode("span", null, "\u63A8\u8350\u4F5C\u8005"), createVNode(i, null, { default: withCtx(() => [createVNode(v), createTextVNode("\u6362\u4E00\u6279")]), _: 1 })]), createVNode("div", { class: "list" }, [(openBlock(), createBlock(Fragment, null, renderList([1, 2, 3, 4, 5], (T, p) => createVNode("div", { class: "list-item" }, [createVNode(i, null, { default: withCtx(() => [createVNode(o, { size: 44 }, { icon: withCtx(() => [createVNode("img", { src: lt, alt: "avatar" })]), _: 1 })]), _: 1 }), createVNode("div", { class: "authors-info" }, [createVNode("div", { class: "authors-name" }, [createVNode("span", null, "\u5C0F\u57CB"), createVNode(i, null, { default: withCtx(() => [createTextVNode("+ \u5173\u6CE8")]), _: 1 })]), createVNode("p", null, "\u5199\u4E86269.3k\u5B57 \xB7 31.6k\u559C\u6B22")])])), 64))])])];
  }), _: 1 }, e));
}
const Mt = Lt.setup;
Lt.setup = (l, n) => {
  const e = useSSRContext();
  return (e.modules || (e.modules = /* @__PURE__ */ new Set())).add("components/RecommendAuthor.vue"), Mt ? Mt(l, n) : void 0;
};
const un = Ea(Lt, [["ssrRender", cn], ["__scopeId", "data-v-df5074f5"]]), dn = { viewBox: "0 0 1024 1024", width: "1.2em", height: "1.2em" }, fn = createElementVNode("path", { fill: "currentColor", d: "M868 545.5L536.1 163a31.96 31.96 0 0 0-48.3 0L156 545.5a7.97 7.97 0 0 0 6 13.2h81c4.6 0 9-2 12.1-5.5L474 300.9V864c0 4.4 3.6 8 8 8h60c4.4 0 8-3.6 8-8V300.9l218.9 252.3c3 3.5 7.4 5.5 12.1 5.5h81c6.8 0 10.5-8 6-13.2z" }, null, -1), mn = [fn];
function vn(l, n) {
  return openBlock(), createElementBlock("svg", dn, mn);
}
const _n = { name: "ant-design-arrow-up-outlined", render: vn };
const At = { __name: "index", __ssrInlineRender: true, async setup(l) {
  let n, e;
  Ci({ title: "\u7B80\u4E66", meta: [{ name: "description", content: "\u7B80\u4E66\u662F\u4E00\u4E2A\u4F18\u8D28\u7684\u521B\u4F5C\u793E\u533A\uFF0C\u5728\u8FD9\u91CC\uFF0C\u4F60\u53EF\u4EE5\u4EFB\u6027\u5730\u521B\u4F5C\uFF0C\u4E00\u7BC7\u77ED\u6587\u3001\u4E00\u5F20\u7167\u7247\u3001\u4E00\u9996\u8BD7\u3001\u4E00\u5E45\u753B\u2026\u2026\u6211\u4EEC\u76F8\u4FE1\uFF0C\u6BCF\u4E2A\u4EBA\u90FD\u662F\u751F\u6D3B\u4E2D\u7684\u827A\u672F\u5BB6\uFF0C\u6709\u7740\u65E0\u7A77\u7684\u521B\u9020\u529B\u3002" }, { name: "keywords", content: "\u7B80\u4E66,\u7B80\u4E66\u5B98\u7F51,\u56FE\u6587\u7F16\u8F91\u8F6F\u4EF6,\u7B80\u4E66\u4E0B\u8F7D,\u56FE\u6587\u521B\u4F5C,\u521B\u4F5C\u8F6F\u4EF6,\u539F\u521B\u793E\u533A,\u5C0F\u8BF4,\u6563\u6587,\u5199\u4F5C,\u9605\u8BFB" }] });
  const r = ref(1), d = ref(8), i = ref(false), v = ref(false), { data: o } = ([n, e] = withAsyncContext(() => ui({ method: "GET", server: true, params: { page: r.value, pageSize: d.value }, key: "noteList" })), n = await n, e(), n);
  if (o.value.code === 1)
    throw Wr({ statusCode: 500, statusMessage: "\u670D\u52A1\u5668\u62A5\u9519~~" });
  i.value = true;
  const g = (s, c, f) => {
    if (f) {
      s = s - 1, o.value.data.list[c].like = s, o.value.data.list[c].flag = false;
      return;
    }
    s = s + 1, o.value.data.list[c].like = s, o.value.data.list[c].flag = true;
  };
  return (s, c, f, T) => {
    const p = zl, C = $l, x = bl, _ = ei, u = ti, w = tn, k = M, h = nn, L = un, V = he, E = _n;
    c(ssrRenderComponent(p, mergeProps({ style: { height: "100vh", "background-color": "#ffffff" } }, T), { default: withCtx((O, z, H, A) => {
      if (z)
        z(ssrRenderComponent(C, null, null, H, A)), z(ssrRenderComponent(x, null, { default: withCtx((q, P, vt, et) => {
          if (P)
            P(ssrRenderComponent(_, { type: "flex", justify: "center", style: { "margin-top": "100px" } }, { default: withCtx((Et, K, Jt, Kt) => {
              if (K)
                K(ssrRenderComponent(u, { span: 12 }, { default: withCtx((Pt, Q, Qt, Yt) => {
                  if (Q)
                    Q(ssrRenderComponent(_, null, { default: withCtx((zt, W, _t, pt) => {
                      if (W)
                        W(ssrRenderComponent(u, { span: 16 }, { default: withCtx((gt, D, Y, G) => {
                          if (D)
                            unref(o).data ? (D("<!--[-->"), ssrRenderList(unref(o).data.list, (kt, nt) => {
                              D(ssrRenderComponent(w, { note: kt, index: nt, onLike: g }, null, Y, G));
                            }), D("<!--]-->")) : D("<!---->"), D(ssrRenderComponent(k, { loading: unref(i), active: "" }, null, Y, G)), unref(v) ? D(`<div style="${ssrRenderStyle({ "text-align": "center" })}" data-v-79687a53${G}>\u6CA1\u6709\u6570\u636E\u5566~~</div>`) : D("<!---->");
                          else
                            return [unref(o).data ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(o).data.list, (kt, nt) => (openBlock(), createBlock(w, { key: nt, note: kt, index: nt, onLike: g }, null, 8, ["note", "index"]))), 128)) : createCommentVNode("", true), createVNode(k, { loading: unref(i), active: "" }, null, 8, ["loading"]), unref(v) ? (openBlock(), createBlock("div", { key: 1, style: { "text-align": "center" } }, "\u6CA1\u6709\u6570\u636E\u5566~~")) : createCommentVNode("", true)];
                        }), _: 1 }, _t, pt)), W(ssrRenderComponent(u, { span: 1 }, null, _t, pt)), W(ssrRenderComponent(u, { span: 7 }, { default: withCtx((gt, D, Y, G) => {
                          if (D)
                            D(ssrRenderComponent(h, null, null, Y, G)), D(ssrRenderComponent(L, null, null, Y, G));
                          else
                            return [createVNode(h), createVNode(L)];
                        }), _: 1 }, _t, pt));
                      else
                        return [createVNode(u, { span: 16 }, { default: withCtx(() => [unref(o).data ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(o).data.list, (gt, D) => (openBlock(), createBlock(w, { key: D, note: gt, index: D, onLike: g }, null, 8, ["note", "index"]))), 128)) : createCommentVNode("", true), createVNode(k, { loading: unref(i), active: "" }, null, 8, ["loading"]), unref(v) ? (openBlock(), createBlock("div", { key: 1, style: { "text-align": "center" } }, "\u6CA1\u6709\u6570\u636E\u5566~~")) : createCommentVNode("", true)]), _: 1 }), createVNode(u, { span: 1 }), createVNode(u, { span: 7 }, { default: withCtx(() => [createVNode(h), createVNode(L)]), _: 1 })];
                    }), _: 1 }, Qt, Yt));
                  else
                    return [createVNode(_, null, { default: withCtx(() => [createVNode(u, { span: 16 }, { default: withCtx(() => [unref(o).data ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(o).data.list, (zt, W) => (openBlock(), createBlock(w, { key: W, note: zt, index: W, onLike: g }, null, 8, ["note", "index"]))), 128)) : createCommentVNode("", true), createVNode(k, { loading: unref(i), active: "" }, null, 8, ["loading"]), unref(v) ? (openBlock(), createBlock("div", { key: 1, style: { "text-align": "center" } }, "\u6CA1\u6709\u6570\u636E\u5566~~")) : createCommentVNode("", true)]), _: 1 }), createVNode(u, { span: 1 }), createVNode(u, { span: 7 }, { default: withCtx(() => [createVNode(h), createVNode(L)]), _: 1 })]), _: 1 })];
                }), _: 1 }, Jt, Kt));
              else
                return [createVNode(u, { span: 12 }, { default: withCtx(() => [createVNode(_, null, { default: withCtx(() => [createVNode(u, { span: 16 }, { default: withCtx(() => [unref(o).data ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(o).data.list, (Pt, Q) => (openBlock(), createBlock(w, { key: Q, note: Pt, index: Q, onLike: g }, null, 8, ["note", "index"]))), 128)) : createCommentVNode("", true), createVNode(k, { loading: unref(i), active: "" }, null, 8, ["loading"]), unref(v) ? (openBlock(), createBlock("div", { key: 1, style: { "text-align": "center" } }, "\u6CA1\u6709\u6570\u636E\u5566~~")) : createCommentVNode("", true)]), _: 1 }), createVNode(u, { span: 1 }), createVNode(u, { span: 7 }, { default: withCtx(() => [createVNode(h), createVNode(L)]), _: 1 })]), _: 1 })]), _: 1 })];
            }), _: 1 }, vt, et));
          else
            return [createVNode(_, { type: "flex", justify: "center", style: { "margin-top": "100px" } }, { default: withCtx(() => [createVNode(u, { span: 12 }, { default: withCtx(() => [createVNode(_, null, { default: withCtx(() => [createVNode(u, { span: 16 }, { default: withCtx(() => [unref(o).data ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(o).data.list, (Et, K) => (openBlock(), createBlock(w, { key: K, note: Et, index: K, onLike: g }, null, 8, ["note", "index"]))), 128)) : createCommentVNode("", true), createVNode(k, { loading: unref(i), active: "" }, null, 8, ["loading"]), unref(v) ? (openBlock(), createBlock("div", { key: 1, style: { "text-align": "center" } }, "\u6CA1\u6709\u6570\u636E\u5566~~")) : createCommentVNode("", true)]), _: 1 }), createVNode(u, { span: 1 }), createVNode(u, { span: 7 }, { default: withCtx(() => [createVNode(h), createVNode(L)]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })];
        }), _: 1 }, H, A)), z(`<div id="components-back-top-demo-custom" data-v-79687a53${A}>`), z(ssrRenderComponent(V, null, { default: withCtx((q, P, vt, et) => {
          if (P)
            P(`<div class="ant-back-top-inner" data-v-79687a53${et}>`), P(ssrRenderComponent(E, null, null, vt, et)), P("</div>");
          else
            return [createVNode("div", { class: "ant-back-top-inner" }, [createVNode(E)])];
        }), _: 1 }, H, A)), z("</div>");
      else
        return [createVNode(C), createVNode(x, null, { default: withCtx(() => [createVNode(_, { type: "flex", justify: "center", style: { "margin-top": "100px" } }, { default: withCtx(() => [createVNode(u, { span: 12 }, { default: withCtx(() => [createVNode(_, null, { default: withCtx(() => [createVNode(u, { span: 16 }, { default: withCtx(() => [unref(o).data ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(o).data.list, (q, P) => (openBlock(), createBlock(w, { key: P, note: q, index: P, onLike: g }, null, 8, ["note", "index"]))), 128)) : createCommentVNode("", true), createVNode(k, { loading: unref(i), active: "" }, null, 8, ["loading"]), unref(v) ? (openBlock(), createBlock("div", { key: 1, style: { "text-align": "center" } }, "\u6CA1\u6709\u6570\u636E\u5566~~")) : createCommentVNode("", true)]), _: 1 }), createVNode(u, { span: 1 }), createVNode(u, { span: 7 }, { default: withCtx(() => [createVNode(h), createVNode(L)]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 })]), _: 1 }), createVNode("div", { id: "components-back-top-demo-custom" }, [createVNode(V, null, { default: withCtx(() => [createVNode("div", { class: "ant-back-top-inner" }, [createVNode(E)])]), _: 1 })])];
    }), _: 1 }, f));
  };
} }, jt = At.setup;
At.setup = (l, n) => {
  const e = useSSRContext();
  return (e.modules || (e.modules = /* @__PURE__ */ new Set())).add("pages/index.vue"), jt ? jt(l, n) : void 0;
};
const ha = Ea(At, [["__scopeId", "data-v-79687a53"]]);

export { ha as default };
//# sourceMappingURL=index-96e9821d.mjs.map
