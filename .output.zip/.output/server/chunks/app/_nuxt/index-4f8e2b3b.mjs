import x from '@babel/runtime/helpers/esm/defineProperty';
import v from '@babel/runtime/helpers/esm/objectSpread2';
import fe from '@babel/runtime/helpers/esm/toConsumableArray';
import { createVNode, defineComponent, reactive, getCurrentInstance, onUpdated, onUnmounted, watch, provide, computed, ref, toRef, Transition, withDirectives, vShow, Fragment, inject, watchEffect, unref, Teleport, nextTick, toRaw } from 'vue';
import ee from '@babel/runtime/helpers/esm/typeof';
import { A as AntdIcon, a as pt, p as pe, k as ke$1, y as ye$1, q as sa$1, m as ki, R as Ri, J as wo, H as Ho, U as Ur, i as it$1, _ as _i, I as Ii } from '../server.mjs';
import rn from 'lodash-es/uniq.js';
import he from '@babel/runtime/helpers/esm/objectWithoutProperties';
import { H as Hn, J as Jo, m as so, b as bt, h as Q, p as to, C as Ce, k as Xo, n as ne, Z as Zo, P as Po, o as oi, v as ni, q as qn$1, w as ft, z as Ao, U as Un, O as Oo, B as dt } from './useHttpFetch-0d93f309.mjs';
import ce from '@babel/runtime/helpers/esm/extends';
import xe from '@babel/runtime/helpers/esm/slicedToArray';
import Kt from 'lodash-es/isPlainObject.js';
import on from 'resize-observer-polyfill';

// This icon file is generated automatically.
var EllipsisOutlined$1 = { "icon": { "tag": "svg", "attrs": { "viewBox": "64 64 896 896", "focusable": "false" }, "children": [{ "tag": "path", "attrs": { "d": "M176 511a56 56 0 10112 0 56 56 0 10-112 0zm280 0a56 56 0 10112 0 56 56 0 10-112 0zm280 0a56 56 0 10112 0 56 56 0 10-112 0z" } }] }, "name": "ellipsis", "theme": "outlined" };
const EllipsisOutlinedSvg = EllipsisOutlined$1;

function _objectSpread$4(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? Object(arguments[i]) : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty$4(target, key, source[key]); }); } return target; }

function _defineProperty$4(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var EllipsisOutlined = function EllipsisOutlined(props, context) {
  var p = _objectSpread$4({}, props, context.attrs);

  return createVNode(AntdIcon, _objectSpread$4({}, p, {
    "icon": EllipsisOutlinedSvg
  }), null);
};

EllipsisOutlined.displayName = 'EllipsisOutlined';
EllipsisOutlined.inheritAttrs = false;
const Gn = EllipsisOutlined;

// This icon file is generated automatically.
var RightOutlined$1 = { "icon": { "tag": "svg", "attrs": { "viewBox": "64 64 896 896", "focusable": "false" }, "children": [{ "tag": "path", "attrs": { "d": "M765.7 486.8L314.9 134.7A7.97 7.97 0 00302 141v77.3c0 4.9 2.3 9.6 6.1 12.6l360 281.1-360 281.1c-3.9 3-6.1 7.7-6.1 12.6V883c0 6.7 7.7 10.4 12.9 6.3l450.8-352.1a31.96 31.96 0 000-50.4z" } }] }, "name": "right", "theme": "outlined" };
const RightOutlinedSvg = RightOutlined$1;

function _objectSpread$3(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? Object(arguments[i]) : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty$3(target, key, source[key]); }); } return target; }

function _defineProperty$3(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var RightOutlined = function RightOutlined(props, context) {
  var p = _objectSpread$3({}, props, context.attrs);

  return createVNode(AntdIcon, _objectSpread$3({}, p, {
    "icon": RightOutlinedSvg
  }), null);
};

RightOutlined.displayName = 'RightOutlined';
RightOutlined.inheritAttrs = false;
const Xe$1 = RightOutlined;

// This icon file is generated automatically.
var SearchOutlined$1 = { "icon": { "tag": "svg", "attrs": { "viewBox": "64 64 896 896", "focusable": "false" }, "children": [{ "tag": "path", "attrs": { "d": "M909.6 854.5L649.9 594.8C690.2 542.7 712 479 712 412c0-80.2-31.3-155.4-87.9-212.1-56.6-56.7-132-87.9-212.1-87.9s-155.5 31.3-212.1 87.9C143.2 256.5 112 331.8 112 412c0 80.1 31.3 155.5 87.9 212.1C256.5 680.8 331.8 712 412 712c67 0 130.6-21.8 182.7-62l259.7 259.6a8.2 8.2 0 0011.6 0l43.6-43.5a8.2 8.2 0 000-11.6zM570.4 570.4C528 612.7 471.8 636 412 636s-116-23.3-158.4-65.6C211.3 528 188 471.8 188 412s23.3-116.1 65.6-158.4C296 211.3 352.2 188 412 188s116.1 23.2 158.4 65.6S636 352.2 636 412s-23.3 116.1-65.6 158.4z" } }] }, "name": "search", "theme": "outlined" };
const SearchOutlinedSvg = SearchOutlined$1;

function _objectSpread$2(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? Object(arguments[i]) : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty$2(target, key, source[key]); }); } return target; }

function _defineProperty$2(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var SearchOutlined = function SearchOutlined(props, context) {
  var p = _objectSpread$2({}, props, context.attrs);

  return createVNode(AntdIcon, _objectSpread$2({}, p, {
    "icon": SearchOutlinedSvg
  }), null);
};

SearchOutlined.displayName = 'SearchOutlined';
SearchOutlined.inheritAttrs = false;
const Ot = SearchOutlined;

// This icon file is generated automatically.
var EyeOutlined$1 = { "icon": { "tag": "svg", "attrs": { "viewBox": "64 64 896 896", "focusable": "false" }, "children": [{ "tag": "path", "attrs": { "d": "M942.2 486.2C847.4 286.5 704.1 186 512 186c-192.2 0-335.4 100.5-430.2 300.3a60.3 60.3 0 000 51.5C176.6 737.5 319.9 838 512 838c192.2 0 335.4-100.5 430.2-300.3 7.7-16.2 7.7-35 0-51.5zM512 766c-161.3 0-279.4-81.8-362.7-254C232.6 339.8 350.7 258 512 258c161.3 0 279.4 81.8 362.7 254C791.5 684.2 673.4 766 512 766zm-4-430c-97.2 0-176 78.8-176 176s78.8 176 176 176 176-78.8 176-176-78.8-176-176-176zm0 288c-61.9 0-112-50.1-112-112s50.1-112 112-112 112 50.1 112 112-50.1 112-112 112z" } }] }, "name": "eye", "theme": "outlined" };
const EyeOutlinedSvg = EyeOutlined$1;

function _objectSpread$1(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? Object(arguments[i]) : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty$1(target, key, source[key]); }); } return target; }

function _defineProperty$1(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var EyeOutlined = function EyeOutlined(props, context) {
  var p = _objectSpread$1({}, props, context.attrs);

  return createVNode(AntdIcon, _objectSpread$1({}, p, {
    "icon": EyeOutlinedSvg
  }), null);
};

EyeOutlined.displayName = 'EyeOutlined';
EyeOutlined.inheritAttrs = false;
const Yt$1 = EyeOutlined;

// This icon file is generated automatically.
var EyeInvisibleOutlined$1 = { "icon": { "tag": "svg", "attrs": { "viewBox": "64 64 896 896", "focusable": "false" }, "children": [{ "tag": "path", "attrs": { "d": "M942.2 486.2Q889.47 375.11 816.7 305l-50.88 50.88C807.31 395.53 843.45 447.4 874.7 512 791.5 684.2 673.4 766 512 766q-72.67 0-133.87-22.38L323 798.75Q408 838 512 838q288.3 0 430.2-300.3a60.29 60.29 0 000-51.5zm-63.57-320.64L836 122.88a8 8 0 00-11.32 0L715.31 232.2Q624.86 186 512 186q-288.3 0-430.2 300.3a60.3 60.3 0 000 51.5q56.69 119.4 136.5 191.41L112.48 835a8 8 0 000 11.31L155.17 889a8 8 0 0011.31 0l712.15-712.12a8 8 0 000-11.32zM149.3 512C232.6 339.8 350.7 258 512 258c54.54 0 104.13 9.36 149.12 28.39l-70.3 70.3a176 176 0 00-238.13 238.13l-83.42 83.42C223.1 637.49 183.3 582.28 149.3 512zm246.7 0a112.11 112.11 0 01146.2-106.69L401.31 546.2A112 112 0 01396 512z" } }, { "tag": "path", "attrs": { "d": "M508 624c-3.46 0-6.87-.16-10.25-.47l-52.82 52.82a176.09 176.09 0 00227.42-227.42l-52.82 52.82c.31 3.38.47 6.79.47 10.25a111.94 111.94 0 01-112 112z" } }] }, "name": "eye-invisible", "theme": "outlined" };
const EyeInvisibleOutlinedSvg = EyeInvisibleOutlined$1;

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? Object(arguments[i]) : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var EyeInvisibleOutlined = function EyeInvisibleOutlined(props, context) {
  var p = _objectSpread({}, props, context.attrs);

  return createVNode(AntdIcon, _objectSpread({}, p, {
    "icon": EyeInvisibleOutlinedSvg
  }), null);
};

EyeInvisibleOutlined.displayName = 'EyeInvisibleOutlined';
EyeInvisibleOutlined.inheritAttrs = false;
const zt = EyeInvisibleOutlined;

const hn = defineComponent({ compatConfig: { MODE: 3 }, name: "ResizeObserver", props: { disabled: Boolean, onResize: Function }, emits: ["resize"], setup: function(e, t) {
  var n = t.slots, i = reactive({ width: 0, height: 0, offsetHeight: 0, offsetWidth: 0 }), l = null, u = null, r = function() {
    u && (u.disconnect(), u = null);
  }, a = function(E) {
    var s = e.onResize, x = E[0].target, f = x.getBoundingClientRect(), M = f.width, P = f.height, w = x.offsetWidth, h = x.offsetHeight, p = Math.floor(M), _ = Math.floor(P);
    if (i.width !== p || i.height !== _ || i.offsetWidth !== w || i.offsetHeight !== h) {
      var $ = { width: p, height: _, offsetWidth: w, offsetHeight: h };
      ce(i, $), s && Promise.resolve().then(function() {
        s(v(v({}, $), {}, { offsetWidth: w, offsetHeight: h }), x);
      });
    }
  }, g = getCurrentInstance(), y = function() {
    var E = e.disabled;
    if (E) {
      r();
      return;
    }
    var s = _i(g), x = s !== l;
    x && (r(), l = s), !u && s && (u = new on(a), u.observe(s));
  };
  return onUpdated(function() {
    y();
  }), onUnmounted(function() {
    r();
  }), watch(function() {
    return e.disabled;
  }, function() {
    y();
  }, { flush: "post" }), function() {
    var m;
    return (m = n.default) === null || m === void 0 ? void 0 : m.call(n)[0];
  };
} });
var R = { MAC_ENTER: 3, BACKSPACE: 8, TAB: 9, NUM_CENTER: 12, ENTER: 13, SHIFT: 16, CTRL: 17, ALT: 18, PAUSE: 19, CAPS_LOCK: 20, ESC: 27, SPACE: 32, PAGE_UP: 33, PAGE_DOWN: 34, END: 35, HOME: 36, LEFT: 37, UP: 38, RIGHT: 39, DOWN: 40, PRINT_SCREEN: 44, INSERT: 45, DELETE: 46, ZERO: 48, ONE: 49, TWO: 50, THREE: 51, FOUR: 52, FIVE: 53, SIX: 54, SEVEN: 55, EIGHT: 56, NINE: 57, QUESTION_MARK: 63, A: 65, B: 66, C: 67, D: 68, E: 69, F: 70, G: 71, H: 72, I: 73, J: 74, K: 75, L: 76, M: 77, N: 78, O: 79, P: 80, Q: 81, R: 82, S: 83, T: 84, U: 85, V: 86, W: 87, X: 88, Y: 89, Z: 90, META: 91, WIN_KEY_RIGHT: 92, CONTEXT_MENU: 93, NUM_ZERO: 96, NUM_ONE: 97, NUM_TWO: 98, NUM_THREE: 99, NUM_FOUR: 100, NUM_FIVE: 101, NUM_SIX: 102, NUM_SEVEN: 103, NUM_EIGHT: 104, NUM_NINE: 105, NUM_MULTIPLY: 106, NUM_PLUS: 107, NUM_MINUS: 109, NUM_PERIOD: 110, NUM_DIVISION: 111, F1: 112, F2: 113, F3: 114, F4: 115, F5: 116, F6: 117, F7: 118, F8: 119, F9: 120, F10: 121, F11: 122, F12: 123, NUMLOCK: 144, SEMICOLON: 186, DASH: 189, EQUALS: 187, COMMA: 188, PERIOD: 190, SLASH: 191, APOSTROPHE: 192, SINGLE_QUOTE: 222, OPEN_SQUARE_BRACKET: 219, BACKSLASH: 220, CLOSE_SQUARE_BRACKET: 221, WIN_KEY: 224, MAC_FF_META: 224, WIN_IME: 229, isTextModifyingKeyEvent: function(e) {
  var t = e.keyCode;
  if (e.altKey && !e.ctrlKey || e.metaKey || t >= R.F1 && t <= R.F12)
    return false;
  switch (t) {
    case R.ALT:
    case R.CAPS_LOCK:
    case R.CONTEXT_MENU:
    case R.CTRL:
    case R.DOWN:
    case R.END:
    case R.ESC:
    case R.HOME:
    case R.INSERT:
    case R.LEFT:
    case R.MAC_FF_META:
    case R.META:
    case R.NUMLOCK:
    case R.NUM_CENTER:
    case R.PAGE_DOWN:
    case R.PAGE_UP:
    case R.PAUSE:
    case R.PRINT_SCREEN:
    case R.RIGHT:
    case R.SHIFT:
    case R.UP:
    case R.WIN_KEY:
    case R.WIN_KEY_RIGHT:
      return false;
    default:
      return true;
  }
}, isCharacterKey: function(e) {
  if (e >= R.ZERO && e <= R.NINE || e >= R.NUM_ZERO && e <= R.NUM_MULTIPLY || e >= R.A && e <= R.Z || window.navigator.userAgent.indexOf("WebKit") !== -1 && e === 0)
    return true;
  switch (e) {
    case R.SPACE:
    case R.QUESTION_MARK:
    case R.NUM_PLUS:
    case R.NUM_MINUS:
    case R.NUM_PERIOD:
    case R.NUM_DIVISION:
    case R.SEMICOLON:
    case R.DASH:
    case R.EQUALS:
    case R.COMMA:
    case R.PERIOD:
    case R.SLASH:
    case R.APOSTROPHE:
    case R.SINGLE_QUOTE:
    case R.OPEN_SQUARE_BRACKET:
    case R.BACKSLASH:
    case R.CLOSE_SQUARE_BRACKET:
      return true;
    default:
      return false;
  }
} };
const Dt = R;
var Zn = Symbol("OverflowContextProviderKey"), fn = defineComponent({ compatConfig: { MODE: 3 }, name: "OverflowContextProvider", inheritAttrs: false, props: { value: { type: Object } }, setup: function(e, t) {
  var n = t.slots;
  return provide(Zn, computed(function() {
    return e.value;
  })), function() {
    var i;
    return (i = n.default) === null || i === void 0 ? void 0 : i.call(n);
  };
} }), $t = function() {
  return inject(Zn, computed(function() {
    return null;
  }));
}, Bt = ["prefixCls", "invalidate", "item", "renderItem", "responsive", "registerSize", "itemKey", "display", "order", "component"], Re = void 0;
const Xe = defineComponent({ compatConfig: { MODE: 3 }, name: "Item", props: { prefixCls: String, item: pt.any, renderItem: Function, responsive: Boolean, itemKey: { type: [String, Number] }, registerSize: Function, display: Boolean, order: Number, component: pt.any, invalidate: Boolean }, setup: function(e, t) {
  var n = t.slots, i = t.expose, l = computed(function() {
    return e.responsive && !e.display;
  }), u = ref();
  i({ itemNodeRef: u });
  function r(a) {
    e.registerSize(e.itemKey, a);
  }
  return onUnmounted(function() {
    r(null);
  }), function() {
    var a, g = e.prefixCls, y = e.invalidate, m = e.item, E = e.renderItem, s = e.responsive;
    e.registerSize, e.itemKey, e.display;
    var x = e.order, f = e.component, M = f === void 0 ? "div" : f, P = he(e, Bt), w = (a = n.default) === null || a === void 0 ? void 0 : a.call(n), h = E && m !== Re ? E(m) : w, p;
    y || (p = { opacity: l.value ? 0 : 1, height: l.value ? 0 : Re, overflowY: l.value ? "hidden" : Re, order: s ? x : Re, pointerEvents: l.value ? "none" : Re, position: l.value ? "absolute" : Re });
    var _ = {};
    return l.value && (_["aria-hidden"] = true), createVNode(hn, { disabled: !s, onResize: function(T) {
      var A = T.offsetWidth;
      r(A);
    } }, { default: function() {
      return createVNode(M, v(v(v({ class: pe(!y && g), style: p }, _), P), {}, { ref: u }), { default: function() {
        return [h];
      } });
    } });
  };
} });
var kt = ["component"], Lt = ["className"], Ut = ["class"];
const Vt = defineComponent({ compatConfig: { MODE: 3 }, name: "RawItem", inheritAttrs: false, props: { component: pt.any, title: pt.any, id: String, onMouseenter: { type: Function }, onMouseleave: { type: Function }, onClick: { type: Function }, onKeydown: { type: Function }, onFocus: { type: Function } }, setup: function(e, t) {
  var n = t.slots, i = t.attrs, l = $t();
  return function() {
    if (!l.value) {
      var u, r = e.component, a = r === void 0 ? "div" : r, g = he(e, kt);
      return createVNode(a, v(v({}, g), i), { default: function() {
        return [(u = n.default) === null || u === void 0 ? void 0 : u.call(n)];
      } });
    }
    var y = l.value, m = y.className, E = he(y, Lt), s = i.class, x = he(i, Ut);
    return createVNode(fn, { value: null }, { default: function() {
      return [createVNode(Xe, v(v(v({ class: pe(m, s) }, E), x), e), n)];
    } });
  };
} });
var jt = ["class", "style"], Xn = "responsive", Qn = "invalidate";
function Ht(o) {
  return "+ ".concat(o.length, " ...");
}
var Wt = function() {
  return { id: String, prefixCls: String, data: Array, itemKey: [String, Number, Function], itemWidth: { type: Number, default: 10 }, renderItem: Function, renderRawItem: Function, maxCount: [Number, String], renderRest: Function, renderRawRest: Function, suffix: pt.any, component: String, itemComponent: pt.any, onVisibleChange: Function, ssr: String, onMousedown: Function };
}, tn = defineComponent({ name: "Overflow", inheritAttrs: false, props: Wt(), emits: ["visibleChange"], setup: function(e, t) {
  var n = t.attrs, i = t.emit, l = t.slots, u = computed(function() {
    return e.ssr === "full";
  }), r = ref(null), a = computed(function() {
    return r.value || 0;
  }), g = ref(/* @__PURE__ */ new Map()), y = ref(0), m = ref(0), E = ref(0), s = ref(null), x = ref(null), f = computed(function() {
    return x.value === null && u.value ? Number.MAX_SAFE_INTEGER : x.value || 0;
  }), M = ref(false), P = computed(function() {
    return "".concat(e.prefixCls, "-item");
  }), w = computed(function() {
    return Math.max(y.value, m.value);
  }), h = computed(function() {
    return !!(e.data.length && e.maxCount === Xn);
  }), p = computed(function() {
    return e.maxCount === Qn;
  }), _ = computed(function() {
    return h.value || typeof e.maxCount == "number" && e.data.length > e.maxCount;
  }), $ = computed(function() {
    var c = e.data;
    return h.value ? r.value === null && u.value ? c = e.data : c = e.data.slice(0, Math.min(e.data.length, a.value / e.itemWidth)) : typeof e.maxCount == "number" && (c = e.data.slice(0, e.maxCount)), c;
  }), T = computed(function() {
    return h.value ? e.data.slice(f.value + 1) : e.data.slice($.value.length);
  }), A = function(I, N) {
    var K;
    return typeof e.itemKey == "function" ? e.itemKey(I) : (K = e.itemKey && (I == null ? void 0 : I[e.itemKey])) !== null && K !== void 0 ? K : N;
  }, O = computed(function() {
    return e.renderItem || function(c) {
      return c;
    };
  }), L = function(I, N) {
    x.value = I, N || (M.value = I < e.data.length - 1, i("visibleChange", I));
  }, j = function(I, N) {
    r.value = N.clientWidth;
  }, Y = function(I, N) {
    var K = new Map(g.value);
    N === null ? K.delete(I) : K.set(I, N), g.value = K;
  }, te = function(I, N) {
    y.value = m.value, m.value = N;
  }, le = function(I, N) {
    E.value = N;
  }, B = function(I) {
    return g.value.get(A($.value[I], I));
  };
  return watch([a, g, m, E, function() {
    return e.itemKey;
  }, $], function() {
    if (a.value && w.value && $.value) {
      var c = E.value, I = $.value.length, N = I - 1;
      if (!I) {
        L(0), s.value = null;
        return;
      }
      for (var K = 0; K < I; K += 1) {
        var V = B(K);
        if (V === void 0) {
          L(K - 1, true);
          break;
        }
        if (c += V, N === 0 && c <= a.value || K === N - 1 && c + B(N) <= a.value) {
          L(N), s.value = null;
          break;
        } else if (c + w.value > a.value) {
          L(K - 1), s.value = c - V - E.value + m.value;
          break;
        }
      }
      e.suffix && B(0) + E.value > a.value && (s.value = null);
    }
  }), function() {
    var c = M.value && !!T.value.length, I = e.itemComponent, N = e.renderRawItem, K = e.renderRawRest, V = e.renderRest, G = e.prefixCls, ee = G === void 0 ? "rc-overflow" : G, k = e.suffix, d = e.component, S = d === void 0 ? "div" : d, U = e.id, H = e.onMousedown, q = n.class, J = n.style, ne = he(n, jt), Z = {};
    s.value !== null && h.value && (Z = { position: "absolute", left: "".concat(s.value, "px"), top: 0 });
    var ae = { prefixCls: P.value, responsive: h.value, component: I, invalidate: p.value }, me = N ? function(ve, oe) {
      var ge = A(ve, oe);
      return createVNode(fn, { key: ge, value: v(v({}, ae), {}, { order: oe, item: ve, itemKey: ge, registerSize: Y, display: oe <= f.value }) }, { default: function() {
        return [N(ve, oe)];
      } });
    } : function(ve, oe) {
      var ge = A(ve, oe);
      return createVNode(Xe, v(v({}, ae), {}, { order: oe, key: ge, item: ve, renderItem: O.value, itemKey: ge, registerSize: Y, display: oe <= f.value }), null);
    }, pe$1 = function() {
      return null;
    }, Ne = { order: c ? f.value : Number.MAX_SAFE_INTEGER, className: "".concat(P.value, " ").concat(P.value, "-rest"), registerSize: te, display: c };
    if (K)
      K && (pe$1 = function() {
        return createVNode(fn, { value: v(v({}, ae), Ne) }, { default: function() {
          return [K(T.value)];
        } });
      });
    else {
      var De = V || Ht;
      pe$1 = function() {
        return createVNode(Xe, v(v({}, ae), Ne), { default: function() {
          return typeof De == "function" ? De(T.value) : De;
        } });
      };
    }
    var $e = function() {
      var oe;
      return createVNode(S, v({ id: U, class: pe(!p.value && ee, q), style: J, onMousedown: H }, ne), { default: function() {
        return [$.value.map(me), _.value ? pe$1() : null, k && createVNode(Xe, v(v({}, ae), {}, { order: f.value, class: "".concat(P.value, "-suffix"), registerSize: le, display: true, style: Z }), { default: function() {
          return k;
        } }), (oe = l.default) === null || oe === void 0 ? void 0 : oe.call(l)];
      } });
    };
    return createVNode(hn, { disabled: !h.value, onResize: j }, { default: $e });
  };
} });
tn.Item = Vt;
tn.RESPONSIVE = Xn;
tn.INVALIDATE = Qn;
const ke = tn;
var Oe = { adjustX: 1, adjustY: 1 }, Ke = [0, 0], Gt = { topLeft: { points: ["bl", "tl"], overflow: Oe, offset: [0, -4], targetOffset: Ke }, topCenter: { points: ["bc", "tc"], overflow: Oe, offset: [0, -4], targetOffset: Ke }, topRight: { points: ["br", "tr"], overflow: Oe, offset: [0, -4], targetOffset: Ke }, bottomLeft: { points: ["tl", "bl"], overflow: Oe, offset: [0, 4], targetOffset: Ke }, bottomCenter: { points: ["tc", "bc"], overflow: Oe, offset: [0, 4], targetOffset: Ke }, bottomRight: { points: ["tr", "br"], overflow: Oe, offset: [0, 4], targetOffset: Ke } };
const Yt = Gt;
var Zt = ["prefixCls", "arrow", "showAction", "overlayStyle", "trigger", "placement", "align", "getPopupContainer", "transitionName", "animation", "overlayClassName"];
const Xt = defineComponent({ compatConfig: { MODE: 3 }, props: { minOverlayWidthMatchTrigger: { type: Boolean, default: void 0 }, arrow: { type: Boolean, default: false }, prefixCls: pt.string.def("rc-dropdown"), transitionName: String, overlayClassName: pt.string.def(""), openClassName: String, animation: pt.any, align: pt.object, overlayStyle: { type: Object, default: void 0 }, placement: pt.string.def("bottomLeft"), overlay: pt.any, trigger: pt.oneOfType([pt.string, pt.arrayOf(pt.string)]).def("hover"), alignPoint: { type: Boolean, default: void 0 }, showAction: pt.array, hideAction: pt.array, getPopupContainer: Function, visible: { type: Boolean, default: void 0 }, defaultVisible: { type: Boolean, default: false }, mouseEnterDelay: pt.number.def(0.15), mouseLeaveDelay: pt.number.def(0.1) }, emits: ["visibleChange", "overlayClick"], slots: ["overlay"], setup: function(e, t) {
  var n = t.slots, i = t.emit, l = t.expose, u = ref(!!e.visible);
  watch(function() {
    return e.visible;
  }, function(x) {
    x !== void 0 && (u.value = x);
  });
  var r = ref();
  l({ triggerRef: r });
  var a = function(f) {
    e.visible === void 0 && (u.value = false), i("visibleChange", false), i("overlayClick", f);
  }, g = function(f) {
    e.visible === void 0 && (u.value = f), i("visibleChange", f);
  }, y = function() {
    var f, M = (f = n.overlay) === null || f === void 0 ? void 0 : f.call(n), P = { prefixCls: "".concat(e.prefixCls, "-menu"), onClick: a, getPopupContainer: function() {
      return r.value.getPopupDomNode();
    } };
    return createVNode(Fragment, null, [e.arrow && createVNode("div", { class: "".concat(e.prefixCls, "-arrow") }, null), Q(M, P, false)]);
  }, m = computed(function() {
    var x = e.minOverlayWidthMatchTrigger, f = x === void 0 ? !e.alignPoint : x;
    return f;
  }), E = function() {
    var f, M = (f = n.default) === null || f === void 0 ? void 0 : f.call(n);
    return u.value && M ? Q(M[0], { class: e.openClassName || "".concat(e.prefixCls, "-open") }, false) : M;
  }, s = computed(function() {
    return !e.hideAction && e.trigger.indexOf("contextmenu") !== -1 ? ["click"] : e.hideAction;
  });
  return function() {
    var x$1 = e.prefixCls, f = e.arrow, M = e.showAction, P = e.overlayStyle, w = e.trigger, h = e.placement, p = e.align, _ = e.getPopupContainer, $ = e.transitionName, T = e.animation, A = e.overlayClassName, O = he(e, Zt);
    return createVNode(Hn, v(v({}, O), {}, { prefixCls: x$1, ref: r, popupClassName: pe(A, x({}, "".concat(x$1, "-show-arrow"), f)), popupStyle: P, builtinPlacements: Yt, action: w, showAction: M, hideAction: s.value || [], popupPlacement: h, popupAlign: p, popupTransitionName: $, popupAnimation: T, popupVisible: u.value, stretch: m.value ? "minWidth" : "", onPopupVisibleChange: g, getPopupContainer: _ }), { popup: y, default: E });
  };
} });
var Qt = function() {
  return { prefixCls: String, size: { type: String } };
};
const mn = defineComponent({ compatConfig: { MODE: 3 }, name: "AButtonGroup", props: Qt(), setup: function(e, t) {
  var n = t.slots, i = ke$1("btn-group", e), l = i.prefixCls, u = i.direction, r = computed(function() {
    var a, g = e.size, y = "";
    switch (g) {
      case "large":
        y = "lg";
        break;
      case "small":
        y = "sm";
        break;
    }
    return a = {}, x(a, "".concat(l.value), true), x(a, "".concat(l.value, "-").concat(y), y), x(a, "".concat(l.value, "-rtl"), u.value === "rtl"), a;
  });
  return function() {
    var a;
    return createVNode("div", { class: r.value }, [ye$1((a = n.default) === null || a === void 0 ? void 0 : a.call(n))]);
  };
} });
Jo.Group = mn;
Jo.install = function(o) {
  return o.component(Jo.name, Jo), o.component(mn.name, mn), o;
};
var qn = function() {
  return { arrow: { type: [Boolean, Object], default: void 0 }, trigger: { type: [Array, String] }, overlay: pt.any, visible: { type: Boolean, default: void 0 }, disabled: { type: Boolean, default: void 0 }, align: { type: Object }, getPopupContainer: Function, prefixCls: String, transitionName: String, placement: String, overlayClassName: String, overlayStyle: { type: Object, default: void 0 }, forceRender: { type: Boolean, default: void 0 }, mouseEnterDelay: Number, mouseLeaveDelay: Number, openClassName: String, minOverlayWidthMatchTrigger: { type: Boolean, default: void 0 }, destroyPopupOnHide: { type: Boolean, default: void 0 }, onVisibleChange: { type: Function }, "onUpdate:visible": { type: Function } };
}, ln = so(), qt = function() {
  return v(v({}, qn()), {}, { type: ln.type, size: String, htmlType: ln.htmlType, href: String, disabled: { type: Boolean, default: void 0 }, prefixCls: String, icon: pt.any, title: String, loading: ln.loading, onClick: { type: Function } });
}, Jt = ["type", "disabled", "loading", "htmlType", "class", "overlay", "trigger", "align", "visible", "onVisibleChange", "placement", "href", "title", "icon", "mouseEnterDelay", "mouseLeaveDelay", "overlayClassName", "overlayStyle", "destroyPopupOnHide", "onClick", "onUpdate:visible"], ea = Jo.Group;
const Je = defineComponent({ compatConfig: { MODE: 3 }, name: "ADropdownButton", inheritAttrs: false, __ANT_BUTTON: true, props: bt(qt(), { trigger: "hover", placement: "bottomRight", type: "default" }), slots: ["icon", "leftButton", "rightButton", "overlay"], setup: function(e, t) {
  var n = t.slots, i = t.attrs, l = t.emit, u = function(E) {
    l("update:visible", E), l("visibleChange", E);
  }, r = ke$1("dropdown-button", e), a = r.prefixCls, g = r.direction, y = r.getPopupContainer;
  return function() {
    var m, E, s = v(v({}, e), i), x = s.type, f = x === void 0 ? "default" : x, M = s.disabled, P = s.loading, w = s.htmlType, h = s.class, p = h === void 0 ? "" : h, _ = s.overlay, $ = _ === void 0 ? (m = n.overlay) === null || m === void 0 ? void 0 : m.call(n) : _, T = s.trigger, A = s.align, O = s.visible;
    s.onVisibleChange;
    var L = s.placement, j = L === void 0 ? g.value === "rtl" ? "bottomLeft" : "bottomRight" : L, Y = s.href, te = s.title, le = s.icon, B = le === void 0 ? ((E = n.icon) === null || E === void 0 ? void 0 : E.call(n)) || createVNode(Gn, null, null) : le, c = s.mouseEnterDelay, I = s.mouseLeaveDelay, N = s.overlayClassName, K = s.overlayStyle, V = s.destroyPopupOnHide, G = s.onClick;
    s["onUpdate:visible"];
    var ee = he(s, Jt), k = { align: A, disabled: M, trigger: M ? [] : T, placement: j, getPopupContainer: y.value, onVisibleChange: u, mouseEnterDelay: c, mouseLeaveDelay: I, visible: O, overlayClassName: N, overlayStyle: K, destroyPopupOnHide: V }, d = createVNode(Jo, { type: f, disabled: M, loading: P, onClick: G, htmlType: w, href: Y, title: te }, { default: n.default }), S = createVNode(Jo, { type: f, icon: B }, null);
    return createVNode(ea, v(v({}, ee), {}, { class: pe(a.value, p) }), { default: function() {
      return [n.leftButton ? n.leftButton({ button: d }) : d, createVNode(Le, k, { default: function() {
        return [n.rightButton ? n.rightButton({ button: S }) : S];
      }, overlay: function() {
        return $;
      } })];
    } });
  };
} });
var Jn = defineComponent({ compatConfig: { MODE: 3 }, name: "ADropdown", inheritAttrs: false, props: bt(qn(), { mouseEnterDelay: 0.15, mouseLeaveDelay: 0.1, placement: "bottomLeft", trigger: "hover" }), slots: ["overlay"], setup: function(e, t) {
  var n = t.slots, i = t.attrs, l = t.emit, u = ke$1("dropdown", e), r = u.prefixCls, a = u.rootPrefixCls, g = u.direction, y = u.getPopupContainer, m = computed(function() {
    var f = e.placement, M = f === void 0 ? "" : f, P = e.transitionName;
    return P !== void 0 ? P : M.indexOf("top") >= 0 ? "".concat(a.value, "-slide-down") : "".concat(a.value, "-slide-up");
  }), E = function() {
    var M, P, w, h = e.overlay || ((M = n.overlay) === null || M === void 0 ? void 0 : M.call(n)), p = Array.isArray(h) ? h[0] : h;
    if (!p)
      return null;
    var _ = p.props || {};
    sa$1(!_.mode || _.mode === "vertical", "Dropdown", 'mode="'.concat(_.mode, `" is not supported for Dropdown's Menu.`));
    var $ = _.selectable, T = $ === void 0 ? false : $, A = _.expandIcon, O = A === void 0 ? (P = p.children) === null || P === void 0 || (w = P.expandIcon) === null || w === void 0 ? void 0 : w.call(P) : A, L = typeof O < "u" && Ii(O) ? O : createVNode("span", { class: "".concat(r.value, "-menu-submenu-arrow") }, [createVNode(Xe$1, { class: "".concat(r.value, "-menu-submenu-arrow-icon") }, null)]), j = Ii(p) ? Q(p, { mode: "vertical", selectable: T, expandIcon: function() {
      return L;
    } }) : p;
    return j;
  }, s = computed(function() {
    var f = e.placement;
    if (!f)
      return g.value === "rtl" ? "bottomRight" : "bottomLeft";
    if (f.includes("Center")) {
      var M = f.slice(0, f.indexOf("Center"));
      return sa$1(!f.includes("Center"), "Dropdown", "You are using '".concat(f, "' placement in Dropdown, which is deprecated. Try to use '").concat(M, "' instead.")), M;
    }
    return f;
  }), x$1 = function(M) {
    l("update:visible", M), l("visibleChange", M);
  };
  return function() {
    var f, M, P = e.arrow, w = e.trigger, h = e.disabled, p = e.overlayClassName, _ = (f = n.default) === null || f === void 0 ? void 0 : f.call(n)[0], $ = Q(_, ce({ class: pe(_ == null || (M = _.props) === null || M === void 0 ? void 0 : M.class, x({}, "".concat(r.value, "-rtl"), g.value === "rtl"), "".concat(r.value, "-trigger")) }, h ? { disabled: h } : {})), T = pe(p, x({}, "".concat(r.value, "-rtl"), g.value === "rtl")), A = h ? [] : w, O;
    A && A.indexOf("contextmenu") !== -1 && (O = true);
    var L = to({ arrowPointAtCenter: ee(P) === "object" && P.pointAtCenter, autoAdjustOverflow: true }), j = Ce(v(v(v({}, e), i), {}, { builtinPlacements: L, overlayClassName: T, arrow: P, alignPoint: O, prefixCls: r.value, getPopupContainer: y.value, transitionName: m.value, trigger: A, onVisibleChange: x$1, placement: s.value }), ["overlay", "onUpdate:visible"]);
    return createVNode(Xt, j, { default: function() {
      return [$];
    }, overlay: E });
  };
} });
Jn.Button = Je;
const Le = Jn;
function na(o, e, t, n) {
  var i = t ? t.call(n, o, e) : void 0;
  if (i !== void 0)
    return !!i;
  if (o === e)
    return true;
  if (ee(o) !== "object" || !o || ee(e) !== "object" || !e)
    return false;
  var l = Object.keys(o), u = Object.keys(e);
  if (l.length !== u.length)
    return false;
  for (var r = Object.prototype.hasOwnProperty.bind(e), a = 0; a < l.length; a++) {
    var g = l[a];
    if (!r(g))
      return false;
    var y = o[g], m = e[g];
    if (i = t ? t.call(n, y, m, g) : void 0, i === false || i === void 0 && y !== m)
      return false;
  }
  return true;
}
function Be(o, e, t, n) {
  return na(toRaw(o), toRaw(e), t, n);
}
var et = Symbol("menuContextKey"), nt = function(e) {
  provide(et, e);
}, Pe = function() {
  return inject(et);
}, tt = Symbol("ForceRenderKey"), ta = function(e) {
  provide(tt, e);
}, at = function() {
  return inject(tt, false);
}, rt = Symbol("menuFirstLevelContextKey"), it = function(e) {
  provide(rt, e);
}, aa = function() {
  return inject(rt, true);
}, en = defineComponent({ compatConfig: { MODE: 3 }, name: "MenuContextProvider", inheritAttrs: false, props: { mode: { type: String, default: void 0 }, overflowDisabled: { type: Boolean, default: void 0 }, isRootMenu: { type: Boolean, default: void 0 } }, setup: function(e, t) {
  var n = t.slots, i = Pe(), l = v({}, i);
  return e.mode !== void 0 && (l.mode = toRef(e, "mode")), e.isRootMenu !== void 0 && (l.isRootMenu = toRef(e, "isRootMenu")), e.overflowDisabled !== void 0 && (l.overflowDisabled = toRef(e, "overflowDisabled")), nt(l), function() {
    var u;
    return (u = n.default) === null || u === void 0 ? void 0 : u.call(n);
  };
} });
const ra = nt;
var ia = Symbol("siderCollapsed"), or = Symbol("siderHookProvider"), Ge = "$$__vc-menu-more__key", ot = Symbol("KeyPathContext"), bn = function() {
  return inject(ot, { parentEventKeys: computed(function() {
    return [];
  }), parentKeys: computed(function() {
    return [];
  }), parentInfo: {} });
}, oa = function(e, t, n) {
  var i = bn(), l = i.parentEventKeys, u = i.parentKeys, r = computed(function() {
    return [].concat(fe(l.value), [e]);
  }), a = computed(function() {
    return [].concat(fe(u.value), [t]);
  });
  return provide(ot, { parentEventKeys: r, parentKeys: a, parentInfo: n }), a;
}, lt = Symbol("measure"), Pn = defineComponent({ compatConfig: { MODE: 3 }, setup: function(e, t) {
  var n = t.slots;
  return provide(lt, true), function() {
    var i;
    return (i = n.default) === null || i === void 0 ? void 0 : i.call(n);
  };
} }), Cn = function() {
  return inject(lt, false);
};
const la = oa;
function ut(o) {
  var e = Pe(), t = e.mode, n = e.rtl, i = e.inlineIndent;
  return computed(function() {
    return t.value !== "inline" ? null : n.value ? { paddingRight: "".concat(o.value * i.value, "px") } : { paddingLeft: "".concat(o.value * i.value, "px") };
  });
}
var ua = 0, sa = function() {
  return { id: String, role: String, disabled: Boolean, danger: Boolean, title: { type: [String, Boolean], default: void 0 }, icon: pt.any, onMouseenter: Function, onMouseleave: Function, onClick: Function, onKeydown: Function, onFocus: Function };
};
const nn = defineComponent({ compatConfig: { MODE: 3 }, name: "AMenuItem", inheritAttrs: false, props: sa(), slots: ["icon", "title"], setup: function(e, t) {
  var n = t.slots, i = t.emit, l = t.attrs, u = getCurrentInstance(), r = Cn(), a = ee(u.vnode.key) === "symbol" ? String(u.vnode.key) : u.vnode.key;
  sa$1(ee(u.vnode.key) !== "symbol", "MenuItem", 'MenuItem `:key="'.concat(String(a), '"` not support Symbol type'));
  var g = "menu_item_".concat(++ua, "_$$_").concat(a), y = bn(), m = y.parentEventKeys, E = y.parentKeys, s = Pe(), x$1 = s.prefixCls, f = s.activeKeys, M = s.disabled, P = s.changeActiveKeys, w = s.rtl, h = s.inlineCollapsed, p = s.siderCollapsed, _ = s.onItemClick, $ = s.selectedKeys, T = s.registerMenuInfo;
  s.unRegisterMenuInfo;
  var A = aa(), O = ref(false), L = computed(function() {
    return [].concat(fe(E.value), [a]);
  }), j = { eventKey: g, key: a, parentEventKeys: m, parentKeys: E, isLeaf: true };
  T(g, j), watch(f, function() {
    O.value = !!f.value.find(function(k) {
      return k === a;
    });
  }, { immediate: true });
  var Y = computed(function() {
    return M.value || e.disabled;
  }), te = computed(function() {
    return $.value.includes(a);
  }), le = computed(function() {
    var k, d = "".concat(x$1.value, "-item");
    return k = {}, x(k, "".concat(d), true), x(k, "".concat(d, "-danger"), e.danger), x(k, "".concat(d, "-active"), O.value), x(k, "".concat(d, "-selected"), te.value), x(k, "".concat(d, "-disabled"), Y.value), k;
  }), B = function(d) {
    return { key: a, eventKey: g, keyPath: L.value, eventKeyPath: [].concat(fe(m.value), [g]), domEvent: d, item: v(v({}, e), l) };
  }, c = function(d) {
    if (!Y.value) {
      var S = B(d);
      i("click", d), _(S);
    }
  }, I = function(d) {
    Y.value || (P(L.value), i("mouseenter", d));
  }, N = function(d) {
    Y.value || (P([]), i("mouseleave", d));
  }, K = function(d) {
    if (i("keydown", d), d.which === Dt.ENTER) {
      var S = B(d);
      i("click", d), _(S);
    }
  }, V = function(d) {
    P(L.value), i("focus", d);
  }, G = function(d, S) {
    var U = createVNode("span", { class: "".concat(x$1.value, "-title-content") }, [S]);
    return (!d || Ii(S) && S.type === "span") && S && h.value && A && typeof S == "string" ? createVNode("div", { class: "".concat(x$1.value, "-inline-collapsed-noicon") }, [S.charAt(0)]) : U;
  }, ee$1 = ut(computed(function() {
    return L.value.length;
  }));
  return function() {
    var k, d, S, U;
    if (r)
      return null;
    var H = (k = e.title) !== null && k !== void 0 ? k : (d = n.title) === null || d === void 0 ? void 0 : d.call(n), q = ye$1((S = n.default) === null || S === void 0 ? void 0 : S.call(n)), J = q.length, ne = H;
    typeof H > "u" ? ne = A && J ? q : "" : H === false && (ne = "");
    var Z = { title: ne };
    !p.value && !h.value && (Z.title = null, Z.visible = false);
    var ae = {};
    e.role === "option" && (ae["aria-selected"] = te.value);
    var me = ki(n, e, "icon");
    return createVNode(Xo, v(v({}, Z), {}, { placement: w.value ? "left" : "right", overlayClassName: "".concat(x$1.value, "-inline-collapsed-tooltip") }), { default: function() {
      return [createVNode(ke.Item, v(v(v({ component: "li" }, l), {}, { id: e.id, style: v(v({}, l.style || {}), ee$1.value), class: [le.value, (U = {}, x(U, "".concat(l.class), !!l.class), x(U, "".concat(x$1.value, "-item-only-child"), (me ? J + 1 : J) === 1), U)], role: e.role || "menuitem", tabindex: e.disabled ? null : -1, "data-menu-id": a, "aria-disabled": e.disabled }, ae), {}, { onMouseenter: I, onMouseleave: N, onClick: c, onKeydown: K, onFocus: V, title: typeof H == "string" ? H : void 0 }), { default: function() {
        return [Q(me, { class: "".concat(x$1.value, "-item-icon") }, false), G(me, q)];
      } })];
    } });
  };
} });
var Me = { adjustX: 1, adjustY: 1 }, va = { topLeft: { points: ["bl", "tl"], overflow: Me, offset: [0, -7] }, bottomLeft: { points: ["tl", "bl"], overflow: Me, offset: [0, 7] }, leftTop: { points: ["tr", "tl"], overflow: Me, offset: [-4, 0] }, rightTop: { points: ["tl", "tr"], overflow: Me, offset: [4, 0] } }, ca = { topLeft: { points: ["bl", "tl"], overflow: Me, offset: [0, -7] }, bottomLeft: { points: ["tl", "bl"], overflow: Me, offset: [0, 7] }, rightTop: { points: ["tr", "tl"], overflow: Me, offset: [-4, 0] }, leftTop: { points: ["tl", "tr"], overflow: Me, offset: [4, 0] } }, da = { horizontal: "bottomLeft", vertical: "rightTop", "vertical-left": "rightTop", "vertical-right": "leftTop" };
const En = defineComponent({ compatConfig: { MODE: 3 }, name: "PopupTrigger", inheritAttrs: false, props: { prefixCls: String, mode: String, visible: Boolean, popupClassName: String, popupOffset: Array, disabled: Boolean, onVisibleChange: Function }, slots: ["popup"], emits: ["visibleChange"], setup: function(e, t) {
  var n = t.slots, i = t.emit, l = ref(false), u = Pe(), r = u.getPopupContainer, a = u.rtl, g = u.subMenuOpenDelay, y = u.subMenuCloseDelay, m = u.builtinPlacements, E = u.triggerSubMenuAction, s = u.isRootMenu, x$1 = u.forceSubMenuRender, f = u.motion, M = u.defaultMotions, P = at(), w = computed(function() {
    return a.value ? v(v({}, ca), m.value) : v(v({}, va), m.value);
  }), h = computed(function() {
    return da[e.mode];
  }), p = ref();
  watch(function() {
    return e.visible;
  }, function(T) {
    ne.cancel(p.value), p.value = ne(function() {
      l.value = T;
    });
  }, { immediate: true });
  var _ = function(A) {
    i("visibleChange", A);
  }, $ = computed(function() {
    var T, A, O = f.value || ((T = M.value) === null || T === void 0 ? void 0 : T[e.mode]) || ((A = M.value) === null || A === void 0 ? void 0 : A.other), L = typeof O == "function" ? O() : O;
    return L ? Ri(L.name, { css: true }) : void 0;
  });
  return function() {
    var T = e.prefixCls, A = e.popupClassName, O = e.mode, L = e.popupOffset, j = e.disabled;
    return createVNode(Hn, { prefixCls: T, popupClassName: pe("".concat(T, "-popup"), x({}, "".concat(T, "-rtl"), a.value), A), stretch: O === "horizontal" ? "minWidth" : null, getPopupContainer: s.value ? r.value : function(Y) {
      return Y.parentNode;
    }, builtinPlacements: w.value, popupPlacement: h.value, popupVisible: l.value, popupAlign: L && { offset: L }, action: j ? [] : [E.value], mouseEnterDelay: g.value, mouseLeaveDelay: y.value, onPopupVisibleChange: _, forceRender: P || x$1.value, popupAnimation: $.value }, { popup: n.popup, default: n.default });
  };
} });
var st = function(e, t) {
  var n, i = t.slots, l = t.attrs, u = Pe(), r = u.prefixCls, a = u.mode;
  return createVNode("ul", v(v({}, l), {}, { class: pe(r.value, "".concat(r.value, "-sub"), "".concat(r.value, "-").concat(a.value === "inline" ? "inline" : "vertical")), "data-menu-list": true }), [(n = i.default) === null || n === void 0 ? void 0 : n.call(i)]);
};
st.displayName = "SubMenuList";
const vt = st, fa = defineComponent({ compatConfig: { MODE: 3 }, name: "InlineSubMenuList", inheritAttrs: false, props: { id: String, open: Boolean, keyPath: Array }, setup: function(e, t) {
  var n = t.slots, i = computed(function() {
    return "inline";
  }), l = Pe(), u = l.motion, r = l.mode, a = l.defaultMotions, g = computed(function() {
    return r.value === i.value;
  }), y = ref(!g.value), m = computed(function() {
    return g.value ? e.open : false;
  });
  watch(r, function() {
    g.value && (y.value = false);
  }, { flush: "post" });
  var E = computed(function() {
    var s, x, f = u.value || ((s = a.value) === null || s === void 0 ? void 0 : s[i.value]) || ((x = a.value) === null || x === void 0 ? void 0 : x.other), M = typeof f == "function" ? f() : f;
    return v(v({}, M), {}, { appear: e.keyPath.length <= 1 });
  });
  return function() {
    var s;
    return y.value ? null : createVNode(en, { mode: i.value }, { default: function() {
      return [createVNode(Transition, E.value, { default: function() {
        return [withDirectives(createVNode(vt, { id: e.id }, { default: function() {
          return [(s = n.default) === null || s === void 0 ? void 0 : s.call(n)];
        } }), [[vShow, m.value]])];
      } })];
    } });
  };
} });
var wn = 0, ma = function() {
  return { icon: pt.any, title: pt.any, disabled: Boolean, level: Number, popupClassName: String, popupOffset: Array, internalPopupClose: Boolean, eventKey: String, expandIcon: Function, onMouseenter: Function, onMouseleave: Function, onTitleClick: Function };
};
const Ve = defineComponent({ compatConfig: { MODE: 3 }, name: "ASubMenu", inheritAttrs: false, props: ma(), slots: ["icon", "title", "expandIcon"], setup: function(e, t) {
  var n, i, l = t.slots, u = t.attrs, r = t.emit;
  it(false);
  var a = Cn(), g = getCurrentInstance(), y = ee(g.vnode.key) === "symbol" ? String(g.vnode.key) : g.vnode.key;
  sa$1(ee(g.vnode.key) !== "symbol", "SubMenu", 'SubMenu `:key="'.concat(String(y), '"` not support Symbol type'));
  var m = wo(y) ? y : "sub_menu_".concat(++wn, "_$$_not_set_key"), E = (n = e.eventKey) !== null && n !== void 0 ? n : wo(y) ? "sub_menu_".concat(++wn, "_$$_").concat(y) : m, s = bn(), x$1 = s.parentEventKeys, f = s.parentInfo, M = s.parentKeys, P = computed(function() {
    return [].concat(fe(M.value), [m]);
  }), w = ref([]), h = { eventKey: E, key: m, parentEventKeys: x$1, childrenEventKeys: w, parentKeys: M };
  (i = f.childrenEventKeys) === null || i === void 0 || i.value.push(E), la(E, m, h);
  var p = Pe(), _ = p.prefixCls, $ = p.activeKeys, T = p.disabled, A = p.changeActiveKeys, O = p.mode, L = p.inlineCollapsed, j = p.antdMenuTheme, Y = p.openKeys, te = p.overflowDisabled, le = p.onOpenChange, B = p.registerMenuInfo;
  p.unRegisterMenuInfo;
  var c = p.selectedSubMenuKeys, I = p.expandIcon, N = y != null, K = !a && (at() || !N);
  ta(K), (a && N || !a && !N || K) && B(E, h);
  var V = computed(function() {
    return "".concat(_.value, "-submenu");
  }), G = computed(function() {
    return T.value || e.disabled;
  }), ee$1 = ref(), k = ref(), d = computed(function() {
    return Y.value.includes(m);
  }), S = computed(function() {
    return !te.value && d.value;
  }), U = computed(function() {
    return c.value.includes(m);
  }), H = ref(false);
  watch($, function() {
    H.value = !!$.value.find(function(re) {
      return re === m;
    });
  }, { immediate: true });
  var q = function(X) {
    G.value || (r("titleClick", X, m), O.value === "inline" && le(m, !d.value));
  }, J = function(X) {
    G.value || (A(P.value), r("mouseenter", X));
  }, ne = function(X) {
    G.value || (A([]), r("mouseleave", X));
  }, Z = ut(computed(function() {
    return P.value.length;
  })), ae = function(X) {
    O.value !== "inline" && le(m, X);
  }, me = function() {
    A(P.value);
  }, pe$1 = E && "".concat(E, "-popup"), Ne = computed(function() {
    return pe(_.value, "".concat(_.value, "-").concat(j.value), e.popupClassName);
  }), De = function(X, ce) {
    if (!ce)
      return L.value && !M.value.length && X && typeof X == "string" ? createVNode("div", { class: "".concat(_.value, "-inline-collapsed-noicon") }, [X.charAt(0)]) : createVNode("span", { class: "".concat(_.value, "-title-content") }, [X]);
    var Se = Ii(X) && X.type === "span";
    return createVNode(Fragment, null, [Q(ce, { class: "".concat(_.value, "-item-icon") }, false), Se ? X : createVNode("span", { class: "".concat(_.value, "-title-content") }, [X])]);
  }, $e = computed(function() {
    return O.value !== "inline" && P.value.length > 1 ? "vertical" : O.value;
  }), ve = computed(function() {
    return O.value === "horizontal" ? "vertical" : O.value;
  }), oe = computed(function() {
    return $e.value === "horizontal" ? "vertical" : $e.value;
  }), ge = function() {
    var X = V.value, ce = ki(l, e, "icon"), Se = e.expandIcon || l.expandIcon || I.value, Ee = De(ki(l, e, "title"), ce);
    return createVNode("div", { style: Z.value, class: "".concat(X, "-title"), tabindex: G.value ? null : -1, ref: ee$1, title: typeof Ee == "string" ? Ee : null, "data-menu-id": m, "aria-expanded": S.value, "aria-haspopup": true, "aria-controls": pe$1, "aria-disabled": G.value, onClick: q, onFocus: me }, [Ee, O.value !== "horizontal" && Se ? Se(v(v({}, e), {}, { isOpen: S.value })) : createVNode("i", { class: "".concat(X, "-arrow") }, null)]);
  };
  return function() {
    var re;
    if (a) {
      var X;
      return N ? (X = l.default) === null || X === void 0 ? void 0 : X.call(l) : null;
    }
    var ce = V.value, Se = function() {
      return null;
    };
    return !te.value && O.value !== "inline" ? Se = function() {
      return createVNode(En, { mode: $e.value, prefixCls: ce, visible: !e.internalPopupClose && S.value, popupClassName: Ne.value, popupOffset: e.popupOffset, disabled: G.value, onVisibleChange: ae }, { default: function() {
        return [ge()];
      }, popup: function() {
        return createVNode(en, { mode: oe.value, isRootMenu: false }, { default: function() {
          return [createVNode(vt, { id: pe$1, ref: k }, { default: l.default })];
        } });
      } });
    } : Se = function() {
      return createVNode(En, null, { default: ge });
    }, createVNode(en, { mode: ve.value }, { default: function() {
      return [createVNode(ke.Item, v(v({ component: "li" }, u), {}, { role: "none", class: pe(ce, "".concat(ce, "-").concat(O.value), u.class, (re = {}, x(re, "".concat(ce, "-open"), S.value), x(re, "".concat(ce, "-active"), H.value), x(re, "".concat(ce, "-selected"), U.value), x(re, "".concat(ce, "-disabled"), G.value), re)), onMouseenter: J, onMouseleave: ne, "data-submenu-id": m }), { default: function() {
        return createVNode(Fragment, null, [Se(), !te.value && createVNode(fa, { id: pe$1, open: S.value, keyPath: P.value }, { default: l.default })]);
      } })];
    } });
  };
} });
var pa = function() {
  return { id: String, prefixCls: String, disabled: Boolean, inlineCollapsed: Boolean, disabledOverflow: Boolean, forceSubMenuRender: Boolean, openKeys: Array, selectedKeys: Array, activeKey: String, selectable: { type: Boolean, default: true }, multiple: { type: Boolean, default: false }, motion: Object, theme: { type: String, default: "light" }, mode: { type: String, default: "vertical" }, inlineIndent: { type: Number, default: 24 }, subMenuOpenDelay: { type: Number, default: 0.1 }, subMenuCloseDelay: { type: Number, default: 0.1 }, builtinPlacements: { type: Object }, triggerSubMenuAction: { type: String, default: "hover" }, getPopupContainer: Function, expandIcon: Function, onOpenChange: Function, onSelect: Function, onDeselect: Function, onClick: [Function, Array], onFocus: Function, onBlur: Function, onMousedown: Function, "onUpdate:openKeys": Function, "onUpdate:selectedKeys": Function, "onUpdate:activeKey": Function };
}, _n = [];
const _e = defineComponent({ compatConfig: { MODE: 3 }, name: "AMenu", inheritAttrs: false, props: pa(), slots: ["expandIcon", "overflowedIndicator"], setup: function(e, t) {
  var n = t.slots, i = t.emit, l = t.attrs, u = ke$1("menu", e), r = u.prefixCls, a = u.direction, g = u.getPrefixCls, y = ref({}), m = inject(ia, ref(void 0)), E = computed(function() {
    return m.value !== void 0 ? m.value : e.inlineCollapsed;
  }), s = ref(false);
  watchEffect(function() {
    sa$1(!(e.inlineCollapsed === true && e.mode !== "inline"), "Menu", "`inlineCollapsed` should only be used when `mode` is inline."), sa$1(!(m.value !== void 0 && e.inlineCollapsed === true), "Menu", "`inlineCollapsed` not control Menu under Sider. Should set `collapsed` on Sider instead.");
  });
  var x$1 = ref([]), f = ref([]), M = ref({});
  watch(y, function() {
    for (var d = {}, S = 0, U = Object.values(y.value); S < U.length; S++) {
      var H = U[S];
      d[H.key] = H;
    }
    M.value = d;
  }, { flush: "post" }), watchEffect(function() {
    if (e.activeKey !== void 0) {
      var d = [], S = e.activeKey ? M.value[e.activeKey] : void 0;
      S && e.activeKey !== void 0 ? d = rn([].concat(unref(S.parentKeys), e.activeKey)) : d = [], Be(x$1.value, d) || (x$1.value = d);
    }
  }), watch(function() {
    return e.selectedKeys;
  }, function(d) {
    d && (f.value = d.slice());
  }, { immediate: true, deep: true });
  var P = ref([]);
  watch([M, f], function() {
    var d = [];
    f.value.forEach(function(S) {
      var U = M.value[S];
      U && (d = d.concat(unref(U.parentKeys)));
    }), d = rn(d), Be(P.value, d) || (P.value = d);
  }, { immediate: true });
  var w = function(S) {
    if (e.selectable) {
      var U = S.key, H = f.value.includes(U), q;
      e.multiple ? H ? q = f.value.filter(function(ne) {
        return ne !== U;
      }) : q = [].concat(fe(f.value), [U]) : q = [U];
      var J = v(v({}, S), {}, { selectedKeys: q });
      Be(q, f.value) || (e.selectedKeys === void 0 && (f.value = q), i("update:selectedKeys", q), H && e.multiple ? i("deselect", J) : i("select", J)), A.value !== "inline" && !e.multiple && h.value.length && j(_n);
    }
  }, h = ref([]);
  watch(function() {
    return e.openKeys;
  }, function() {
    var d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : h.value;
    Be(h.value, d) || (h.value = d.slice());
  }, { immediate: true, deep: true });
  var p, _ = function(S) {
    clearTimeout(p), p = setTimeout(function() {
      e.activeKey === void 0 && (x$1.value = S), i("update:activeKey", S[S.length - 1]);
    });
  }, $ = computed(function() {
    return !!e.disabled;
  }), T = computed(function() {
    return a.value === "rtl";
  }), A = ref("vertical"), O = ref(false);
  watchEffect(function() {
    (e.mode === "inline" || e.mode === "vertical") && E.value ? (A.value = "vertical", O.value = E.value) : (A.value = e.mode, O.value = false);
  });
  var L = computed(function() {
    return A.value === "inline";
  }), j = function(S) {
    h.value = S, i("update:openKeys", S), i("openChange", S);
  }, Y = ref(h.value), te = ref(false);
  watch(h, function() {
    L.value && (Y.value = h.value);
  }, { immediate: true }), watch(L, function() {
    if (!te.value) {
      te.value = true;
      return;
    }
    L.value ? h.value = Y.value : j(_n);
  }, { immediate: true });
  var le = computed(function() {
    var d;
    return d = {}, x(d, "".concat(r.value), true), x(d, "".concat(r.value, "-root"), true), x(d, "".concat(r.value, "-").concat(A.value), true), x(d, "".concat(r.value, "-inline-collapsed"), O.value), x(d, "".concat(r.value, "-rtl"), T.value), x(d, "".concat(r.value, "-").concat(e.theme), true), d;
  }), B = computed(function() {
    return g();
  }), c = computed(function() {
    return { horizontal: { name: "".concat(B.value, "-slide-up") }, inline: Zo, other: { name: "".concat(B.value, "-zoom-big") } };
  });
  it(true);
  var I = function d() {
    var S = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], U = [], H = y.value;
    return S.forEach(function(q) {
      var J = H[q], ne = J.key, Z = J.childrenEventKeys;
      U.push.apply(U, [ne].concat(fe(d(unref(Z)))));
    }), U;
  }, N = function(S) {
    i("click", S), w(S);
  }, K = function(S, U) {
    var H, q = ((H = M.value[S]) === null || H === void 0 ? void 0 : H.childrenEventKeys) || [], J = h.value.filter(function(Z) {
      return Z !== S;
    });
    if (U)
      J.push(S);
    else if (A.value !== "inline") {
      var ne = I(unref(q));
      J = rn(J.filter(function(Z) {
        return !ne.includes(Z);
      }));
    }
    Be(h, J) || j(J);
  }, V = function(S, U) {
    y.value = v(v({}, y.value), {}, x({}, S, U));
  }, G = function(S) {
    delete y.value[S], y.value = v({}, y.value);
  }, ee = ref(0), k = computed(function() {
    return e.expandIcon || n.expandIcon ? function(d) {
      var S = e.expandIcon || n.expandIcon;
      return S = typeof S == "function" ? S(d) : S, Q(S, { class: "".concat(r.value, "-submenu-expand-icon") }, false);
    } : null;
  });
  return ra({ store: y, prefixCls: r, activeKeys: x$1, openKeys: h, selectedKeys: f, changeActiveKeys: _, disabled: $, rtl: T, mode: A, inlineIndent: computed(function() {
    return e.inlineIndent;
  }), subMenuCloseDelay: computed(function() {
    return e.subMenuCloseDelay;
  }), subMenuOpenDelay: computed(function() {
    return e.subMenuOpenDelay;
  }), builtinPlacements: computed(function() {
    return e.builtinPlacements;
  }), triggerSubMenuAction: computed(function() {
    return e.triggerSubMenuAction;
  }), getPopupContainer: computed(function() {
    return e.getPopupContainer;
  }), inlineCollapsed: O, antdMenuTheme: computed(function() {
    return e.theme;
  }), siderCollapsed: m, defaultMotions: computed(function() {
    return s.value ? c.value : null;
  }), motion: computed(function() {
    return s.value ? e.motion : null;
  }), overflowDisabled: ref(void 0), onOpenChange: K, onItemClick: N, registerMenuInfo: V, unRegisterMenuInfo: G, selectedSubMenuKeys: P, isRootMenu: ref(true), expandIcon: k, forceSubMenuRender: computed(function() {
    return e.forceSubMenuRender;
  }) }), function() {
    var d, S, U = ye$1((d = n.default) === null || d === void 0 ? void 0 : d.call(n)), H = ee.value >= U.length - 1 || A.value !== "horizontal" || e.disabledOverflow, q = A.value !== "horizontal" || e.disabledOverflow ? U : U.map(function(ne, Z) {
      return createVNode(en, { key: ne.key, overflowDisabled: Z > ee.value }, { default: function() {
        return ne;
      } });
    }), J = ((S = n.overflowedIndicator) === null || S === void 0 ? void 0 : S.call(n)) || createVNode(Gn, null, null);
    return createVNode(ke, v(v({}, l), {}, { onMousedown: e.onMousedown, prefixCls: "".concat(r.value, "-overflow"), component: "ul", itemComponent: nn, class: [le.value, l.class], role: "menu", id: e.id, data: q, renderRawItem: function(Z) {
      return Z;
    }, renderRawRest: function(Z) {
      var ae = Z.length, me = ae ? U.slice(-ae) : null;
      return createVNode(Fragment, null, [createVNode(Ve, { eventKey: Ge, key: Ge, title: J, disabled: H, internalPopupClose: ae === 0 }, { default: function() {
        return me;
      } }), createVNode(Pn, null, { default: function() {
        return [createVNode(Ve, { eventKey: Ge, key: Ge, title: J, disabled: H, internalPopupClose: ae === 0 }, { default: function() {
          return me;
        } })];
      } })]);
    }, maxCount: A.value !== "horizontal" || e.disabledOverflow ? ke.INVALIDATE : ke.RESPONSIVE, ssr: "full", "data-menu-list": true, onVisibleChange: function(Z) {
      ee.value = Z;
    } }), { default: function() {
      return [createVNode(Teleport, { to: "body" }, { default: function() {
        return [createVNode("div", { style: { display: "none" }, "aria-hidden": true }, [createVNode(Pn, null, { default: function() {
          return [q];
        } })])];
      } })];
    } });
  };
} });
var ga = function() {
  return { title: pt.any };
};
const pn = defineComponent({ compatConfig: { MODE: 3 }, name: "AMenuItemGroup", inheritAttrs: false, props: ga(), slots: ["title"], setup: function(e, t) {
  var n = t.slots, i = t.attrs, l = Pe(), u = l.prefixCls, r = computed(function() {
    return "".concat(u.value, "-item-group");
  }), a = Cn();
  return function() {
    var g, y;
    return a ? (g = n.default) === null || g === void 0 ? void 0 : g.call(n) : createVNode("li", v(v({}, i), {}, { onClick: function(E) {
      return E.stopPropagation();
    }, class: r.value }), [createVNode("div", { title: typeof e.title == "string" ? e.title : void 0, class: "".concat(r.value, "-title") }, [ki(n, e, "title")]), createVNode("ul", { class: "".concat(r.value, "-list") }, [(y = n.default) === null || y === void 0 ? void 0 : y.call(n)])]);
  };
} });
var ya = function() {
  return { prefixCls: String, dashed: Boolean };
};
const gn = defineComponent({ compatConfig: { MODE: 3 }, name: "AMenuDivider", props: ya(), setup: function(e) {
  var t = ke$1("menu", e), n = t.prefixCls, i = computed(function() {
    var l;
    return l = {}, x(l, "".concat(n.value, "-item-divider"), true), x(l, "".concat(n.value, "-item-divider-dashed"), !!e.dashed), l;
  });
  return function() {
    return createVNode("li", { class: i.value }, null);
  };
} });
_e.install = function(o) {
  return o.component(_e.name, _e), o.component(nn.name, nn), o.component(Ve.name, Ve), o.component(gn.name, gn), o.component(pn.name, pn), o;
};
_e.Item = nn;
_e.Divider = gn;
_e.SubMenu = Ve;
_e.ItemGroup = pn;
Le.Button = Je;
Le.install = function(o) {
  return o.component(Le.name, Le), o.component(Je.name, Je), o;
};
const ha = defineComponent({ compatConfig: { MODE: 3 }, name: "AInputGroup", props: { prefixCls: String, size: { type: String }, compact: { type: Boolean, default: void 0 }, onMouseenter: { type: Function }, onMouseleave: { type: Function }, onFocus: { type: Function }, onBlur: { type: Function } }, setup: function(e, t) {
  var n = t.slots, i = ke$1("input-group", e), l = i.prefixCls, u = i.direction, r = computed(function() {
    var a, g = l.value;
    return a = {}, x(a, "".concat(g), true), x(a, "".concat(g, "-lg"), e.size === "large"), x(a, "".concat(g, "-sm"), e.size === "small"), x(a, "".concat(g, "-compact"), e.compact), x(a, "".concat(g, "-rtl"), u.value === "rtl"), a;
  });
  return function() {
    var a;
    return createVNode("span", { class: r.value, onMouseenter: e.onMouseenter, onMouseleave: e.onMouseleave, onFocus: e.onFocus, onBlur: e.onBlur }, [(a = n.default) === null || a === void 0 ? void 0 : a.call(n)]);
  };
} });
var un = /iPhone/i, An = /iPod/i, Nn = /iPad/i, sn = /\bAndroid(?:.+)Mobile\b/i, Rn = /Android/i, Te = /\bAndroid(?:.+)SD4930UR\b/i, Ye = /\bAndroid(?:.+)(?:KF[A-Z]{2,4})\b/i, ye = /Windows Phone/i, On = /\bWindows(?:.+)ARM\b/i, Kn = /BlackBerry/i, Tn = /BB10/i, Fn = /Opera Mini/i, zn = /\b(CriOS|Chrome)(?:.+)Mobile/i, Dn = /Mobile(?:.+)Firefox\b/i;
function D(o, e) {
  return o.test(e);
}
function $n(o) {
  var e = o || "", t = e.split("[FBAN");
  if (typeof t[1] < "u") {
    var n = t, i = xe(n, 1);
    e = i[0];
  }
  if (t = e.split("Twitter"), typeof t[1] < "u") {
    var l = t, u = xe(l, 1);
    e = u[0];
  }
  var r = { apple: { phone: D(un, e) && !D(ye, e), ipod: D(An, e), tablet: !D(un, e) && D(Nn, e) && !D(ye, e), device: (D(un, e) || D(An, e) || D(Nn, e)) && !D(ye, e) }, amazon: { phone: D(Te, e), tablet: !D(Te, e) && D(Ye, e), device: D(Te, e) || D(Ye, e) }, android: { phone: !D(ye, e) && D(Te, e) || !D(ye, e) && D(sn, e), tablet: !D(ye, e) && !D(Te, e) && !D(sn, e) && (D(Ye, e) || D(Rn, e)), device: !D(ye, e) && (D(Te, e) || D(Ye, e) || D(sn, e) || D(Rn, e)) || D(/\bokhttp\b/i, e) }, windows: { phone: D(ye, e), tablet: D(On, e), device: D(ye, e) || D(On, e) }, other: { blackberry: D(Kn, e), blackberry10: D(Tn, e), opera: D(Fn, e), firefox: D(Dn, e), chrome: D(zn, e), device: D(Kn, e) || D(Tn, e) || D(Fn, e) || D(Dn, e) || D(zn, e) }, any: null, phone: null, tablet: null };
  return r.any = r.apple.device || r.android.device || r.windows.device || r.other.device, r.phone = r.apple.phone || r.android.phone || r.windows.phone, r.tablet = r.apple.tablet || r.android.tablet || r.windows.tablet, r;
}
var ba = v(v({}, $n()), {}, { isMobile: $n });
const Ca = ba;
var xa = ["disabled", "loading", "addonAfter", "suffix"];
const Sa = defineComponent({ compatConfig: { MODE: 3 }, name: "AInputSearch", inheritAttrs: false, props: v(v({}, Po()), {}, { inputPrefixCls: String, enterButton: pt.any, onSearch: { type: Function } }), setup: function(e, t) {
  var n = t.slots, i = t.attrs, l = t.expose, u = t.emit, r = ref(), a = function() {
    var p;
    (p = r.value) === null || p === void 0 || p.focus();
  }, g = function() {
    var p;
    (p = r.value) === null || p === void 0 || p.blur();
  };
  l({ focus: a, blur: g });
  var y = function(p) {
    u("update:value", p.target.value), p && p.target && p.type === "click" && u("search", p.target.value, p), u("change", p);
  }, m = function(p) {
    var _;
    document.activeElement === ((_ = r.value) === null || _ === void 0 ? void 0 : _.input) && p.preventDefault();
  }, E = function(p) {
    var _;
    u("search", (_ = r.value) === null || _ === void 0 ? void 0 : _.stateValue, p), Ca.tablet || r.value.focus();
  }, s = ke$1("input-search", e), x$1 = s.prefixCls, f = s.getPrefixCls, M = s.direction, P = s.size, w = computed(function() {
    return f("input", e.inputPrefixCls);
  });
  return function() {
    var h, p, _, $, T, A = e.disabled, O = e.loading, L = e.addonAfter, j = L === void 0 ? (h = n.addonAfter) === null || h === void 0 ? void 0 : h.call(n) : L, Y = e.suffix, te = Y === void 0 ? (p = n.suffix) === null || p === void 0 ? void 0 : p.call(n) : Y, le = he(e, xa), B = e.enterButton, c = B === void 0 ? (_ = ($ = n.enterButton) === null || $ === void 0 ? void 0 : $.call(n)) !== null && _ !== void 0 ? _ : false : B;
    c = c || c === "";
    var I = typeof c == "boolean" ? createVNode(Ot, null, null) : null, N = "".concat(x$1.value, "-button"), K = Array.isArray(c) ? c[0] : c, V, G = K.type && Kt(K.type) && K.type.__ANT_BUTTON;
    if (G || K.tagName === "button")
      V = Q(K, v({ onMousedown: m, onClick: E, key: "enterButton" }, G ? { class: N, size: P.value } : {}), false);
    else {
      var ee = I && !c;
      V = createVNode(Jo, { class: N, type: c ? "primary" : void 0, size: P.value, disabled: A, key: "enterButton", onMousedown: m, onClick: E, loading: O, icon: ee ? I : null }, { default: function() {
        return [ee ? null : I || c];
      } });
    }
    j && (V = [V, j]);
    var k = pe(x$1.value, (T = {}, x(T, "".concat(x$1.value, "-rtl"), M.value === "rtl"), x(T, "".concat(x$1.value, "-").concat(P.value), !!P.value), x(T, "".concat(x$1.value, "-with-button"), !!c), T), i.class);
    return createVNode(oi, v(v(v({ ref: r }, Ce(le, ["onUpdate:value", "onSearch", "enterButton"])), i), {}, { onPressEnter: E, size: P.value, prefixCls: w.value, addonAfter: V, suffix: te, onChange: y, class: k, disabled: A }), n);
  };
} });
var Ma = `
 min-height:0 !important;
 max-height:none !important;
 height:0 !important;
 visibility:hidden !important;
 overflow:hidden !important;
 position:absolute !important;
 z-index:-1000 !important;
 top:0 !important;
 right:0 !important
`, Ia = ["letter-spacing", "line-height", "padding-top", "padding-bottom", "font-family", "font-weight", "font-size", "font-variant", "text-rendering", "text-transform", "width", "text-indent", "padding-left", "padding-right", "border-width", "box-sizing", "word-break"], vn = {}, de;
function Pa(o) {
  var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false, t = o.getAttribute("id") || o.getAttribute("data-reactid") || o.getAttribute("name");
  if (e && vn[t])
    return vn[t];
  var n = window.getComputedStyle(o), i = n.getPropertyValue("box-sizing") || n.getPropertyValue("-moz-box-sizing") || n.getPropertyValue("-webkit-box-sizing"), l = parseFloat(n.getPropertyValue("padding-bottom")) + parseFloat(n.getPropertyValue("padding-top")), u = parseFloat(n.getPropertyValue("border-bottom-width")) + parseFloat(n.getPropertyValue("border-top-width")), r = Ia.map(function(g) {
    return "".concat(g, ":").concat(n.getPropertyValue(g));
  }).join(";"), a = { sizingStyle: r, paddingSize: l, borderSize: u, boxSizing: i };
  return e && t && (vn[t] = a), a;
}
function Ea(o) {
  var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false, t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null, n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : null;
  de || (de = document.createElement("textarea"), de.setAttribute("tab-index", "-1"), de.setAttribute("aria-hidden", "true"), document.body.appendChild(de)), o.getAttribute("wrap") ? de.setAttribute("wrap", o.getAttribute("wrap")) : de.removeAttribute("wrap");
  var i = Pa(o, e), l = i.paddingSize, u = i.borderSize, r = i.boxSizing, a = i.sizingStyle;
  de.setAttribute("style", "".concat(a, ";").concat(Ma)), de.value = o.value || o.placeholder || "";
  var g = Number.MIN_SAFE_INTEGER, y = Number.MAX_SAFE_INTEGER, m = de.scrollHeight, E;
  if (r === "border-box" ? m += u : r === "content-box" && (m -= l), t !== null || n !== null) {
    de.value = " ";
    var s = de.scrollHeight - l;
    t !== null && (g = s * t, r === "border-box" && (g = g + l + u), m = Math.max(g, m)), n !== null && (y = s * n, r === "border-box" && (y = y + l + u), E = m > y ? "" : "hidden", m = Math.min(y, m));
  }
  return { height: "".concat(m, "px"), minHeight: "".concat(g, "px"), maxHeight: "".concat(y, "px"), overflowY: E, resize: "none" };
}
var cn = 0, Bn = 1, wa = 2, _a = defineComponent({ compatConfig: { MODE: 3 }, name: "ResizableTextArea", inheritAttrs: false, props: ni(), setup: function(e, t) {
  var n = t.attrs, i = t.emit, l = t.expose, u, r, a = ref(), g = ref({}), y = ref(cn), m = function() {
    try {
      if (document.activeElement === a.value) {
        var w = a.value.selectionStart, h = a.value.selectionEnd;
        a.value.setSelectionRange(w, h);
      }
    } catch {
    }
  }, E = function() {
    var w = e.autoSize || e.autosize;
    if (!(!w || !a.value)) {
      var h = w.minRows, p = w.maxRows;
      g.value = Ea(a.value, false, h, p), y.value = Bn, ne.cancel(r), r = ne(function() {
        y.value = wa, r = ne(function() {
          y.value = cn, m();
        });
      });
    }
  }, s = function() {
    ne.cancel(u), u = ne(E);
  }, x$1 = function(w) {
    if (y.value === cn) {
      i("resize", w);
      var h = e.autoSize || e.autosize;
      h && s();
    }
  };
  Ho(e.autosize === void 0, "Input.TextArea", "autosize is deprecated, please use autoSize instead.");
  var f = function() {
    var w = e.prefixCls, h = e.autoSize, p = e.autosize, _ = e.disabled, $ = Ce(e, ["prefixCls", "onPressEnter", "autoSize", "autosize", "defaultValue", "allowClear", "type", "lazy", "maxlength", "valueModifiers"]), T = pe(w, n.class, x({}, "".concat(w, "-disabled"), _)), A = [n.style, g.value, y.value === Bn ? { overflowX: "hidden", overflowY: "hidden" } : null], O = v(v(v({}, $), n), {}, { style: A, class: T });
    return O.autofocus || delete O.autofocus, O.rows === 0 && delete O.rows, createVNode(hn, { onResize: x$1, disabled: !(h || p) }, { default: function() {
      return [withDirectives(createVNode("textarea", v(v({}, O), {}, { ref: a }), null), [[Un]])];
    } });
  };
  watch(function() {
    return e.value;
  }, function() {
    nextTick(function() {
      E();
    });
  });
  var M = getCurrentInstance();
  return l({ resizeTextarea: E, textArea: a, instance: M }), function() {
    return f();
  };
} });
const Aa = _a;
function ct(o, e) {
  return fe(o || "").slice(0, e).join("");
}
function kn(o, e, t, n) {
  var i = t;
  return o ? i = ct(t, n) : fe(e || "").length < t.length && fe(t || "").length > n && (i = e), i;
}
const Na = defineComponent({ compatConfig: { MODE: 3 }, name: "ATextarea", inheritAttrs: false, props: ni(), setup: function(e, t) {
  var n = t.attrs, i = t.expose, l = t.emit, u = qn$1(), r = ref(e.value === void 0 ? e.defaultValue : e.value), a = ref(), g = ref(""), y = ke$1("input", e), m = y.prefixCls, E = y.size, s = y.direction, x$1 = computed(function() {
    return e.showCount === "" || e.showCount || false;
  }), f = computed(function() {
    return Number(e.maxlength) > 0;
  }), M = ref(false), P = ref(), w = ref(0), h = function(c) {
    M.value = true, P.value = g.value, w.value = c.currentTarget.selectionStart, l("compositionstart", c);
  }, p = function(c) {
    M.value = false;
    var I = c.currentTarget.value;
    if (f.value) {
      var N, K = w.value >= e.maxlength + 1 || w.value === ((N = P.value) === null || N === void 0 ? void 0 : N.length);
      I = kn(K, P.value, I, e.maxlength);
    }
    I !== g.value && (A(I), dt(c.currentTarget, c, j, I)), l("compositionend", c);
  }, _ = getCurrentInstance();
  watch(function() {
    return e.value;
  }, function() {
    "value" in _.vnode.props;
    var B;
    r.value = (B = e.value) !== null && B !== void 0 ? B : "";
  });
  var $ = function(c) {
    var I;
    Oo((I = a.value) === null || I === void 0 ? void 0 : I.textArea, c);
  }, T = function() {
    var c, I;
    (c = a.value) === null || c === void 0 || (I = c.textArea) === null || I === void 0 || I.blur();
  }, A = function(c, I) {
    r.value !== c && (e.value === void 0 ? r.value = c : nextTick(function() {
      if (a.value.textArea.value !== g.value) {
        var N, K, V;
        (N = a.value) === null || N === void 0 || (K = (V = N.instance).update) === null || K === void 0 || K.call(V);
      }
    }), nextTick(function() {
      I && I();
    }));
  }, O = function(c) {
    c.keyCode === 13 && l("pressEnter", c), l("keydown", c);
  }, L = function(c) {
    var I = e.onBlur;
    I == null || I(c), u.onFieldBlur();
  }, j = function(c) {
    l("update:value", c.target.value), l("change", c), l("input", c), u.onFieldChange();
  }, Y = function(c) {
    dt(a.value.textArea, c, j), A("", function() {
      $();
    });
  }, te = function(c) {
    var I = c.target.composing, N = c.target.value;
    if (M.value = !!(c.isComposing || I), !(M.value && e.lazy || r.value === N)) {
      if (f.value) {
        var K = c.target, V = K.selectionStart >= e.maxlength + 1 || K.selectionStart === N.length || !K.selectionStart;
        N = kn(V, g.value, N, e.maxlength);
      }
      dt(c.currentTarget, c, j, N), A(N);
    }
  }, le = function() {
    var c, I, N, K = n.style, V = n.class, G = e.bordered, ee = G === void 0 ? true : G, k = v(v(v({}, Ce(e, ["allowClear"])), n), {}, { style: x$1.value ? {} : K, class: (c = {}, x(c, "".concat(m.value, "-borderless"), !ee), x(c, "".concat(V), V && !x$1.value), x(c, "".concat(m.value, "-sm"), E.value === "small"), x(c, "".concat(m.value, "-lg"), E.value === "large"), c), showCount: null, prefixCls: m.value, onInput: te, onChange: te, onBlur: L, onKeydown: O, onCompositionstart: h, onCompositionend: p });
    return (I = e.valueModifiers) !== null && I !== void 0 && I.lazy && delete k.onInput, createVNode(Aa, v(v({}, k), {}, { id: (N = k.id) !== null && N !== void 0 ? N : u.id.value, ref: a, maxlength: e.maxlength }), null);
  };
  return i({ focus: $, blur: T, resizableTextArea: a }), watchEffect(function() {
    var B = ft(r.value);
    !M.value && f.value && (e.value === null || e.value === void 0) && (B = ct(B, e.maxlength)), g.value = B;
  }), function() {
    var B = e.maxlength, c = e.bordered, I = c === void 0 ? true : c, N = e.hidden, K = n.style, V = n.class, G = v(v(v({}, e), n), {}, { prefixCls: m.value, inputType: "text", handleReset: Y, direction: s.value, bordered: I, style: x$1.value ? void 0 : K }), ee$1 = createVNode(Ao, v(v({}, G), {}, { value: g.value }), { element: le });
    if (x$1.value) {
      var k = fe(g.value).length, d = "";
      ee(x$1.value) === "object" ? d = x$1.value.formatter({ count: k, maxlength: B }) : d = "".concat(k).concat(f.value ? " / ".concat(B) : ""), ee$1 = createVNode("div", { hidden: N, class: pe("".concat(m.value, "-textarea"), x({}, "".concat(m.value, "-textarea-rtl"), s.value === "rtl"), "".concat(m.value, "-textarea-show-count"), V), style: K, "data-count": ee(d) !== "object" ? d : void 0 }, [ee$1]);
    }
    return ee$1;
  };
} });
var Ra = ["size", "visibilityToggle"], Oa = { click: "onClick", hover: "onMouseover" }, Ka = function(e) {
  return e ? createVNode(Yt$1, null, null) : createVNode(zt, null, null);
};
const Ta = defineComponent({ compatConfig: { MODE: 3 }, name: "AInputPassword", inheritAttrs: false, props: v(v({}, Po()), {}, { prefixCls: String, inputPrefixCls: String, action: { type: String, default: "click" }, visibilityToggle: { type: Boolean, default: true }, iconRender: Function }), setup: function(e, t) {
  var n = t.slots, i = t.attrs, l = t.expose, u = ref(false), r = function() {
    var w = e.disabled;
    w || (u.value = !u.value);
  }, a = ref(), g = function() {
    var w;
    (w = a.value) === null || w === void 0 || w.focus();
  }, y = function() {
    var w;
    (w = a.value) === null || w === void 0 || w.blur();
  };
  l({ focus: g, blur: y });
  var m = function(w) {
    var h, p = e.action, _ = e.iconRender, $ = _ === void 0 ? n.iconRender || Ka : _, T = Oa[p] || "", A = $(u.value), O = (h = {}, x(h, T, r), x(h, "class", "".concat(w, "-icon")), x(h, "key", "passwordIcon"), x(h, "onMousedown", function(j) {
      j.preventDefault();
    }), x(h, "onMouseup", function(j) {
      j.preventDefault();
    }), h);
    return Q(Ii(A) ? A : createVNode("span", null, [A]), O);
  }, E = ke$1("input-password", e), s = E.prefixCls, x$1 = E.getPrefixCls, f = computed(function() {
    return x$1("input", e.inputPrefixCls);
  }), M = function() {
    var w = e.size, h = e.visibilityToggle, p = he(e, Ra), _ = h && m(s.value), $ = pe(s.value, i.class, x({}, "".concat(s.value, "-").concat(w), !!w)), T = v(v(v({}, Ce(p, ["suffix", "iconRender", "action"])), i), {}, { type: u.value ? "text" : "password", class: $, prefixCls: f.value, suffix: _ });
    return w && (T.size = w), createVNode(oi, v({ ref: a }, T), n);
  };
  return function() {
    return M();
  };
} });
oi.Group = ha;
oi.Search = Sa;
oi.TextArea = Na;
oi.Password = Ta;
oi.install = function(o) {
  return o.component(oi.name, oi), o.component(oi.Group.name, oi.Group), o.component(oi.Search.name, oi.Search), o.component(oi.TextArea.name, oi.TextArea), o.component(oi.Password.name, oi.Password), o;
};
const lr = () => Ur("userInfo", () => {
  const o = it$1("userInfo");
  return o.value ? o.value : null;
});

export { Dt as D, Le as L, Xe$1 as X, Yt$1 as Y, _e as _, hn as h, ia as i, lr as l, nn as n, or as o };
//# sourceMappingURL=index-4f8e2b3b.mjs.map
