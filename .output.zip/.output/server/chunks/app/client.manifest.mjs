const client_manifest = {
  "NavBar.css": {
    "resourceType": "style",
    "file": "NavBar.6be84dfb.css",
    "src": "NavBar.css"
  },
  "_Form.cc4c8a44.js": {
    "resourceType": "script",
    "module": true,
    "file": "Form.cc4c8a44.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useHttpFetch.b8763db9.js",
      "_debounce.9a19f0ed.js",
      "_logo.078fbf45.js"
    ]
  },
  "_NavBar.e23e2e49.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "NavBar.6be84dfb.css"
    ],
    "file": "NavBar.e23e2e49.js",
    "imports": [
      "_nuxt-link.8968655c.js",
      "_index.d1eec92c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useHttpFetch.b8763db9.js",
      "_logo.078fbf45.js"
    ]
  },
  "NavBar.6be84dfb.css": {
    "file": "NavBar.6be84dfb.css",
    "resourceType": "style"
  },
  "_debounce.9a19f0ed.js": {
    "resourceType": "script",
    "module": true,
    "file": "debounce.9a19f0ed.js",
    "imports": [
      "_useHttpFetch.b8763db9.js"
    ]
  },
  "_diamond.34a53e80.js": {
    "resourceType": "script",
    "module": true,
    "file": "diamond.34a53e80.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.4f00da55.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.56ad1383.css"
    ],
    "file": "index.4f00da55.js",
    "imports": [
      "_debounce.9a19f0ed.js",
      "_useHttpFetch.b8763db9.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "index.56ad1383.css": {
    "file": "index.56ad1383.css",
    "resourceType": "style"
  },
  "_index.707105eb.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.707105eb.js",
    "imports": [
      "_Form.cc4c8a44.js",
      "_useHttpFetch.b8763db9.js"
    ]
  },
  "_index.d1eec92c.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.0866b696.css"
    ],
    "file": "index.d1eec92c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useHttpFetch.b8763db9.js"
    ]
  },
  "index.0866b696.css": {
    "file": "index.0866b696.css",
    "resourceType": "style"
  },
  "_login_page_download.dc30f808.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "login_page_download.e7a4ee31.css"
    ],
    "file": "login_page_download.dc30f808.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "login_page_download.e7a4ee31.css": {
    "file": "login_page_download.e7a4ee31.css",
    "resourceType": "style"
  },
  "_logo.078fbf45.js": {
    "resourceType": "script",
    "module": true,
    "file": "logo.078fbf45.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useHttpFetch.b8763db9.js"
    ]
  },
  "_nuxt-link.8968655c.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.8968655c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_pickAttrs.a4410196.js": {
    "resourceType": "script",
    "module": true,
    "file": "pickAttrs.a4410196.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useHttpFetch.b8763db9.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "useHttpFetch.40658419.css"
    ],
    "file": "useHttpFetch.b8763db9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "useHttpFetch.40658419.css": {
    "file": "useHttpFetch.40658419.css",
    "resourceType": "style"
  },
  "index.css": {
    "resourceType": "style",
    "file": "index.0866b696.css",
    "src": "index.css"
  },
  "login_page_download.css": {
    "resourceType": "style",
    "file": "login_page_download.e7a4ee31.css",
    "src": "login_page_download.css"
  },
  "middleware/auth.ts": {
    "resourceType": "script",
    "module": true,
    "file": "auth.584842b4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/auth.ts"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.23f2309d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.c65ed224.js",
    "imports": [
      "_nuxt-link.8968655c.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.23f2309d.css": {
    "file": "error-404.23f2309d.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.aa16ed4d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.f610e7a0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.aa16ed4d.css": {
    "file": "error-500.aa16ed4d.css",
    "resourceType": "style"
  },
  "node_modules/highlight.js/es/index.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.a897a849.js",
    "isDynamicEntry": true,
    "src": "node_modules/highlight.js/es/index.js"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.e93d3e98.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.e93d3e98.css"
    ],
    "dynamicImports": [
      "middleware/auth.ts",
      "virtual:nuxt:/Users/hedy/Projects/j-book/.nuxt/error-component.mjs"
    ],
    "file": "entry.f068fae9.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.e93d3e98.css": {
    "file": "entry.e93d3e98.css",
    "resourceType": "style"
  },
  "pages/about.vue": {
    "resourceType": "script",
    "module": true,
    "file": "about.f43180b6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/about.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.33a0c2ab.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.a3270bcd.js",
    "imports": [
      "_NavBar.e23e2e49.js",
      "_nuxt-link.8968655c.js",
      "_useHttpFetch.b8763db9.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_diamond.34a53e80.js",
      "_index.d1eec92c.js",
      "_logo.078fbf45.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.33a0c2ab.css": {
    "file": "index.33a0c2ab.css",
    "resourceType": "style"
  },
  "pages/note/writer.css": {
    "resourceType": "style",
    "file": "writer.ef863487.css",
    "src": "pages/note/writer.css"
  },
  "pages/note/writer.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "writer.a373e0c2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useHttpFetch.b8763db9.js",
      "_index.d1eec92c.js",
      "_index.4f00da55.js",
      "_debounce.9a19f0ed.js",
      "_pickAttrs.a4410196.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/note/writer.vue"
  },
  "writer.ef863487.css": {
    "file": "writer.ef863487.css",
    "resourceType": "style"
  },
  "pages/p/[id].css": {
    "resourceType": "style",
    "file": "_id_.5e39c1f1.css",
    "src": "pages/p/[id].css"
  },
  "pages/p/[id].vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "dynamicImports": [
      "node_modules/highlight.js/es/index.js"
    ],
    "file": "_id_.c3bae127.js",
    "imports": [
      "_NavBar.e23e2e49.js",
      "_nuxt-link.8968655c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useHttpFetch.b8763db9.js",
      "_diamond.34a53e80.js",
      "_index.4f00da55.js",
      "_index.d1eec92c.js",
      "_logo.078fbf45.js",
      "_debounce.9a19f0ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/p/[id].vue"
  },
  "_id_.5e39c1f1.css": {
    "file": "_id_.5e39c1f1.css",
    "resourceType": "style"
  },
  "pages/sign_in.css": {
    "resourceType": "style",
    "file": "sign_in.3dbba087.css",
    "src": "pages/sign_in.css"
  },
  "pages/sign_in.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "sign_in.de6505da.js",
    "imports": [
      "_nuxt-link.8968655c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_login_page_download.dc30f808.js",
      "_useHttpFetch.b8763db9.js",
      "_logo.078fbf45.js",
      "_Form.cc4c8a44.js",
      "_index.707105eb.js",
      "_debounce.9a19f0ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign_in.vue"
  },
  "sign_in.3dbba087.css": {
    "file": "sign_in.3dbba087.css",
    "resourceType": "style"
  },
  "pages/sign_up.css": {
    "resourceType": "style",
    "file": "sign_up.5b78dd62.css",
    "src": "pages/sign_up.css"
  },
  "pages/sign_up.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "sign_up.db6b5946.js",
    "imports": [
      "_nuxt-link.8968655c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_login_page_download.dc30f808.js",
      "_useHttpFetch.b8763db9.js",
      "_logo.078fbf45.js",
      "_Form.cc4c8a44.js",
      "_debounce.9a19f0ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign_up.vue"
  },
  "sign_up.5b78dd62.css": {
    "file": "sign_up.5b78dd62.css",
    "resourceType": "style"
  },
  "pages/user/settings.css": {
    "resourceType": "style",
    "file": "settings.f0035a5c.css",
    "src": "pages/user/settings.css"
  },
  "pages/user/settings.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "settings.59fbad00.js",
    "imports": [
      "_NavBar.e23e2e49.js",
      "_index.d1eec92c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useHttpFetch.b8763db9.js",
      "_pickAttrs.a4410196.js",
      "_Form.cc4c8a44.js",
      "_index.707105eb.js",
      "_nuxt-link.8968655c.js",
      "_logo.078fbf45.js",
      "_debounce.9a19f0ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/settings.vue"
  },
  "settings.f0035a5c.css": {
    "file": "settings.f0035a5c.css",
    "resourceType": "style"
  },
  "useHttpFetch.css": {
    "resourceType": "style",
    "file": "useHttpFetch.40658419.css",
    "src": "useHttpFetch.css"
  },
  "virtual:nuxt:/Users/hedy/Projects/j-book/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.c21d3344.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:/Users/hedy/Projects/j-book/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
