const interopDefault = r => r.default || r || [];
const styles = {
  "pages/index.vue": () => import('./_nuxt/index-styles.1b532bdb.mjs').then(interopDefault),
  "pages/note/writer.vue": () => import('./_nuxt/writer-styles.1082921f.mjs').then(interopDefault),
  "pages/p/[id].vue": () => import('./_nuxt/_id_-styles.3c0bc94f.mjs').then(interopDefault),
  "pages/sign_up.vue": () => import('./_nuxt/sign_up-styles.b9d8e2cd.mjs').then(interopDefault),
  "pages/user/settings.vue": () => import('./_nuxt/settings-styles.6cb053ef.mjs').then(interopDefault),
  "pages/sign_in.vue": () => import('./_nuxt/sign_in-styles.132f6f81.mjs').then(interopDefault),
  "components/BannerSider.vue": () => import('./_nuxt/BannerSider-styles.945d2aca.mjs').then(interopDefault),
  "components/NoteItem.vue": () => import('./_nuxt/NoteItem-styles.feee8c35.mjs').then(interopDefault),
  "components/RecommendAuthor.vue": () => import('./_nuxt/RecommendAuthor-styles.a2118f01.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.d89c5c2f.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.165701d8.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
