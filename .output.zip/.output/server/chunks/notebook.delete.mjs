import { defineEventHandler, setResponseStatus, readBody } from 'h3';
import Joi from 'joi';
import { g as getDB } from './index2.mjs';
import { g as getLoginUid, r as responseJson } from './index.mjs';
import 'mysql2';
import './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'jsonwebtoken';

const notebook_delete = defineEventHandler(async (event) => {
  let uid = getLoginUid(event);
  console.log("uid", uid);
  if (uid === 0) {
    setResponseStatus(event, 401);
    return responseJson(1, "\u8BF7\u5148\u767B\u5F55", {});
  }
  const body = await readBody(event);
  console.log("11111", body);
  const schema = Joi.object({
    id: Joi.number().required()
  });
  try {
    const value = await schema.validateAsync(body);
  } catch (err) {
    return responseJson(1, "\u53C2\u6570\u9519\u8BEF", {});
  }
  const con = getDB();
  try {
    const [rows] = await con.execute(
      "DELETE FROM `notebooks` WHERE `id`=? AND `uid`=?",
      [body.id, uid]
    );
    console.log("333333", rows);
    await con.end();
    if (rows.affectedRows === 0) {
      return responseJson(1, "\u5220\u9664\u5931\u8D25", {});
    }
    return responseJson(0, "\u5220\u9664\u6587\u96C6\u6210\u529F\u54E6", {});
  } catch (e) {
    await con.end();
    console.log("error", e);
    setResponseStatus(event, 500);
    return responseJson(1, "\u670D\u52A1\u5668\u9519\u8BEF", {});
  }
});

export { notebook_delete as default };
//# sourceMappingURL=notebook.delete.mjs.map
