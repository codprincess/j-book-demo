import { defineEventHandler, readBody } from 'h3';
import Joi from 'joi';
import { r as responseJson } from './index.mjs';
import { g as getDB } from './index2.mjs';
import md5 from 'md5';
import jwt from 'jsonwebtoken';
import 'mysql2';
import './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const login_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  console.log("11111", body);
  const schema = Joi.object({
    password: Joi.string().required(),
    phone: Joi.string().pattern(/1\d{10}/)
  });
  try {
    const value = await schema.validateAsync(body);
  } catch (err) {
    return responseJson(1, "\u53C2\u6570\u9519\u8BEF", {});
  }
  let salt = "ueidfisgfilegfiff";
  let password = md5(md5(body.password) + salt);
  const con = getDB();
  try {
    const [rows] = await con.execute(
      "SELECT * FROM `users` WHERE `phone`=? AND `password`=?",
      [body.phone, password]
    );
    console.log("22222", rows);
    if (rows.length === 0) {
      return responseJson(1, "\u8D26\u53F7\u4E0D\u5B58\u5728\u6216\u8005\u5BC6\u7801\u9519\u8BEF", {});
    }
    await con.end();
    let secret = "eifuisedfuvs";
    let token = jwt.sign({
      exp: Math.floor(Date.now() / 1e3) + 60 * 60,
      data: { data: { uid: rows[0].id } }
    }, secret);
    return responseJson(0, "ok", {
      accessToken: token,
      userInfo: {
        id: rows[0].id,
        nickname: rows[0].nickname,
        phone: rows[0].phone,
        avatar: rows[0].avatar
      }
    });
  } catch (e) {
    await con.end();
    return responseJson(1, "\u670D\u52A1\u5668\u9519\u8BEF", {});
  }
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
